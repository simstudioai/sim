import { eq, desc, sql, lte, and, gte } from "drizzle-orm";
import { db } from "./db";
import { encrypt, decrypt, maskSecret } from "./crypto";
import {
  users,
  affiliateNetworks,
  affiliateProducts,
  affiliateEarnings,
  affiliateClicks,
  affiliatePayouts,
  secureVaultItems,
  activityLogs,
  socialAccounts,
  marketplaceProducts,
  campaigns,
  postQueue,
  notificationSettings,
  notifications,
  abTestVariants,
  postTemplates,
  analyticsSnapshots,
  rateLimits,
  salesTracking,
  blogPosts,
  contentQueue,
  customerPurchases,
  supportTickets,
  supportMessages,
  type User,
  type InsertUser,
  type AffiliateNetwork,
  type InsertAffiliateNetwork,
  type AffiliateProduct,
  type InsertAffiliateProduct,
  type AffiliateEarning,
  type InsertAffiliateEarning,
  type AffiliateClick,
  type InsertAffiliateClick,
  type AffiliatePayout,
  type InsertAffiliatePayout,
  type SecureVaultItem,
  type InsertSecureVaultItem,
  type ActivityLog,
  type InsertActivityLog,
  type SocialAccount,
  type InsertSocialAccount,
  type MarketplaceProduct,
  type InsertMarketplaceProduct,
  type Campaign,
  type InsertCampaign,
  type PostQueue,
  type InsertPostQueue,
  type NotificationSettings,
  type InsertNotificationSettings,
  type Notification,
  type InsertNotification,
  type AbTestVariant,
  type InsertAbTestVariant,
  type PostTemplate,
  type InsertPostTemplate,
  type AnalyticsSnapshot,
  type InsertAnalyticsSnapshot,
  type RateLimit,
  type InsertRateLimit,
  type SalesTracking,
  type InsertSalesTracking,
  type BlogPost,
  type InsertBlogPost,
  type ContentQueue,
  type InsertContentQueue,
  type CustomerPurchase,
  type InsertCustomerPurchase,
  type SupportTicket,
  type InsertSupportTicket,
  type SupportMessage,
  type InsertSupportMessage,
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Affiliate Networks (with encryption)
  getAffiliateNetworks(): Promise<AffiliateNetwork[]>;
  getAffiliateNetworksSafe(): Promise<Omit<AffiliateNetwork, "apiKey" | "apiSecret">[]>;
  getAffiliateNetwork(id: string): Promise<AffiliateNetwork | undefined>;
  getAffiliateNetworkDecrypted(id: string): Promise<AffiliateNetwork | undefined>;
  createAffiliateNetwork(network: InsertAffiliateNetwork): Promise<AffiliateNetwork>;
  updateAffiliateNetwork(id: string, network: Partial<InsertAffiliateNetwork>): Promise<AffiliateNetwork | undefined>;
  deleteAffiliateNetwork(id: string): Promise<boolean>;

  // Affiliate Products
  getAffiliateProducts(networkId?: string): Promise<AffiliateProduct[]>;
  getAffiliateProduct(id: string): Promise<AffiliateProduct | undefined>;
  createAffiliateProduct(product: InsertAffiliateProduct): Promise<AffiliateProduct>;
  updateAffiliateProduct(id: string, product: Partial<InsertAffiliateProduct>): Promise<AffiliateProduct | undefined>;
  deleteAffiliateProduct(id: string): Promise<boolean>;

  // Earnings
  getAffiliateEarnings(networkId?: string): Promise<AffiliateEarning[]>;
  createAffiliateEarning(earning: InsertAffiliateEarning): Promise<AffiliateEarning>;
  getTotalEarnings(): Promise<{ total: string; pending: string; paid: string }>;

  // Clicks
  getAffiliateClicks(productId?: string): Promise<AffiliateClick[]>;
  createAffiliateClick(click: InsertAffiliateClick): Promise<AffiliateClick>;
  getClickStats(): Promise<{ total: number; today: number }>;

  // Payouts
  getAffiliatePayouts(networkId?: string): Promise<AffiliatePayout[]>;
  createAffiliatePayout(payout: InsertAffiliatePayout): Promise<AffiliatePayout>;

  // Secure Vault
  getSecureVaultItems(): Promise<SecureVaultItem[]>;
  getSecureVaultItem(id: string): Promise<SecureVaultItem | undefined>;
  createSecureVaultItem(item: InsertSecureVaultItem): Promise<SecureVaultItem>;
  updateSecureVaultItem(id: string, item: Partial<InsertSecureVaultItem>): Promise<SecureVaultItem | undefined>;
  deleteSecureVaultItem(id: string): Promise<boolean>;

  // Activity Logs
  getActivityLogs(limit?: number): Promise<ActivityLog[]>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;

  // Customer Purchases
  createCustomerPurchase(purchase: InsertCustomerPurchase): Promise<CustomerPurchase>;
  getCustomerPurchaseByTransaction(transactionId: string): Promise<CustomerPurchase | undefined>;
  getCustomerPurchaseByToken(token: string): Promise<CustomerPurchase | undefined>;
  getCustomerPurchases(): Promise<CustomerPurchase[]>;
  deleteCustomerPurchase(id: string): Promise<boolean>;

  // Support Tickets
  createSupportTicket(ticket: InsertSupportTicket): Promise<SupportTicket>;
  getSupportTicket(id: string): Promise<SupportTicket | undefined>;
  getSupportTickets(status?: string): Promise<SupportTicket[]>;
  updateSupportTicket(id: string, ticket: Partial<SupportTicket>): Promise<SupportTicket | undefined>;

  // Support Messages
  createSupportMessage(message: InsertSupportMessage): Promise<SupportMessage>;
  getTicketMessages(ticketId: string): Promise<SupportMessage[]>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Affiliate Networks - SECURE VERSION
  async getAffiliateNetworks(): Promise<AffiliateNetwork[]> {
    return db.select().from(affiliateNetworks).orderBy(desc(affiliateNetworks.createdAt));
  }

  // Safe version that masks credentials for API responses
  async getAffiliateNetworksSafe(): Promise<Omit<AffiliateNetwork, "apiKey" | "apiSecret">[]> {
    const networks = await db.select().from(affiliateNetworks).orderBy(desc(affiliateNetworks.createdAt));
    return networks.map(network => ({
      ...network,
      apiKey: network.apiKey ? maskSecret(decrypt(network.apiKey)) : null,
      apiSecret: network.apiSecret ? maskSecret(decrypt(network.apiSecret)) : null,
    }));
  }

  async getAffiliateNetwork(id: string): Promise<AffiliateNetwork | undefined> {
    const [network] = await db.select().from(affiliateNetworks).where(eq(affiliateNetworks.id, id));
    return network;
  }

  // Decrypt credentials for internal use (API calls)
  async getAffiliateNetworkDecrypted(id: string): Promise<AffiliateNetwork | undefined> {
    const [network] = await db.select().from(affiliateNetworks).where(eq(affiliateNetworks.id, id));
    if (!network) return undefined;
    
    return {
      ...network,
      apiKey: network.apiKey ? decrypt(network.apiKey) : null,
      apiSecret: network.apiSecret ? decrypt(network.apiSecret) : null,
    };
  }

  async createAffiliateNetwork(network: InsertAffiliateNetwork): Promise<AffiliateNetwork> {
    // Encrypt sensitive fields before storing
    const encryptedNetwork = {
      ...network,
      apiKey: network.apiKey ? encrypt(network.apiKey) : null,
      apiSecret: network.apiSecret ? encrypt(network.apiSecret) : null,
    };
    
    const [created] = await db.insert(affiliateNetworks).values(encryptedNetwork).returning();
    
    // Log this action
    await this.createActivityLog({
      action: "network_connected",
      category: "affiliate",
      details: `Connected ${network.name} affiliate network`,
      severity: "info",
    });
    
    return created;
  }

  async updateAffiliateNetwork(id: string, network: Partial<InsertAffiliateNetwork>): Promise<AffiliateNetwork | undefined> {
    // Encrypt sensitive fields if they're being updated
    const encryptedUpdates = {
      ...network,
      ...(network.apiKey && { apiKey: encrypt(network.apiKey) }),
      ...(network.apiSecret && { apiSecret: encrypt(network.apiSecret) }),
    };
    
    const [updated] = await db.update(affiliateNetworks).set(encryptedUpdates).where(eq(affiliateNetworks.id, id)).returning();
    return updated;
  }

  async deleteAffiliateNetwork(id: string): Promise<boolean> {
    const network = await this.getAffiliateNetwork(id);
    await db.delete(affiliateNetworks).where(eq(affiliateNetworks.id, id));
    
    if (network) {
      await this.createActivityLog({
        action: "network_disconnected",
        category: "affiliate",
        details: `Disconnected ${network.name} affiliate network`,
        severity: "warning",
      });
    }
    
    return true;
  }

  // Affiliate Products
  async getAffiliateProducts(networkId?: string): Promise<AffiliateProduct[]> {
    if (networkId) {
      return db.select().from(affiliateProducts).where(eq(affiliateProducts.networkId, networkId)).orderBy(desc(affiliateProducts.createdAt));
    }
    return db.select().from(affiliateProducts).orderBy(desc(affiliateProducts.createdAt));
  }

  async getAffiliateProduct(id: string): Promise<AffiliateProduct | undefined> {
    const [product] = await db.select().from(affiliateProducts).where(eq(affiliateProducts.id, id));
    return product;
  }

  async createAffiliateProduct(product: InsertAffiliateProduct): Promise<AffiliateProduct> {
    const [created] = await db.insert(affiliateProducts).values(product).returning();
    return created;
  }

  async updateAffiliateProduct(id: string, product: Partial<InsertAffiliateProduct>): Promise<AffiliateProduct | undefined> {
    const [updated] = await db.update(affiliateProducts).set(product).where(eq(affiliateProducts.id, id)).returning();
    return updated;
  }

  async deleteAffiliateProduct(id: string): Promise<boolean> {
    await db.delete(affiliateProducts).where(eq(affiliateProducts.id, id));
    return true;
  }

  // Earnings
  async getAffiliateEarnings(networkId?: string): Promise<AffiliateEarning[]> {
    if (networkId) {
      return db.select().from(affiliateEarnings).where(eq(affiliateEarnings.networkId, networkId)).orderBy(desc(affiliateEarnings.createdAt));
    }
    return db.select().from(affiliateEarnings).orderBy(desc(affiliateEarnings.createdAt));
  }

  async createAffiliateEarning(earning: InsertAffiliateEarning): Promise<AffiliateEarning> {
    const [created] = await db.insert(affiliateEarnings).values(earning).returning();
    return created;
  }

  async getTotalEarnings(): Promise<{ total: string; pending: string; paid: string }> {
    const [result] = await db.select({
      total: sql<string>`COALESCE(SUM(${affiliateEarnings.amount}), 0)`,
      pending: sql<string>`COALESCE(SUM(CASE WHEN ${affiliateEarnings.status} = 'pending' THEN ${affiliateEarnings.amount} ELSE 0 END), 0)`,
      paid: sql<string>`COALESCE(SUM(CASE WHEN ${affiliateEarnings.status} = 'paid' THEN ${affiliateEarnings.amount} ELSE 0 END), 0)`,
    }).from(affiliateEarnings);
    return result || { total: "0", pending: "0", paid: "0" };
  }

  // Clicks
  async getAffiliateClicks(productId?: string): Promise<AffiliateClick[]> {
    if (productId) {
      return db.select().from(affiliateClicks).where(eq(affiliateClicks.productId, productId)).orderBy(desc(affiliateClicks.clickedAt));
    }
    return db.select().from(affiliateClicks).orderBy(desc(affiliateClicks.clickedAt));
  }

  async createAffiliateClick(click: InsertAffiliateClick): Promise<AffiliateClick> {
    const [created] = await db.insert(affiliateClicks).values(click).returning();
    return created;
  }

  async getClickStats(): Promise<{ total: number; today: number }> {
    const [result] = await db.select({
      total: sql<number>`COUNT(*)`,
      today: sql<number>`COUNT(*) FILTER (WHERE ${affiliateClicks.clickedAt} >= CURRENT_DATE)`,
    }).from(affiliateClicks);
    return result || { total: 0, today: 0 };
  }

  // Payouts
  async getAffiliatePayouts(networkId?: string): Promise<AffiliatePayout[]> {
    if (networkId) {
      return db.select().from(affiliatePayouts).where(eq(affiliatePayouts.networkId, networkId)).orderBy(desc(affiliatePayouts.createdAt));
    }
    return db.select().from(affiliatePayouts).orderBy(desc(affiliatePayouts.createdAt));
  }

  async createAffiliatePayout(payout: InsertAffiliatePayout): Promise<AffiliatePayout> {
    const [created] = await db.insert(affiliatePayouts).values(payout).returning();
    return created;
  }

  // Secure Vault - with encryption
  async getSecureVaultItems(): Promise<SecureVaultItem[]> {
    const items = await db.select().from(secureVaultItems).orderBy(desc(secureVaultItems.createdAt));
    // Decrypt content for display
    return items.map(item => ({
      ...item,
      encryptedContent: item.encryptedContent ? decrypt(item.encryptedContent) : null,
    }));
  }

  async getSecureVaultItem(id: string): Promise<SecureVaultItem | undefined> {
    const [item] = await db.select().from(secureVaultItems).where(eq(secureVaultItems.id, id));
    if (!item) return undefined;
    
    return {
      ...item,
      encryptedContent: item.encryptedContent ? decrypt(item.encryptedContent) : null,
    };
  }

  async createSecureVaultItem(item: InsertSecureVaultItem): Promise<SecureVaultItem> {
    const encryptedItem = {
      ...item,
      encryptedContent: item.encryptedContent ? encrypt(item.encryptedContent) : null,
    };
    
    const [created] = await db.insert(secureVaultItems).values(encryptedItem).returning();
    
    await this.createActivityLog({
      action: "vault_item_created",
      category: "security",
      details: `Added "${item.name}" to secure vault`,
      severity: "info",
    });
    
    return created;
  }

  async updateSecureVaultItem(id: string, item: Partial<InsertSecureVaultItem>): Promise<SecureVaultItem | undefined> {
    const encryptedUpdates = {
      ...item,
      ...(item.encryptedContent && { encryptedContent: encrypt(item.encryptedContent) }),
    };
    
    const [updated] = await db.update(secureVaultItems).set(encryptedUpdates).where(eq(secureVaultItems.id, id)).returning();
    return updated;
  }

  async deleteSecureVaultItem(id: string): Promise<boolean> {
    const item = await this.getSecureVaultItem(id);
    await db.delete(secureVaultItems).where(eq(secureVaultItems.id, id));
    
    if (item) {
      await this.createActivityLog({
        action: "vault_item_deleted",
        category: "security",
        details: `Removed "${item.name}" from secure vault`,
        severity: "warning",
      });
    }
    
    return true;
  }

  // Activity Logs
  async getActivityLogs(limit: number = 50): Promise<ActivityLog[]> {
    return db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(limit);
  }

  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const [created] = await db.insert(activityLogs).values(log).returning();
    return created;
  }

  // Marketplace Products
  async getMarketplaceProducts(networkId?: string): Promise<MarketplaceProduct[]> {
    if (networkId) {
      return db.select().from(marketplaceProducts).where(eq(marketplaceProducts.networkId, networkId)).orderBy(desc(marketplaceProducts.gravity));
    }
    return db.select().from(marketplaceProducts).orderBy(desc(marketplaceProducts.gravity));
  }

  async getMarketplaceProduct(id: string): Promise<MarketplaceProduct | undefined> {
    const [product] = await db.select().from(marketplaceProducts).where(eq(marketplaceProducts.id, id));
    return product;
  }

  async createMarketplaceProduct(product: InsertMarketplaceProduct): Promise<MarketplaceProduct> {
    const [created] = await db.insert(marketplaceProducts).values(product).returning();
    return created;
  }

  async updateMarketplaceProduct(id: string, product: Partial<InsertMarketplaceProduct>): Promise<MarketplaceProduct | undefined> {
    const [updated] = await db.update(marketplaceProducts).set(product).where(eq(marketplaceProducts.id, id)).returning();
    return updated;
  }

  async deleteMarketplaceProduct(id: string): Promise<boolean> {
    await db.delete(marketplaceProducts).where(eq(marketplaceProducts.id, id));
    return true;
  }

  // Social Accounts
  async getSocialAccounts(): Promise<SocialAccount[]> {
    const accounts = await db.select().from(socialAccounts).orderBy(desc(socialAccounts.createdAt));
    return accounts.map(account => ({
      ...account,
      accessToken: account.accessToken ? maskSecret(decrypt(account.accessToken)) : null,
      refreshToken: account.refreshToken ? maskSecret(decrypt(account.refreshToken)) : null,
    }));
  }

  async getSocialAccount(id: string): Promise<SocialAccount | undefined> {
    const [account] = await db.select().from(socialAccounts).where(eq(socialAccounts.id, id));
    return account;
  }

  async getSocialAccountDecrypted(id: string): Promise<SocialAccount | undefined> {
    const [account] = await db.select().from(socialAccounts).where(eq(socialAccounts.id, id));
    if (!account) return undefined;
    return {
      ...account,
      accessToken: account.accessToken ? decrypt(account.accessToken) : null,
      refreshToken: account.refreshToken ? decrypt(account.refreshToken) : null,
    };
  }

  async createSocialAccount(account: InsertSocialAccount): Promise<SocialAccount> {
    const encryptedAccount = {
      ...account,
      accessToken: account.accessToken ? encrypt(account.accessToken) : null,
      refreshToken: account.refreshToken ? encrypt(account.refreshToken) : null,
    };
    const [created] = await db.insert(socialAccounts).values(encryptedAccount).returning();
    
    await this.createActivityLog({
      action: "social_account_connected",
      category: "automation",
      details: `Connected ${account.platform} account`,
      severity: "info",
    });
    
    return created;
  }

  async updateSocialAccount(id: string, account: Partial<InsertSocialAccount>): Promise<SocialAccount | undefined> {
    const encryptedUpdates = {
      ...account,
      ...(account.accessToken && { accessToken: encrypt(account.accessToken) }),
      ...(account.refreshToken && { refreshToken: encrypt(account.refreshToken) }),
    };
    const [updated] = await db.update(socialAccounts).set(encryptedUpdates).where(eq(socialAccounts.id, id)).returning();
    return updated;
  }

  async deleteSocialAccount(id: string): Promise<boolean> {
    await db.delete(socialAccounts).where(eq(socialAccounts.id, id));
    return true;
  }

  // Campaigns
  async getCampaigns(status?: string): Promise<Campaign[]> {
    if (status) {
      return db.select().from(campaigns).where(eq(campaigns.status, status)).orderBy(desc(campaigns.createdAt));
    }
    return db.select().from(campaigns).orderBy(desc(campaigns.createdAt));
  }

  async getCampaign(id: string): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign;
  }

  async createCampaign(campaign: InsertCampaign): Promise<Campaign> {
    const [created] = await db.insert(campaigns).values(campaign).returning();
    
    await this.createActivityLog({
      action: "campaign_created",
      category: "automation",
      details: `Created campaign: ${campaign.name}`,
      severity: "info",
    });
    
    return created;
  }

  async updateCampaign(id: string, campaign: Partial<InsertCampaign>): Promise<Campaign | undefined> {
    const [updated] = await db.update(campaigns).set(campaign).where(eq(campaigns.id, id)).returning();
    return updated;
  }

  async deleteCampaign(id: string): Promise<boolean> {
    await db.delete(campaigns).where(eq(campaigns.id, id));
    return true;
  }

  async getScheduledCampaigns(): Promise<Campaign[]> {
    return db.select().from(campaigns)
      .where(eq(campaigns.status, "scheduled"))
      .orderBy(campaigns.scheduledTime);
  }

  // Post Queue
  async getPostQueue(status?: string): Promise<PostQueue[]> {
    if (status) {
      return db.select().from(postQueue).where(eq(postQueue.status, status)).orderBy(postQueue.scheduledFor);
    }
    return db.select().from(postQueue).orderBy(postQueue.scheduledFor);
  }

  async getPendingPosts(limit: number = 10): Promise<PostQueue[]> {
    const now = new Date();
    return db.select().from(postQueue)
      .where(and(
        eq(postQueue.status, "pending"),
        lte(postQueue.scheduledFor, now)
      ))
      .orderBy(postQueue.priority)
      .limit(limit);
  }

  async createPostQueue(post: InsertPostQueue): Promise<PostQueue> {
    const [created] = await db.insert(postQueue).values(post).returning();
    return created;
  }

  async updatePostQueue(id: string, post: Partial<PostQueue>): Promise<PostQueue | undefined> {
    const [updated] = await db.update(postQueue).set(post).where(eq(postQueue.id, id)).returning();
    return updated;
  }

  async deletePostQueue(id: string): Promise<boolean> {
    await db.delete(postQueue).where(eq(postQueue.id, id));
    return true;
  }

  // Notification Settings
  async getNotificationSettings(): Promise<NotificationSettings | undefined> {
    const [settings] = await db.select().from(notificationSettings).limit(1);
    return settings;
  }

  async upsertNotificationSettings(settings: InsertNotificationSettings): Promise<NotificationSettings> {
    const existing = await this.getNotificationSettings();
    if (existing) {
      const [updated] = await db.update(notificationSettings)
        .set({ ...settings, updatedAt: new Date() })
        .where(eq(notificationSettings.id, existing.id))
        .returning();
      return updated;
    }
    const [created] = await db.insert(notificationSettings).values(settings).returning();
    return created;
  }

  // Notifications
  async getNotifications(limit: number = 50): Promise<Notification[]> {
    return db.select().from(notifications).orderBy(desc(notifications.sentAt)).limit(limit);
  }

  async getUnreadNotifications(): Promise<Notification[]> {
    return db.select().from(notifications)
      .where(eq(notifications.isRead, false))
      .orderBy(desc(notifications.sentAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [created] = await db.insert(notifications).values(notification).returning();
    return created;
  }

  async markNotificationRead(id: string): Promise<boolean> {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
    return true;
  }

  async markAllNotificationsRead(): Promise<boolean> {
    await db.update(notifications).set({ isRead: true });
    return true;
  }

  // A/B Test Variants
  async getAllAbTestVariants(): Promise<AbTestVariant[]> {
    return db.select().from(abTestVariants)
      .orderBy(desc(abTestVariants.conversionRate));
  }

  async getAbTestVariants(campaignId: string): Promise<AbTestVariant[]> {
    return db.select().from(abTestVariants)
      .where(eq(abTestVariants.campaignId, campaignId))
      .orderBy(desc(abTestVariants.conversionRate));
  }

  async createAbTestVariant(variant: InsertAbTestVariant): Promise<AbTestVariant> {
    const [created] = await db.insert(abTestVariants).values(variant).returning();
    return created;
  }

  async updateAbTestVariant(id: string, variant: Partial<AbTestVariant>): Promise<AbTestVariant | undefined> {
    const [updated] = await db.update(abTestVariants).set(variant).where(eq(abTestVariants.id, id)).returning();
    return updated;
  }

  async deleteAbTestVariant(id: string): Promise<boolean> {
    await db.delete(abTestVariants).where(eq(abTestVariants.id, id));
    return true;
  }

  // Post Templates
  async getPostTemplates(platform?: string): Promise<PostTemplate[]> {
    if (platform) {
      return db.select().from(postTemplates)
        .where(eq(postTemplates.platform, platform))
        .orderBy(desc(postTemplates.conversionRate));
    }
    return db.select().from(postTemplates).orderBy(desc(postTemplates.conversionRate));
  }

  async getPostTemplate(id: string): Promise<PostTemplate | undefined> {
    const [template] = await db.select().from(postTemplates).where(eq(postTemplates.id, id));
    return template;
  }

  async createPostTemplate(template: InsertPostTemplate): Promise<PostTemplate> {
    const [created] = await db.insert(postTemplates).values(template).returning();
    return created;
  }

  async updatePostTemplate(id: string, template: Partial<InsertPostTemplate>): Promise<PostTemplate | undefined> {
    const [updated] = await db.update(postTemplates).set(template).where(eq(postTemplates.id, id)).returning();
    return updated;
  }

  async deletePostTemplate(id: string): Promise<boolean> {
    await db.delete(postTemplates).where(eq(postTemplates.id, id));
    return true;
  }

  async incrementTemplateUsage(id: string): Promise<void> {
    await db.update(postTemplates)
      .set({ usageCount: sql`${postTemplates.usageCount} + 1` })
      .where(eq(postTemplates.id, id));
  }

  // Analytics Snapshots
  async getAnalyticsSnapshots(days: number = 30): Promise<AnalyticsSnapshot[]> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    return db.select().from(analyticsSnapshots)
      .where(gte(analyticsSnapshots.date, startDate))
      .orderBy(desc(analyticsSnapshots.date));
  }

  async createAnalyticsSnapshot(snapshot: InsertAnalyticsSnapshot): Promise<AnalyticsSnapshot> {
    const [created] = await db.insert(analyticsSnapshots).values(snapshot).returning();
    return created;
  }

  async getTodaySnapshot(): Promise<AnalyticsSnapshot | undefined> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const [snapshot] = await db.select().from(analyticsSnapshots)
      .where(gte(analyticsSnapshots.date, today))
      .limit(1);
    return snapshot;
  }

  // Rate Limits
  async getRateLimit(accountId: string): Promise<RateLimit | undefined> {
    const [limit] = await db.select().from(rateLimits).where(eq(rateLimits.accountId, accountId));
    return limit;
  }

  async getRateLimits(): Promise<RateLimit[]> {
    return db.select().from(rateLimits);
  }

  async upsertRateLimit(limit: InsertRateLimit): Promise<RateLimit> {
    if (limit.accountId) {
      const existing = await this.getRateLimit(limit.accountId);
      if (existing) {
        const [updated] = await db.update(rateLimits)
          .set(limit)
          .where(eq(rateLimits.id, existing.id))
          .returning();
        return updated;
      }
    }
    const [created] = await db.insert(rateLimits).values(limit).returning();
    return created;
  }

  async incrementPostCount(accountId: string): Promise<void> {
    await db.update(rateLimits)
      .set({
        postsToday: sql`${rateLimits.postsToday} + 1`,
        postsThisHour: sql`${rateLimits.postsThisHour} + 1`,
        lastPostAt: new Date(),
      })
      .where(eq(rateLimits.accountId, accountId));
  }

  async resetDailyLimits(): Promise<void> {
    await db.update(rateLimits).set({ postsToday: 0, resetAt: new Date() });
  }

  async resetHourlyLimits(): Promise<void> {
    await db.update(rateLimits).set({ postsThisHour: 0 });
  }

  // Sales Tracking
  async getSalesTracking(networkId?: string): Promise<SalesTracking[]> {
    if (networkId) {
      return db.select().from(salesTracking)
        .where(eq(salesTracking.networkId, networkId))
        .orderBy(desc(salesTracking.saleDate));
    }
    return db.select().from(salesTracking).orderBy(desc(salesTracking.saleDate));
  }

  async createSalesTracking(sale: InsertSalesTracking): Promise<SalesTracking> {
    const [created] = await db.insert(salesTracking).values(sale).returning();
    
    await this.createNotification({
      type: "sale",
      title: "New Sale! 💰",
      message: `You earned $${sale.commission} from a sale!`,
      data: JSON.stringify(sale),
    });
    
    return created;
  }

  async getUnnotifiedSales(): Promise<SalesTracking[]> {
    return db.select().from(salesTracking)
      .where(eq(salesTracking.isNotified, false))
      .orderBy(desc(salesTracking.saleDate));
  }

  async markSaleNotified(id: string): Promise<void> {
    await db.update(salesTracking).set({ isNotified: true }).where(eq(salesTracking.id, id));
  }

  async getSalesToday(): Promise<{ count: number; total: string }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const [result] = await db.select({
      count: sql<number>`COUNT(*)`,
      total: sql<string>`COALESCE(SUM(${salesTracking.commission}), 0)`,
    }).from(salesTracking)
      .where(gte(salesTracking.saleDate, today));
    return result || { count: 0, total: "0" };
  }

  async getDuplicateCampaign(id: string): Promise<Campaign | undefined> {
    const original = await this.getCampaign(id);
    if (!original) return undefined;
    
    const duplicate = await this.createCampaign({
      name: `${original.name} (Copy)`,
      productId: original.productId,
      socialAccountId: original.socialAccountId,
      postContent: original.postContent,
      hashtags: original.hashtags,
      scheduledTime: null,
      status: "draft",
    });
    
    return duplicate;
  }

  // Blog Posts
  async getBlogPosts(status?: string): Promise<BlogPost[]> {
    if (status) {
      return db.select().from(blogPosts)
        .where(eq(blogPosts.status, status))
        .orderBy(desc(blogPosts.publishedAt));
    }
    return db.select().from(blogPosts).orderBy(desc(blogPosts.publishedAt));
  }

  async getBlogPost(id: string): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, id));
    return post;
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug));
    return post;
  }

  async createBlogPost(post: InsertBlogPost): Promise<BlogPost> {
    const [created] = await db.insert(blogPosts).values(post).returning();
    return created;
  }

  async updateBlogPost(id: string, post: Partial<InsertBlogPost>): Promise<BlogPost | undefined> {
    const [updated] = await db.update(blogPosts)
      .set({ ...post, updatedAt: new Date() })
      .where(eq(blogPosts.id, id))
      .returning();
    return updated;
  }

  async deleteBlogPost(id: string): Promise<boolean> {
    const result = await db.delete(blogPosts).where(eq(blogPosts.id, id));
    return true;
  }

  async incrementBlogViews(id: string): Promise<void> {
    await db.update(blogPosts)
      .set({ viewCount: sql`${blogPosts.viewCount} + 1` })
      .where(eq(blogPosts.id, id));
  }

  async incrementBlogClicks(id: string): Promise<void> {
    await db.update(blogPosts)
      .set({ clickCount: sql`${blogPosts.clickCount} + 1` })
      .where(eq(blogPosts.id, id));
  }

  async getPublishedBlogPosts(): Promise<BlogPost[]> {
    return db.select().from(blogPosts)
      .where(eq(blogPosts.status, "published"))
      .orderBy(desc(blogPosts.publishedAt));
  }

  // Content Queue
  async getContentQueue(status?: string): Promise<ContentQueue[]> {
    if (status) {
      return db.select().from(contentQueue)
        .where(eq(contentQueue.status, status))
        .orderBy(desc(contentQueue.priority));
    }
    return db.select().from(contentQueue).orderBy(desc(contentQueue.priority));
  }

  async createContentQueueItem(item: InsertContentQueue): Promise<ContentQueue> {
    const [created] = await db.insert(contentQueue).values(item).returning();
    return created;
  }

  async updateContentQueueItem(id: string, item: Partial<ContentQueue>): Promise<ContentQueue | undefined> {
    const [updated] = await db.update(contentQueue)
      .set(item)
      .where(eq(contentQueue.id, id))
      .returning();
    return updated;
  }

  async getPendingContentQueue(): Promise<ContentQueue[]> {
    const now = new Date();
    return db.select().from(contentQueue)
      .where(and(
        eq(contentQueue.status, "pending"),
        lte(contentQueue.scheduledFor, now)
      ))
      .orderBy(desc(contentQueue.priority));
  }

  // Customer Purchases
  async createCustomerPurchase(purchase: InsertCustomerPurchase): Promise<CustomerPurchase> {
    const [created] = await db.insert(customerPurchases).values(purchase).returning();
    return created;
  }

  async getCustomerPurchaseByTransaction(transactionId: string): Promise<CustomerPurchase | undefined> {
    const [purchase] = await db.select().from(customerPurchases)
      .where(eq(customerPurchases.transactionId, transactionId));
    return purchase;
  }

  async getCustomerPurchaseByToken(token: string): Promise<CustomerPurchase | undefined> {
    const [purchase] = await db.select().from(customerPurchases)
      .where(eq(customerPurchases.accessToken, token));
    return purchase;
  }

  async getCustomerPurchases(): Promise<CustomerPurchase[]> {
    return db.select().from(customerPurchases).orderBy(desc(customerPurchases.purchasedAt));
  }

  async incrementDownloadCount(id: string): Promise<void> {
    await db.update(customerPurchases)
      .set({ downloadCount: sql`${customerPurchases.downloadCount} + 1` })
      .where(eq(customerPurchases.id, id));
  }

  async deleteCustomerPurchase(id: string): Promise<boolean> {
    const result = await db.delete(customerPurchases)
      .where(eq(customerPurchases.id, id))
      .returning();
    return result.length > 0;
  }

  // Support Tickets
  async createSupportTicket(ticket: InsertSupportTicket): Promise<SupportTicket> {
    const [created] = await db.insert(supportTickets).values(ticket).returning();
    return created;
  }

  async getSupportTicket(id: string): Promise<SupportTicket | undefined> {
    const [ticket] = await db.select().from(supportTickets).where(eq(supportTickets.id, id));
    return ticket;
  }

  async getSupportTickets(status?: string): Promise<SupportTicket[]> {
    if (status) {
      return db.select().from(supportTickets)
        .where(eq(supportTickets.status, status))
        .orderBy(desc(supportTickets.createdAt));
    }
    return db.select().from(supportTickets).orderBy(desc(supportTickets.createdAt));
  }

  async updateSupportTicket(id: string, ticket: Partial<SupportTicket>): Promise<SupportTicket | undefined> {
    const [updated] = await db.update(supportTickets)
      .set(ticket)
      .where(eq(supportTickets.id, id))
      .returning();
    return updated;
  }

  async getOpenTicketsByEmail(email: string): Promise<SupportTicket[]> {
    return db.select().from(supportTickets)
      .where(and(
        eq(supportTickets.customerEmail, email),
        eq(supportTickets.status, "open")
      ))
      .orderBy(desc(supportTickets.createdAt));
  }

  // Support Messages
  async createSupportMessage(message: InsertSupportMessage): Promise<SupportMessage> {
    const [created] = await db.insert(supportMessages).values(message).returning();
    return created;
  }

  async getTicketMessages(ticketId: string): Promise<SupportMessage[]> {
    return db.select().from(supportMessages)
      .where(eq(supportMessages.ticketId, ticketId))
      .orderBy(supportMessages.createdAt);
  }
}

export const storage = new DatabaseStorage();
