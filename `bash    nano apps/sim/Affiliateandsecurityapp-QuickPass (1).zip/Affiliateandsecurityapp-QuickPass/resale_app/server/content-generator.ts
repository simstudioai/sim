import { storage } from "./storage";
import type { MarketplaceProduct, BlogPost, InsertBlogPost } from "@shared/schema";

const REVIEW_TEMPLATES = [
  {
    style: "comprehensive",
    generateTitle: (product: MarketplaceProduct) => 
      `${product.name} Review 2024: Is It Worth Your Money?`,
    generateContent: (product: MarketplaceProduct) => `
# ${product.name} Review: An Honest In-Depth Analysis

Are you looking for a solution in the **${product.category || 'health and wellness'}** space? You've probably come across **${product.name}**. In this comprehensive review, we'll break down everything you need to know before making a purchase.

## What is ${product.name}?

${product.description || `${product.name} is a digital product designed to help you achieve your goals. It has been gaining popularity in the online marketplace.`}

## Key Benefits

Based on our research, here are the main benefits users report:

- **Easy to Follow**: The program is designed for beginners and experts alike
- **Comprehensive Coverage**: Addresses multiple aspects of the topic
- **Money-Back Guarantee**: Protected by ClickBank's 60-day refund policy
- **Instant Access**: Download and start immediately after purchase

## Who Is This For?

${product.name} is ideal for:
- People looking for proven solutions
- Those who prefer self-paced learning
- Anyone seeking expert guidance without the high cost of consultants

## Pricing

The current price is **$${product.initialPrice || '47'}**, which includes:
- Full access to the main program
- Bonus materials (if available)
- 60-day money-back guarantee through ClickBank

## Our Verdict

After thorough research, we believe ${product.name} offers good value for those serious about achieving results. The ClickBank guarantee means you can try it risk-free.

**Rating: 4.5/5 Stars**

Ready to get started? [Click here to learn more and get instant access](AFFILIATE_LINK)
    `.trim(),
  },
  {
    style: "comparison",
    generateTitle: (product: MarketplaceProduct) => 
      `${product.name}: The Complete Buyer's Guide [Updated 2024]`,
    generateContent: (product: MarketplaceProduct) => `
# ${product.name}: Everything You Need to Know

Looking for honest information about **${product.name}**? You've come to the right place. We've researched this product thoroughly to help you make an informed decision.

## Quick Overview

| Feature | Details |
|---------|---------|
| Product Name | ${product.name} |
| Category | ${product.category || 'Digital Product'} |
| Price | $${product.initialPrice || '47'} |
| Refund Policy | 60 Days |
| Platform | ClickBank |

## What Makes ${product.name} Different?

${product.description || `This product stands out in the crowded marketplace by focusing on delivering real results.`}

### Pros:
- ✅ Backed by ClickBank's buyer protection
- ✅ Instant digital delivery
- ✅ Comprehensive training materials
- ✅ Active customer support

### Cons:
- ❌ Digital-only (no physical products)
- ❌ Requires commitment to see results

## Is It Worth the Investment?

At $${product.initialPrice || '47'}, ${product.name} is competitively priced. With the 60-day money-back guarantee, there's minimal risk in trying it out.

## Final Recommendation

We recommend ${product.name} for anyone serious about getting results in this area. The combination of quality content and buyer protection makes it a solid choice.

[**Click Here to Get ${product.name} →**](AFFILIATE_LINK)
    `.trim(),
  },
  {
    style: "benefits",
    generateTitle: (product: MarketplaceProduct) => 
      `Why ${product.name} Is Getting So Much Attention in 2024`,
    generateContent: (product: MarketplaceProduct) => `
# Discover Why Thousands Are Choosing ${product.name}

In the world of **${product.category || 'digital products'}**, finding something that actually works can be challenging. That's why ${product.name} has been generating buzz.

## The Problem Most People Face

Let's be honest - there's a lot of hype out there. Most products promise the world but deliver very little. That's what makes ${product.name} different.

## How ${product.name} Solves This

${product.description || `This program takes a practical, results-focused approach that has helped many users achieve their goals.`}

### Key Features:

**1. Step-by-Step Guidance**
No more guessing. Get clear instructions that anyone can follow.

**2. Proven Methods**
Based on approaches that have worked for others.

**3. Full Support**
Access to resources and materials whenever you need them.

**4. Risk-Free Trial**
Protected by a 60-day money-back guarantee.

## What Real Users Are Saying

Users appreciate the straightforward approach and practical advice. The consensus is that ${product.name} delivers on its promises.

## Getting Started

Ready to see what ${product.name} can do for you?

**Special Offer**: Get instant access today for just $${product.initialPrice || '47'}

[**Yes! I Want to Get Started →**](AFFILIATE_LINK)

*Your purchase is protected by ClickBank's 60-day refund policy.*
    `.trim(),
  },
];

function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .substring(0, 80);
}

function generateExcerpt(content: string): string {
  const plainText = content
    .replace(/#+\s/g, '')
    .replace(/\*\*/g, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/\n+/g, ' ')
    .trim();
  return plainText.substring(0, 200) + '...';
}

function generateKeywords(product: MarketplaceProduct): string[] {
  const baseKeywords = [
    product.name.toLowerCase(),
    `${product.name} review`,
    `${product.name} reviews`,
    `buy ${product.name}`,
    `${product.name} discount`,
  ];
  
  if (product.category) {
    baseKeywords.push(product.category.toLowerCase());
    baseKeywords.push(`best ${product.category.toLowerCase()}`);
  }
  
  return baseKeywords;
}

export async function generateBlogPostForProduct(product: MarketplaceProduct): Promise<BlogPost> {
  const template = REVIEW_TEMPLATES[Math.floor(Math.random() * REVIEW_TEMPLATES.length)];
  
  const title = template.generateTitle(product);
  let content = template.generateContent(product);
  
  content = content.replace(/\(AFFILIATE_LINK\)/g, `(${product.hopLink || '#'})`);
  
  const slug = generateSlug(title);
  const excerpt = generateExcerpt(content);
  const keywords = generateKeywords(product);
  
  const blogPost: InsertBlogPost = {
    productId: product.id,
    title,
    slug,
    content,
    excerpt,
    metaTitle: `${title} | Trusted Reviews`,
    metaDescription: excerpt.substring(0, 160),
    keywords,
    category: product.category || 'Product Reviews',
    affiliateLink: product.hopLink || null,
    status: 'draft',
    publishedAt: null,
  };
  
  const created = await storage.createBlogPost(blogPost);
  
  await storage.createActivityLog({
    action: "blog_post_generated",
    category: "content",
    details: `Auto-generated review for ${product.name}`,
    severity: "info",
  });
  
  return created;
}

export async function processContentQueue(): Promise<{ processed: number; errors: string[] }> {
  const pendingItems = await storage.getPendingContentQueue();
  let processed = 0;
  const errors: string[] = [];
  
  for (const item of pendingItems) {
    try {
      await storage.updateContentQueueItem(item.id, {
        status: "processing",
        attempts: (item.attempts || 0) + 1,
      });
      
      if (!item.productId) {
        throw new Error("No product ID specified");
      }
      
      const product = await storage.getMarketplaceProduct(item.productId);
      if (!product) {
        throw new Error(`Product ${item.productId} not found`);
      }
      
      const existingPosts = await storage.getBlogPosts();
      const alreadyExists = existingPosts.some(p => p.productId === item.productId);
      
      if (alreadyExists) {
        await storage.updateContentQueueItem(item.id, {
          status: "skipped",
          lastError: "Blog post already exists for this product",
          processedAt: new Date(),
        });
        continue;
      }
      
      const blogPost = await generateBlogPostForProduct(product);
      
      await storage.updateContentQueueItem(item.id, {
        status: "completed",
        generatedBlogId: blogPost.id,
        processedAt: new Date(),
      });
      
      processed++;
      console.log(`[CONTENT] Generated blog post: ${blogPost.title}`);
      
    } catch (error: any) {
      const errorMsg = error.message || String(error);
      errors.push(`Item ${item.id}: ${errorMsg}`);
      
      if ((item.attempts || 0) >= 3) {
        await storage.updateContentQueueItem(item.id, {
          status: "failed",
          lastError: errorMsg,
        });
      } else {
        await storage.updateContentQueueItem(item.id, {
          status: "pending",
          lastError: errorMsg,
        });
      }
    }
  }
  
  return { processed, errors };
}

export async function autoGenerateContent(): Promise<void> {
  console.log("[CONTENT] Running auto-generation...");
  
  const products = await storage.getMarketplaceProducts();
  const activeProducts = products.filter(p => p.isPromoting && p.hopLink);
  
  const existingPosts = await storage.getBlogPosts();
  const existingProductIds = new Set(existingPosts.map(p => p.productId));
  
  const needsContent = activeProducts.filter(p => !existingProductIds.has(p.id));
  
  console.log(`[CONTENT] Found ${needsContent.length} products needing content`);
  
  for (const product of needsContent.slice(0, 5)) {
    try {
      const blogPost = await generateBlogPostForProduct(product);
      console.log(`[CONTENT] Generated: ${blogPost.title}`);
      
      await storage.updateBlogPost(blogPost.id, {
        status: "published",
        publishedAt: new Date(),
      });
      
      console.log(`[CONTENT] Auto-published: ${blogPost.title}`);
    } catch (error: any) {
      console.error(`[CONTENT] Failed to generate for ${product.name}:`, error.message);
    }
  }
}

export async function getContentStats(): Promise<{
  totalPosts: number;
  publishedPosts: number;
  draftPosts: number;
  totalViews: number;
  totalClicks: number;
  pendingQueue: number;
}> {
  const posts = await storage.getBlogPosts();
  const queue = await storage.getContentQueue("pending");
  
  return {
    totalPosts: posts.length,
    publishedPosts: posts.filter(p => p.status === "published").length,
    draftPosts: posts.filter(p => p.status === "draft").length,
    totalViews: posts.reduce((sum, p) => sum + (p.viewCount || 0), 0),
    totalClicks: posts.reduce((sum, p) => sum + (p.clickCount || 0), 0),
    pendingQueue: queue.length,
  };
}
