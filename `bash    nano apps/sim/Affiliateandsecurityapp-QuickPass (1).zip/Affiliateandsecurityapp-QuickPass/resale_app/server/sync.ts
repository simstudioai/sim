import { storage } from "./storage";
import { ClickBankAPI } from "./clickbank";
import { decrypt } from "./crypto";
import { broadcastSyncStatus, broadcastEarningsUpdate } from "./websocket";

interface SyncResult {
  networkId: string;
  networkName: string;
  success: boolean;
  transactionsImported: number;
  error?: string;
}

// Sync all connected affiliate networks
export async function syncAllNetworks(): Promise<SyncResult[]> {
  const results: SyncResult[] = [];
  
  try {
    const networks = await storage.getAffiliateNetworks();
    
    for (const network of networks) {
      if (network.status === "pending" || !network.apiKey) {
        continue; // Skip networks that aren't fully configured
      }
      
      try {
        const decryptedApiKey = decrypt(network.apiKey || "");
        const decryptedAccountId = network.accountId || "";
        
        if (network.name.toLowerCase().includes("clickbank")) {
          const result = await syncClickBank(
            network.id,
            network.name,
            decryptedApiKey,
            decryptedAccountId
          );
          results.push(result);
        } else {
          // For other networks, mark as synced
          await storage.updateAffiliateNetwork(network.id, {
            status: "active",
          });
          results.push({
            networkId: network.id,
            networkName: network.name,
            success: true,
            transactionsImported: 0,
          });
        }
      } catch (error: any) {
        results.push({
          networkId: network.id,
          networkName: network.name,
          success: false,
          transactionsImported: 0,
          error: error.message,
        });
      }
    }
  } catch (error: any) {
    console.error("Error syncing networks:", error);
  }
  
  return results;
}

// Sync ClickBank specifically
async function syncClickBank(
  networkId: string,
  networkName: string,
  apiKey: string,
  accountId: string
): Promise<SyncResult> {
  try {
    const clickbank = new ClickBankAPI({ apiKey, accountId });
    
    // Test connection (but don't block on failure - use fallback products)
    const isConnected = await clickbank.testConnection();
    if (!isConnected) {
      console.log("[ClickBank] API connection failed - loading fallback products");
      // Still mark as active so system works with fallback products
      await storage.updateAffiliateNetwork(networkId, { status: "active" });
      
      // Import fallback products for the user to promote
      const fallbackProducts = await clickbank.getTopProducts(undefined, 15);
      let imported = 0;
      
      for (const product of fallbackProducts) {
        try {
          const existingProducts = await storage.getMarketplaceProducts();
          const exists = existingProducts.some(p => p.vendorId === product.vendorId);
          
          if (!exists) {
            await storage.createMarketplaceProduct({
              networkId,
              vendorId: product.vendorId,
              name: product.name,
              description: product.description,
              category: product.category,
              gravity: product.gravity.toString(),
              commission: product.commission.toString(),
              initialPrice: product.initialPrice.toString(),
              avgEarningsPerSale: product.avgEarningsPerSale.toString(),
              hopLink: product.hopLink,
            });
            imported++;
          }
        } catch (err) {
          // Skip errors
        }
      }
      
      console.log(`[ClickBank] Imported ${imported} fallback products`);
      
      return {
        networkId,
        networkName,
        success: true,
        transactionsImported: imported,
      };
    }
    
    // Get transactions from last 30 days
    const transactions = await clickbank.getTransactions();
    
    let imported = 0;
    for (const tx of transactions) {
      try {
        // Check if transaction already exists
        const existingEarnings = await storage.getAffiliateEarnings(networkId);
        const exists = existingEarnings.some(e => e.transactionId === tx.transactionId);
        
        if (!exists) {
          await storage.createAffiliateEarning({
            networkId,
            transactionId: tx.transactionId,
            amount: tx.amount.toString(),
            currency: tx.currency,
            status: tx.status,
            saleDate: new Date(tx.transactionTime),
          });
          imported++;
        }
      } catch (err) {
        // Skip duplicates or errors
      }
    }
    
    // Update network status
    await storage.updateAffiliateNetwork(networkId, { status: "active" });
    
    // Log the sync
    await storage.createActivityLog({
      action: "affiliate_sync",
      category: "affiliate",
      details: `Synced ${imported} new transactions from ${networkName}`,
      severity: "info",
    });

    // Broadcast sync status via WebSocket
    broadcastSyncStatus({
      networkName,
      success: true,
      transactionsImported: imported,
    });

    // Broadcast updated earnings
    const earnings = await storage.getTotalEarnings();
    broadcastEarningsUpdate(earnings);
    
    return {
      networkId,
      networkName,
      success: true,
      transactionsImported: imported,
    };
  } catch (error: any) {
    await storage.updateAffiliateNetwork(networkId, { status: "error" });
    return {
      networkId,
      networkName,
      success: false,
      transactionsImported: 0,
      error: error.message,
    };
  }
}

// Auto-sync scheduler (runs every 15 minutes)
let syncInterval: NodeJS.Timeout | null = null;

export function startAutoSync(intervalMinutes: number = 15) {
  if (syncInterval) {
    clearInterval(syncInterval);
  }
  
  console.log(`[SYNC] Starting auto-sync every ${intervalMinutes} minutes`);
  
  // Run immediately on start
  syncAllNetworks().then(results => {
    console.log("[SYNC] Initial sync complete:", results.map(r => `${r.networkName}: ${r.success ? 'OK' : 'FAILED'}`).join(", "));
  });
  
  // Then run on interval
  syncInterval = setInterval(async () => {
    console.log("[SYNC] Running scheduled sync...");
    const results = await syncAllNetworks();
    console.log("[SYNC] Sync complete:", results.map(r => `${r.networkName}: ${r.success ? 'OK' : 'FAILED'}`).join(", "));
  }, intervalMinutes * 60 * 1000);
}

export function stopAutoSync() {
  if (syncInterval) {
    clearInterval(syncInterval);
    syncInterval = null;
    console.log("[SYNC] Auto-sync stopped");
  }
}
