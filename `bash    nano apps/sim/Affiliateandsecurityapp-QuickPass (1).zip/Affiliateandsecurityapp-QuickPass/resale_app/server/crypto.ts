import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from "crypto";

const ALGORITHM = "aes-256-gcm";
const KEY_LENGTH = 32;
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;
const SALT_LENGTH = 32;

// Derive encryption key from a master secret
function getEncryptionKey(): Buffer {
  const masterSecret = process.env.ENCRYPTION_SECRET || process.env.DATABASE_URL || "default-dev-secret-change-in-production";
  const salt = Buffer.from("privately-security-salt", "utf8");
  return scryptSync(masterSecret, salt, KEY_LENGTH);
}

// Encrypt sensitive data (API keys, secrets)
export function encrypt(plaintext: string): string {
  if (!plaintext) return "";
  
  const key = getEncryptionKey();
  const iv = randomBytes(IV_LENGTH);
  const cipher = createCipheriv(ALGORITHM, key, iv);
  
  let encrypted = cipher.update(plaintext, "utf8", "hex");
  encrypted += cipher.final("hex");
  
  const authTag = cipher.getAuthTag();
  
  // Return format: iv:authTag:encryptedData
  return `${iv.toString("hex")}:${authTag.toString("hex")}:${encrypted}`;
}

// Decrypt sensitive data
export function decrypt(encryptedData: string): string {
  if (!encryptedData || !encryptedData.includes(":")) return encryptedData;
  
  try {
    const [ivHex, authTagHex, encrypted] = encryptedData.split(":");
    
    if (!ivHex || !authTagHex || !encrypted) return "";
    
    const key = getEncryptionKey();
    const iv = Buffer.from(ivHex, "hex");
    const authTag = Buffer.from(authTagHex, "hex");
    
    const decipher = createDecipheriv(ALGORITHM, key, iv);
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted, "hex", "utf8");
    decrypted += decipher.final("utf8");
    
    return decrypted;
  } catch (error) {
    console.error("Decryption failed:", error);
    return "";
  }
}

// Mask sensitive data for display (show only last 4 characters)
export function maskSecret(secret: string): string {
  if (!secret || secret.length < 8) return "••••••••";
  return "••••••••" + secret.slice(-4);
}

// Hash data for secure comparison (not reversible)
export function hashData(data: string): string {
  const key = getEncryptionKey();
  const cipher = createCipheriv("aes-256-cbc", key, Buffer.alloc(16, 0));
  let hashed = cipher.update(data, "utf8", "hex");
  hashed += cipher.final("hex");
  return hashed.slice(0, 64);
}
