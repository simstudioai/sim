import { storage } from "./storage";

const defaultTemplates = [
  {
    name: "Product Review Hook",
    platform: "twitter",
    category: "review",
    content: "🔥 Just tried {{product_name}} and WOW!\n\nHere's what surprised me:\n- {{benefit_1}}\n- {{benefit_2}}\n- {{benefit_3}}\n\nFull review: {{link}}",
    hashtags: ["review", "recommended", "musthave"],
    isBuiltIn: true,
  },
  {
    name: "Problem/Solution",
    platform: "twitter",
    category: "direct",
    content: "Struggling with {{problem}}?\n\n{{product_name}} helped me:\n✅ {{solution_1}}\n✅ {{solution_2}}\n\nGet it here: {{link}}",
    hashtags: ["solution", "gamechanger", "helpful"],
    isBuiltIn: true,
  },
  {
    name: "Social Proof",
    platform: "twitter",
    category: "social_proof",
    content: "Over {{number}} people are already using {{product_name}} 📈\n\nWhy? Because it actually works.\n\n👉 {{link}}",
    hashtags: ["trending", "popular", "musttry"],
    isBuiltIn: true,
  },
  {
    name: "Instagram Story Post",
    platform: "instagram",
    category: "story",
    content: "📢 NEW DISCOVERY!\n\n{{product_name}}\n\n{{description}}\n\n💫 {{main_benefit}}\n\n🔗 Link in bio!\n\n.",
    hashtags: ["newproduct", "recommended", "lifestyle", "instagood", "fyp"],
    isBuiltIn: true,
  },
  {
    name: "Before/After",
    platform: "instagram",
    category: "transformation",
    content: "Before {{product_name}}:\n❌ {{problem_1}}\n❌ {{problem_2}}\n\nAfter:\n✅ {{benefit_1}}\n✅ {{benefit_2}}\n\n👉 Link in bio!",
    hashtags: ["transformation", "beforeafter", "results", "motivation"],
    isBuiltIn: true,
  },
  {
    name: "Educational Value",
    platform: "facebook",
    category: "educational",
    content: "📚 Did you know?\n\n{{interesting_fact}}\n\nThat's why {{product_name}} is so effective!\n\n🔗 Learn more: {{link}}\n\n.",
    hashtags: ["education", "didyouknow", "learnmore"],
    isBuiltIn: true,
  },
  {
    name: "Personal Story",
    platform: "facebook",
    category: "storytelling",
    content: "I was skeptical at first...\n\nBut after trying {{product_name}} for {{time_period}}, I can honestly say it changed {{what_changed}}.\n\nHere's my experience:\n{{experience}}\n\n👉 {{link}}",
    hashtags: ["mystory", "honest", "review"],
    isBuiltIn: true,
  },
  {
    name: "TikTok POV",
    platform: "tiktok",
    category: "pov",
    content: "POV: You just discovered {{product_name}} 🤯\n\n{{short_benefit}}\n\n🔗 Link in bio",
    hashtags: ["fyp", "viral", "pov", "musthave", "trending"],
    isBuiltIn: true,
  },
  {
    name: "TikTok Duet Style",
    platform: "tiktok",
    category: "duet",
    content: "Wait... is this actually real?! 😱\n\n{{product_name}} = {{result}}\n\nLink in bio 👆",
    hashtags: ["fyp", "duet", "viral", "trending", "musttry"],
    isBuiltIn: true,
  },
  {
    name: "YouTube Description",
    platform: "youtube",
    category: "description",
    content: "🎯 {{product_name}} Review\n\nIn this video, I'm sharing my honest experience with {{product_name}}.\n\n📌 What's covered:\n- {{point_1}}\n- {{point_2}}\n- {{point_3}}\n\n🔗 Get it here: {{link}}\n\n.",
    hashtags: ["review", "honest", "productreview"],
    isBuiltIn: true,
  },
  {
    name: "Limited Time Offer",
    platform: "twitter",
    category: "urgency",
    content: "⚠️ LIMITED TIME ⚠️\n\n{{product_name}} is {{discount}}% off right now!\n\nDon't miss this: {{link}}\n\nEnds {{deadline}}",
    hashtags: ["limitedtime", "sale", "discount", "deal"],
    isBuiltIn: true,
  },
  {
    name: "Comparison Post",
    platform: "facebook",
    category: "comparison",
    content: "{{product_name}} vs The Competition:\n\n✅ {{advantage_1}}\n✅ {{advantage_2}}\n✅ {{advantage_3}}\n\nWinner? {{product_name}} 🏆\n\n👉 {{link}}",
    hashtags: ["comparison", "best", "winner"],
    isBuiltIn: true,
  },
];

export async function seedDefaultTemplates() {
  try {
    const existingTemplates = await storage.getPostTemplates();
    const builtInCount = existingTemplates.filter(t => t.isBuiltIn).length;
    
    if (builtInCount >= defaultTemplates.length) {
      console.log("[SEED] Templates already seeded");
      return;
    }
    
    console.log("[SEED] Seeding default templates...");
    
    for (const template of defaultTemplates) {
      const exists = existingTemplates.some(
        t => t.name === template.name && t.platform === template.platform
      );
      
      if (!exists) {
        await storage.createPostTemplate(template);
        console.log(`[SEED] Created template: ${template.name}`);
      }
    }
    
    console.log("[SEED] Template seeding complete");
  } catch (error) {
    console.error("[SEED] Error seeding templates:", error);
  }
}
