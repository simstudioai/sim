import { WebSocketServer, WebSocket } from "ws";
import { Server } from "http";

let wss: WebSocketServer | null = null;
const clients: Set<WebSocket> = new Set();

export function setupWebSocket(server: Server) {
  wss = new WebSocketServer({ server, path: "/ws" });

  wss.on("connection", (ws) => {
    clients.add(ws);
    console.log("[WS] Client connected. Total clients:", clients.size);

    ws.send(JSON.stringify({ type: "connected", message: "Real-time updates enabled" }));

    ws.on("close", () => {
      clients.delete(ws);
      console.log("[WS] Client disconnected. Total clients:", clients.size);
    });

    ws.on("error", (error) => {
      console.error("[WS] Client error:", error);
      clients.delete(ws);
    });
  });

  console.log("[WS] WebSocket server initialized");
}

export function broadcast(event: {
  type: string;
  data?: any;
  message?: string;
}) {
  if (!wss || clients.size === 0) return;
  
  const message = JSON.stringify(event);
  
  clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

export function broadcastEarningsUpdate(earnings: {
  total: string;
  pending: string;
  paid: string;
  newTransaction?: any;
}) {
  broadcast({
    type: "earnings_update",
    data: earnings,
    message: "Earnings data updated",
  });
}

export function broadcastSyncStatus(status: {
  networkName: string;
  success: boolean;
  transactionsImported: number;
}) {
  broadcast({
    type: "sync_complete",
    data: status,
    message: `Synced ${status.networkName}: ${status.transactionsImported} new transactions`,
  });
}

export function broadcastSecurityAlert(alert: {
  severity: "info" | "warning" | "critical";
  title: string;
  message: string;
}) {
  broadcast({
    type: "security_alert",
    data: alert,
  });
}
