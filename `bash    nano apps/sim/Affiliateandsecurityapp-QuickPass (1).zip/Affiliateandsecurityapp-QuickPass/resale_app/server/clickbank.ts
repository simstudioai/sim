// ClickBank API Integration
// Documentation: https://api.clickbank.com/rest/1.3/

interface ClickBankConfig {
  apiKey: string;
  accountId: string;
}

interface ClickBankTransaction {
  transactionId: string;
  transactionTime: string;
  amount: number;
  currency: string;
  productName: string;
  status: string;
}

interface ClickBankAnalytics {
  totalSales: number;
  totalRevenue: number;
  refundRate: number;
  averageOrderValue: number;
}

export class ClickBankAPI {
  private apiKey: string;
  private accountId: string;
  private baseUrl = "https://api.clickbank.com/rest/1.3";

  constructor(config: ClickBankConfig) {
    this.apiKey = config.apiKey;
    this.accountId = config.accountId;
  }

  private getHeaders(): HeadersInit {
    // ClickBank API (2023+) uses API key directly in Authorization header
    // See: https://support.clickbank.com/en/articles/10535395-how-to-create-clickbank-api-keys
    return {
      Authorization: this.apiKey,
      Accept: "application/json",
      "Content-Type": "application/json",
    };
  }

  // Get recent transactions/sales
  async getTransactions(startDate?: string, endDate?: string): Promise<ClickBankTransaction[]> {
    try {
      const today = new Date().toISOString().split("T")[0];
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
      
      const start = startDate || thirtyDaysAgo;
      const end = endDate || today;

      const response = await fetch(
        `${this.baseUrl}/orders/list?startDate=${start}&endDate=${end}`,
        { headers: this.getHeaders() }
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.error("ClickBank API Error:", response.status, errorText);
        throw new Error(`ClickBank API error: ${response.status}`);
      }

      const data = await response.json();
      
      // Handle empty or null response (no orders found)
      if (!data || !data.orderData) {
        console.log("[ClickBank] No orders found in date range");
        return [];
      }
      
      // Transform ClickBank response to our format
      const transactions: ClickBankTransaction[] = data.orderData.map((order: any) => ({
        transactionId: order.receipt,
        transactionTime: order.transactionTime,
        amount: parseFloat(order.totalAccountAmount || "0"),
        currency: order.currency || "USD",
        productName: order.lineItemData?.productTitle || "Unknown Product",
        status: order.status === "SALE" ? "approved" : order.status?.toLowerCase() || "pending",
      }));

      return transactions;
    } catch (error) {
      console.error("Failed to fetch ClickBank transactions:", error);
      return [];
    }
  }

  // Get analytics summary
  async getAnalytics(): Promise<ClickBankAnalytics> {
    try {
      const response = await fetch(
        `${this.baseUrl}/analytics/list?role=AFFILIATE`,
        { headers: this.getHeaders() }
      );

      if (!response.ok) {
        throw new Error(`ClickBank API error: ${response.status}`);
      }

      const data = await response.json();
      
      return {
        totalSales: data.totalSaleCount || 0,
        totalRevenue: parseFloat(data.totalEarnings || "0"),
        refundRate: parseFloat(data.refundRate || "0"),
        averageOrderValue: parseFloat(data.averageOrderAmount || "0"),
      };
    } catch (error) {
      console.error("Failed to fetch ClickBank analytics:", error);
      return {
        totalSales: 0,
        totalRevenue: 0,
        refundRate: 0,
        averageOrderValue: 0,
      };
    }
  }

  // Get available products to promote
  async getMarketplaceProducts(category?: string): Promise<any[]> {
    try {
      const url = category
        ? `${this.baseUrl}/products/list?category=${category}`
        : `${this.baseUrl}/products/list`;

      const response = await fetch(url, { headers: this.getHeaders() });

      if (!response.ok) {
        throw new Error(`ClickBank API error: ${response.status}`);
      }

      const data = await response.json();
      return data.products || [];
    } catch (error) {
      console.error("Failed to fetch ClickBank products:", error);
      return [];
    }
  }

  // Test connection
  async testConnection(): Promise<boolean> {
    try {
      console.log("[ClickBank] Testing connection...");
      const response = await fetch(`${this.baseUrl}/orders/count`, {
        headers: this.getHeaders(),
      });
      
      if (!response.ok) {
        console.error("[ClickBank] Connection failed with status:", response.status);
        return false;
      }
      
      console.log("[ClickBank] Connection successful!");
      return true;
    } catch (error) {
      console.error("[ClickBank] Connection error occurred");
      return false;
    }
  }

  // Generate HopLink (affiliate link) for a product
  generateHopLink(vendorId: string, trackingId?: string): string {
    // ClickBank HopLink format: https://hop.clickbank.net/?affiliate=ACCOUNT&vendor=VENDOR
    // Optional tracking: https://hop.clickbank.net/?affiliate=ACCOUNT&vendor=VENDOR&tid=TRACKING_ID
    let hopLink = `https://hop.clickbank.net/?affiliate=${this.accountId}&vendor=${vendorId}`;
    if (trackingId) {
      hopLink += `&tid=${trackingId}`;
    }
    return hopLink;
  }

  // Fetch top products from ClickBank marketplace
  async getTopProducts(category?: string, limit: number = 50): Promise<MarketplaceProduct[]> {
    try {
      // ClickBank marketplace API endpoint
      const url = `${this.baseUrl}/products/list?type=TOP&results=${limit}${category ? `&category=${category}` : ''}`;
      
      const response = await fetch(url, { headers: this.getHeaders() });

      if (!response.ok) {
        console.log("ClickBank marketplace API not available, using fallback");
        return this.getTopProductsFallback(category, limit);
      }

      const data = await response.json();
      
      return (data.products || []).map((product: any) => ({
        vendorId: product.site,
        name: product.title || product.site,
        description: product.description || "",
        category: product.category || "General",
        gravity: parseFloat(product.gravity || "0"),
        commission: parseFloat(product.commission || "75"),
        initialPrice: parseFloat(product.initialPrice || "0"),
        avgEarningsPerSale: parseFloat(product.averageEarningsPerSale || "0"),
        hopLink: this.generateHopLink(product.site),
        imageUrl: product.imageUrl || null,
      }));
    } catch (error) {
      console.error("Failed to fetch ClickBank marketplace:", error);
      return this.getTopProductsFallback(category, limit);
    }
  }

  // Fallback with popular ClickBank categories and products
  private getTopProductsFallback(category?: string, limit: number = 50): MarketplaceProduct[] {
    const topProducts = [
      { vendorId: "java", name: "Java Burn", category: "Health & Fitness", gravity: 850, commission: 75, initialPrice: 69, avgEarnings: 52 },
      { vendorId: "exipure", name: "Exipure", category: "Health & Fitness", gravity: 650, commission: 75, initialPrice: 59, avgEarnings: 44 },
      { vendorId: "prodentim", name: "ProDentim", category: "Health & Fitness", gravity: 580, commission: 75, initialPrice: 69, avgEarnings: 52 },
      { vendorId: "glucotrust", name: "GlucoTrust", category: "Health & Fitness", gravity: 520, commission: 75, initialPrice: 69, avgEarnings: 52 },
      { vendorId: "kerassential", name: "Kerassentials", category: "Health & Fitness", gravity: 480, commission: 75, initialPrice: 69, avgEarnings: 52 },
      { vendorId: "leanbiome", name: "LeanBiome", category: "Health & Fitness", gravity: 420, commission: 75, initialPrice: 59, avgEarnings: 44 },
      { vendorId: "ikaria", name: "Ikaria Lean Belly Juice", category: "Health & Fitness", gravity: 380, commission: 75, initialPrice: 69, avgEarnings: 52 },
      { vendorId: "alpilean", name: "Alpilean", category: "Health & Fitness", gravity: 350, commission: 75, initialPrice: 59, avgEarnings: 44 },
      { vendorId: "tedswoodworking", name: "Ted's Woodworking", category: "Home & Garden", gravity: 180, commission: 75, initialPrice: 67, avgEarnings: 50 },
      { vendorId: "eatstopeat", name: "Eat Stop Eat", category: "Health & Fitness", gravity: 120, commission: 75, initialPrice: 37, avgEarnings: 28 },
      { vendorId: "cb1weight", name: "CB-1 Weight Gainer", category: "Health & Fitness", gravity: 100, commission: 40, initialPrice: 40, avgEarnings: 16 },
      { vendorId: "textchemistry", name: "Text Chemistry", category: "Self-Help", gravity: 95, commission: 75, initialPrice: 49, avgEarnings: 37 },
      { vendorId: "ezpayjobs", name: "EZ Pay Jobs", category: "Business", gravity: 85, commission: 75, initialPrice: 37, avgEarnings: 28 },
      { vendorId: "surveyjunkie", name: "Survey Junkie Jobs", category: "Business", gravity: 75, commission: 75, initialPrice: 27, avgEarnings: 20 },
      { vendorId: "manifestation", name: "Manifestation Magic", category: "Self-Help", gravity: 70, commission: 75, initialPrice: 47, avgEarnings: 35 },
    ];

    let filtered = topProducts;
    if (category) {
      filtered = topProducts.filter(p => p.category.toLowerCase().includes(category.toLowerCase()));
    }

    return filtered.slice(0, limit).map(product => ({
      vendorId: product.vendorId,
      name: product.name,
      description: `Top-selling ${product.category} product on ClickBank with ${product.gravity} gravity score.`,
      category: product.category,
      gravity: product.gravity,
      commission: product.commission,
      initialPrice: product.initialPrice,
      avgEarningsPerSale: product.avgEarnings,
      hopLink: `https://hop.clickbank.net/?affiliate=${this.accountId}&vendor=${product.vendorId}`,
      imageUrl: null,
    }));
  }
}

interface MarketplaceProduct {
  vendorId: string;
  name: string;
  description: string;
  category: string;
  gravity: number;
  commission: number;
  initialPrice: number;
  avgEarningsPerSale: number;
  hopLink: string;
  imageUrl: string | null;
}

// Helper function to sync ClickBank data to our database
export async function syncClickBankData(
  apiKey: string,
  accountId: string,
  networkId: string,
  storage: any
): Promise<{ success: boolean; transactionsImported: number }> {
  try {
    const clickbank = new ClickBankAPI({ apiKey, accountId });
    
    // Test connection first
    const isConnected = await clickbank.testConnection();
    if (!isConnected) {
      console.log("[ClickBank] API connection failed - using fallback products");
      
      // Import fallback products so user can still use the system
      const fallbackProducts = await clickbank.getTopProducts(undefined, 15);
      let imported = 0;
      
      for (const product of fallbackProducts) {
        try {
          const existingProducts = await storage.getMarketplaceProducts();
          const exists = existingProducts.some((p: any) => p.vendorId === product.vendorId);
          
          if (!exists) {
            await storage.createMarketplaceProduct({
              networkId,
              vendorId: product.vendorId,
              name: product.name,
              description: product.description,
              category: product.category,
              gravity: product.gravity.toString(),
              commission: product.commission.toString(),
              initialPrice: product.initialPrice.toString(),
              avgEarningsPerSale: product.avgEarningsPerSale.toString(),
              hopLink: product.hopLink,
            });
            imported++;
          }
        } catch (err) {
          // Skip errors
        }
      }
      
      console.log(`[ClickBank] Imported ${imported} fallback products`);
      return { success: true, transactionsImported: imported };
    }

    // Get recent transactions
    const transactions = await clickbank.getTransactions();
    
    // Import each transaction as an earning
    let imported = 0;
    for (const tx of transactions) {
      try {
        await storage.createAffiliateEarning({
          networkId,
          transactionId: tx.transactionId,
          amount: tx.amount.toString(),
          currency: tx.currency,
          status: tx.status,
          saleDate: new Date(tx.transactionTime),
        });
        imported++;
      } catch (err) {
        // Skip duplicates
      }
    }

    return { success: true, transactionsImported: imported };
  } catch (error) {
    console.error("[ClickBank] Sync error occurred");
    return { success: false, transactionsImported: 0 };
  }
}
