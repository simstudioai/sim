const AYRSHARE_API_URL = "https://api.ayrshare.com/api";

interface AyrshareConfig {
  apiKey: string;
  profileKey?: string;
}

interface HashtagConfig {
  max?: number;
  position?: "auto" | "end";
}

interface AutoRepostConfig {
  repeat: number;
  days: number;
  startDate?: string;
}

interface FirstComment {
  comment: string;
  mediaUrls?: string[];
}

interface PlatformContent {
  instagram?: string;
  facebook?: string;
  twitter?: string;
  linkedin?: string;
  tiktok?: string;
  default?: string;
}

interface PlatformMediaUrls {
  instagram?: string;
  facebook?: string;
  twitter?: string;
  linkedin?: string;
  tiktok?: string;
  default?: string;
}

interface PostOptions {
  post: string | PlatformContent;
  platforms: string[];
  mediaUrls?: string[] | PlatformMediaUrls;
  scheduleDate?: string;
  autoHashtag?: boolean;
  hashtags?: HashtagConfig;
  autoRepost?: AutoRepostConfig;
  requiresApproval?: boolean;
  approvalNotes?: string;
  idempotencyKey?: string;
  firstComment?: FirstComment;
  shortenLinks?: boolean;
}

interface PostResponse {
  status: string;
  id?: string;
  postIds?: Record<string, string>;
  errors?: any[];
  scheduleDate?: string;
}

export class AyrshareClient {
  private apiKey: string;
  private profileKey?: string;

  constructor(config: AyrshareConfig) {
    this.apiKey = config.apiKey;
    this.profileKey = config.profileKey;
  }

  private async request(endpoint: string, method: string, body?: any): Promise<any> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${this.apiKey}`,
    };
    
    // Add Profile-Key for multi-brand/profile support
    if (this.profileKey) {
      headers["Profile-Key"] = this.profileKey;
    }
    
    const response = await fetch(`${AYRSHARE_API_URL}${endpoint}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    const data = await response.json();
    return data;
  }

  async post(options: PostOptions): Promise<PostResponse> {
    const payload: any = {
      post: options.post,
      platforms: options.platforms,
    };

    if (options.mediaUrls) {
      if (Array.isArray(options.mediaUrls)) {
        payload.mediaUrls = options.mediaUrls.map(url => this.sanitizeUrl(url));
      } else {
        // Platform-specific media URLs
        const sanitizedMediaUrls: any = {};
        for (const [platform, url] of Object.entries(options.mediaUrls)) {
          if (url) {
            sanitizedMediaUrls[platform] = this.sanitizeUrl(url);
          }
        }
        payload.mediaUrls = sanitizedMediaUrls;
      }
    }

    if (options.scheduleDate) {
      payload.scheduleDate = options.scheduleDate;
    }

    if (options.autoHashtag) {
      payload.autoHashtag = true;
    }

    if (options.hashtags) {
      payload.hashtags = {
        max: options.hashtags.max || 3,
        position: options.hashtags.position || "auto",
      };
    }

    if (options.autoRepost) {
      payload.autoRepost = {
        repeat: Math.min(Math.max(options.autoRepost.repeat, 2), 10),
        days: Math.max(options.autoRepost.days, 2),
      };
      if (options.autoRepost.startDate) {
        payload.autoRepost.startDate = options.autoRepost.startDate;
      }
    }

    if (options.requiresApproval) {
      payload.requiresApproval = true;
      if (options.approvalNotes) {
        payload.notes = options.approvalNotes;
      }
    }

    if (options.idempotencyKey) {
      payload.idempotencyKey = options.idempotencyKey;
    }

    if (options.firstComment) {
      payload.firstComment = {
        comment: options.firstComment.comment,
      };
      if (options.firstComment.mediaUrls?.length) {
        payload.firstComment.mediaUrls = options.firstComment.mediaUrls;
      }
    }

    if (options.shortenLinks !== undefined) {
      payload.shortenLinks = options.shortenLinks;
    }

    console.log("[AYRSHARE] Posting to platforms:", options.platforms);
    return this.request("/post", "POST", payload);
  }

  async getHistory(platform?: string): Promise<any> {
    const endpoint = platform ? `/history?platform=${platform}` : "/history";
    return this.request(endpoint, "GET");
  }

  async deletePost(id: string): Promise<any> {
    return this.request("/delete", "DELETE", { id });
  }

  async getUser(): Promise<any> {
    return this.request("/user", "GET");
  }

  async getAnalytics(id: string, platforms: string[]): Promise<any> {
    return this.request("/analytics/post", "POST", { id, platforms });
  }

  // Profile Management for Multi-Brand Support
  async createProfile(title: string): Promise<any> {
    return this.request("/profiles", "POST", { title });
  }

  async getProfiles(): Promise<any> {
    return this.request("/profiles", "GET");
  }

  async deleteProfile(profileKey: string): Promise<any> {
    return this.request("/profiles", "DELETE", { profileKey });
  }

  async updateProfile(profileKey: string, data: { title?: string; displayTitle?: string }): Promise<any> {
    return this.request("/profiles", "PUT", { profileKey, ...data });
  }

  // Direct Messaging (Business Plan)
  async sendMessage(
    platform: "facebook" | "instagram" | "twitter",
    recipientId: string,
    message: string,
    mediaUrls?: string[]
  ): Promise<any> {
    const payload: any = {
      recipientId,
      message,
    };
    
    if (mediaUrls?.length) {
      payload.mediaUrls = mediaUrls.map(url => this.sanitizeUrl(url));
    }
    
    return this.request(`/messages/${platform}`, "POST", payload);
  }

  async getMessages(platform?: string): Promise<any> {
    const endpoint = platform ? `/messages?platform=${platform}` : "/messages";
    return this.request(endpoint, "GET");
  }

  async updateMessageStatus(
    platform: "facebook" | "instagram" | "twitter",
    conversationId: string,
    status: "active" | "archived"
  ): Promise<any> {
    return this.request(`/messages/${platform}/${conversationId}`, "PUT", { status });
  }

  // Facebook Ads API (Premium Plan)
  async getAdAccounts(): Promise<any> {
    return this.request("/ads/accounts", "GET");
  }

  async boostPost(options: {
    postId: string;
    adAccountId: string;
    budget: number;
    startDate: string;
    endDate: string;
    goal?: string;
    targeting?: {
      ageMin?: number;
      ageMax?: number;
      genders?: string[];
      locations?: string[];
      interests?: string[];
    };
  }): Promise<any> {
    return this.request("/ads/boost", "POST", options);
  }

  async getAdHistory(adAccountId?: string): Promise<any> {
    const endpoint = adAccountId ? `/ads/history?adAccountId=${adAccountId}` : "/ads/history";
    return this.request(endpoint, "GET");
  }

  async updateAd(adId: string, updates: { status?: string; budget?: number }): Promise<any> {
    return this.request("/ads/update", "PUT", { adId, ...updates });
  }

  // Auto-Response for Customer Service (Business Plan)
  async setAutoResponse(options: {
    autoResponseActive: boolean;
    autoResponseWaitSeconds?: number;
    autoResponseMessage?: string;
  }): Promise<any> {
    return this.request("/messages/autoresponse", "POST", options);
  }

  async getAutoResponse(): Promise<any> {
    return this.request("/messages/autoresponse", "GET");
  }

  // Media Gallery (Premium Plan)
  async getMedia(): Promise<any> {
    return this.request("/media", "GET");
  }

  async uploadMedia(mediaUrl: string, fileName?: string, description?: string): Promise<any> {
    return this.request("/media/upload", "POST", {
      mediaUrl: this.sanitizeUrl(mediaUrl),
      fileName,
      description
    });
  }

  async deleteMedia(mediaId: string): Promise<any> {
    return this.request("/media", "DELETE", { id: mediaId });
  }

  // Large File Upload (Premium Plan) - for files > 10MB up to 5GB
  async getUploadUrl(fileName: string, contentType?: string): Promise<any> {
    const params = new URLSearchParams({ fileName });
    if (contentType) params.append("contentType", contentType);
    return this.request(`/media/uploadUrl?${params.toString()}`, "GET");
  }

  // Media Metadata (Premium Plan) - get file details like dimensions, duration
  async getMediaMetadata(url: string): Promise<any> {
    const encodedUrl = encodeURIComponent(url);
    return this.request(`/media/meta?url=${encodedUrl}`, "GET");
  }

  // Verify Media URL Exists (Premium Plan)
  async verifyMediaUrl(mediaUrl: string): Promise<any> {
    return this.request("/media/urlExists", "POST", { mediaUrl });
  }

  private sanitizeUrl(url: string): string {
    try {
      const [protocol, rest] = url.split("://");
      if (!rest) return url;
      const [domain, ...pathParts] = rest.split("/");
      const sanitizedPath = pathParts.join("/").replace(/[^a-z0-9\/\.\-_]/gi, "_");
      return `${protocol}://${domain}/${sanitizedPath}`;
    } catch {
      return url;
    }
  }
}

let ayrshareClient: AyrshareClient | null = null;

export function getAyrshareClient(): AyrshareClient | null {
  const apiKey = process.env.AYRSHARE_API_KEY;
  if (!apiKey) {
    return null;
  }
  
  // Support optional profile key for multi-brand management
  const profileKey = process.env.AYRSHARE_PROFILE_KEY;
  
  if (!ayrshareClient) {
    ayrshareClient = new AyrshareClient({ apiKey, profileKey });
  }
  
  return ayrshareClient;
}

export async function postToAyrshare(
  content: string,
  platforms: string[],
  options?: {
    scheduleDate?: Date;
    autoHashtag?: boolean;
    maxHashtags?: number;
    autoRepost?: { repeat: number; days: number };
  }
): Promise<PostResponse | null> {
  const client = getAyrshareClient();
  if (!client) {
    console.log("[AYRSHARE] No API key configured");
    return null;
  }

  const postOptions: PostOptions = {
    post: content,
    platforms,
    shortenLinks: true,
  };

  if (options?.scheduleDate) {
    postOptions.scheduleDate = options.scheduleDate.toISOString();
  }

  if (options?.autoHashtag) {
    postOptions.autoHashtag = true;
    postOptions.hashtags = {
      max: options.maxHashtags || 3,
      position: "auto",
    };
  }

  if (options?.autoRepost) {
    postOptions.autoRepost = options.autoRepost;
  }

  postOptions.idempotencyKey = `post_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  try {
    const result = await client.post(postOptions);
    console.log("[AYRSHARE] Post result:", result.status);
    return result;
  } catch (error) {
    console.error("[AYRSHARE] Post failed:", error);
    return null;
  }
}
