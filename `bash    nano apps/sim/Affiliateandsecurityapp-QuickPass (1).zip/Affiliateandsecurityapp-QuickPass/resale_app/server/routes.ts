import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertAffiliateNetworkSchema, 
  insertAffiliateProductSchema, 
  insertAffiliateEarningSchema,
  insertSecureVaultItemSchema,
  insertMarketplaceProductSchema,
  insertSocialAccountSchema,
  insertCampaignSchema,
  insertBlogPostSchema,
} from "@shared/schema";
import { ClickBankAPI, syncClickBankData } from "./clickbank";
import { decrypt } from "./crypto";
import { 
  getAutomationStatus, 
  startAutomationEngine, 
  stopAutomationEngine, 
  generateOptimizedContent, 
  discoverAndPromoteProducts,
  getSystemHealth,
  triggerManualRecovery,
  runHealthChecks,
} from "./automation";
import { getAyrshareClient, postToAyrshare } from "./ayrshare";
import { autoGenerateContent, processContentQueue, getContentStats } from "./content-generator";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // ===== AFFILIATE NETWORKS =====
  
  // Get all networks (SAFE - masked credentials)
  app.get("/api/networks", async (req, res) => {
    try {
      const networks = await storage.getAffiliateNetworksSafe();
      res.json(networks);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch networks" });
    }
  });

  // Get single network (SAFE - masked credentials)
  app.get("/api/networks/:id", async (req, res) => {
    try {
      const networks = await storage.getAffiliateNetworksSafe();
      const network = networks.find(n => n.id === req.params.id);
      if (!network) {
        return res.status(404).json({ error: "Network not found" });
      }
      res.json(network);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch network" });
    }
  });

  // Create network
  app.post("/api/networks", async (req, res) => {
    try {
      const parsed = insertAffiliateNetworkSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid network data", details: parsed.error });
      }
      const network = await storage.createAffiliateNetwork(parsed.data);
      
      // Return safe version without credentials
      const safeNetworks = await storage.getAffiliateNetworksSafe();
      const safeNetwork = safeNetworks.find(n => n.id === network.id);
      res.status(201).json(safeNetwork);
    } catch (error) {
      res.status(500).json({ error: "Failed to create network" });
    }
  });

  // Update network
  app.patch("/api/networks/:id", async (req, res) => {
    try {
      const network = await storage.updateAffiliateNetwork(req.params.id, req.body);
      if (!network) {
        return res.status(404).json({ error: "Network not found" });
      }
      // Return safe version
      const safeNetworks = await storage.getAffiliateNetworksSafe();
      const safeNetwork = safeNetworks.find(n => n.id === network.id);
      res.json(safeNetwork);
    } catch (error) {
      res.status(500).json({ error: "Failed to update network" });
    }
  });

  // Delete network
  app.delete("/api/networks/:id", async (req, res) => {
    try {
      await storage.deleteAffiliateNetwork(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete network" });
    }
  });

  // ===== AFFILIATE PRODUCTS =====
  
  // Get all products
  app.get("/api/products", async (req, res) => {
    try {
      const networkId = req.query.networkId as string | undefined;
      const products = await storage.getAffiliateProducts(networkId);
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  // Get single product
  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getAffiliateProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Create product
  app.post("/api/products", async (req, res) => {
    try {
      const parsed = insertAffiliateProductSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid product data", details: parsed.error });
      }
      const product = await storage.createAffiliateProduct(parsed.data);
      res.status(201).json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to create product" });
    }
  });

  // Update product
  app.patch("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.updateAffiliateProduct(req.params.id, req.body);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to update product" });
    }
  });

  // Delete product
  app.delete("/api/products/:id", async (req, res) => {
    try {
      await storage.deleteAffiliateProduct(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  // ===== EARNINGS =====
  
  // Get all earnings
  app.get("/api/earnings", async (req, res) => {
    try {
      const networkId = req.query.networkId as string | undefined;
      const earnings = await storage.getAffiliateEarnings(networkId);
      res.json(earnings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch earnings" });
    }
  });

  // Get earnings summary
  app.get("/api/earnings/summary", async (req, res) => {
    try {
      const totals = await storage.getTotalEarnings();
      res.json(totals);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch earnings summary" });
    }
  });

  // Create earning
  app.post("/api/earnings", async (req, res) => {
    try {
      const parsed = insertAffiliateEarningSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid earning data", details: parsed.error });
      }
      const earning = await storage.createAffiliateEarning(parsed.data);
      res.status(201).json(earning);
    } catch (error) {
      res.status(500).json({ error: "Failed to create earning" });
    }
  });

  // ===== CLICKS =====
  
  // Get click stats
  app.get("/api/clicks/stats", async (req, res) => {
    try {
      const stats = await storage.getClickStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch click stats" });
    }
  });

  // Track a click (public endpoint for affiliate links)
  app.get("/api/track/:productId", async (req, res) => {
    try {
      const product = await storage.getAffiliateProduct(req.params.productId);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      // Record the click
      await storage.createAffiliateClick({
        productId: product.id,
        ipAddress: req.ip || "",
        userAgent: req.headers["user-agent"] || "",
        referrer: req.headers.referer || "",
      });

      // Redirect to affiliate link
      res.redirect(product.affiliateLink);
    } catch (error) {
      res.status(500).json({ error: "Failed to track click" });
    }
  });

  // ===== PAYOUTS =====
  
  // Get all payouts
  app.get("/api/payouts", async (req, res) => {
    try {
      const networkId = req.query.networkId as string | undefined;
      const payouts = await storage.getAffiliatePayouts(networkId);
      res.json(payouts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch payouts" });
    }
  });

  // ===== SECURE VAULT =====
  
  // Get all vault items
  app.get("/api/vault", async (req, res) => {
    try {
      const items = await storage.getSecureVaultItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch vault items" });
    }
  });

  // Get single vault item
  app.get("/api/vault/:id", async (req, res) => {
    try {
      const item = await storage.getSecureVaultItem(req.params.id);
      if (!item) {
        return res.status(404).json({ error: "Vault item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch vault item" });
    }
  });

  // Create vault item
  app.post("/api/vault", async (req, res) => {
    try {
      const parsed = insertSecureVaultItemSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid vault item data", details: parsed.error });
      }
      const item = await storage.createSecureVaultItem(parsed.data);
      res.status(201).json(item);
    } catch (error) {
      res.status(500).json({ error: "Failed to create vault item" });
    }
  });

  // Update vault item
  app.patch("/api/vault/:id", async (req, res) => {
    try {
      const item = await storage.updateSecureVaultItem(req.params.id, req.body);
      if (!item) {
        return res.status(404).json({ error: "Vault item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ error: "Failed to update vault item" });
    }
  });

  // Delete vault item
  app.delete("/api/vault/:id", async (req, res) => {
    try {
      await storage.deleteSecureVaultItem(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete vault item" });
    }
  });

  // ===== ACTIVITY LOGS =====
  
  // Get activity logs
  app.get("/api/activity", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const logs = await storage.getActivityLogs(limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch activity logs" });
    }
  });

  // ===== CLICKBANK SYNC =====
  
  app.post("/api/networks/:id/sync", async (req, res) => {
    try {
      // Get network with decrypted credentials for API calls
      const network = await storage.getAffiliateNetworkDecrypted(req.params.id);
      if (!network) {
        return res.status(404).json({ error: "Network not found" });
      }

      if (!network.apiKey || !network.accountId) {
        return res.status(400).json({ error: "Network missing API credentials" });
      }

      // For now, we support ClickBank syncing
      if (network.name.toLowerCase().includes("clickbank")) {
        const result = await syncClickBankData(
          network.apiKey,
          network.accountId,
          network.id,
          storage
        );

        if (result.success) {
          await storage.updateAffiliateNetwork(network.id, {
            status: "active",
          });
        }

        res.json(result);
      } else {
        // For other networks, just mark as active
        await storage.updateAffiliateNetwork(network.id, { status: "active" });
        res.json({ success: true, message: "Network activated" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to sync network" });
    }
  });

  // ===== DASHBOARD STATS =====
  
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const networks = await storage.getAffiliateNetworks();
      const products = await storage.getAffiliateProducts();
      const earnings = await storage.getTotalEarnings();
      const clicks = await storage.getClickStats();

      res.json({
        activeNetworks: networks.filter(n => n.status === "active").length,
        totalProducts: products.length,
        totalRevenue: earnings.total,
        pendingRevenue: earnings.pending,
        paidRevenue: earnings.paid,
        totalClicks: clicks.total,
        todayClicks: clicks.today,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  // ===== MARKETPLACE PRODUCTS =====
  
  app.get("/api/marketplace", async (req, res) => {
    try {
      const networkId = req.query.networkId as string | undefined;
      const products = await storage.getMarketplaceProducts(networkId);
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch marketplace products" });
    }
  });

  app.get("/api/marketplace/:id", async (req, res) => {
    try {
      const product = await storage.getMarketplaceProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch marketplace product" });
    }
  });

  app.post("/api/marketplace", async (req, res) => {
    try {
      const parsed = insertMarketplaceProductSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid product data", details: parsed.error });
      }
      const product = await storage.createMarketplaceProduct(parsed.data);
      res.status(201).json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to create marketplace product" });
    }
  });

  app.patch("/api/marketplace/:id", async (req, res) => {
    try {
      const product = await storage.updateMarketplaceProduct(req.params.id, req.body);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to update marketplace product" });
    }
  });

  app.delete("/api/marketplace/:id", async (req, res) => {
    try {
      await storage.deleteMarketplaceProduct(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete marketplace product" });
    }
  });

  // Discover products from ClickBank marketplace
  app.post("/api/marketplace/discover", async (req, res) => {
    try {
      const { networkId, category, limit } = req.body;
      
      const network = await storage.getAffiliateNetworkDecrypted(networkId);
      if (!network || !network.apiKey || !network.accountId) {
        return res.status(400).json({ error: "Network not configured properly" });
      }

      const clickbank = new ClickBankAPI({
        apiKey: network.apiKey,
        accountId: network.accountId,
      });

      const products = await clickbank.getTopProducts(category, limit || 20);
      
      // Save discovered products to database
      const savedProducts = [];
      for (const product of products) {
        const saved = await storage.createMarketplaceProduct({
          networkId,
          externalId: product.vendorId,
          name: product.name,
          description: product.description,
          vendorId: product.vendorId,
          category: product.category,
          gravity: product.gravity.toString(),
          commission: product.commission.toString(),
          initialPrice: product.initialPrice.toString(),
          avgEarningsPerSale: product.avgEarningsPerSale.toString(),
          hopLink: product.hopLink,
          imageUrl: product.imageUrl,
          isPromoting: false,
        });
        savedProducts.push(saved);
      }

      res.json({ 
        discovered: products.length,
        saved: savedProducts.length,
        products: savedProducts,
      });
    } catch (error) {
      console.error("Marketplace discovery error:", error);
      res.status(500).json({ error: "Failed to discover marketplace products" });
    }
  });

  // ===== SOCIAL ACCOUNTS =====
  
  app.get("/api/social-accounts", async (req, res) => {
    try {
      const accounts = await storage.getSocialAccounts();
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch social accounts" });
    }
  });

  app.get("/api/social-accounts/:id", async (req, res) => {
    try {
      const account = await storage.getSocialAccount(req.params.id);
      if (!account) {
        return res.status(404).json({ error: "Social account not found" });
      }
      res.json(account);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch social account" });
    }
  });

  app.post("/api/social-accounts", async (req, res) => {
    try {
      const parsed = insertSocialAccountSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid social account data", details: parsed.error });
      }
      const account = await storage.createSocialAccount(parsed.data);
      res.status(201).json(account);
    } catch (error) {
      res.status(500).json({ error: "Failed to create social account" });
    }
  });

  app.patch("/api/social-accounts/:id", async (req, res) => {
    try {
      const account = await storage.updateSocialAccount(req.params.id, req.body);
      if (!account) {
        return res.status(404).json({ error: "Social account not found" });
      }
      res.json(account);
    } catch (error) {
      res.status(500).json({ error: "Failed to update social account" });
    }
  });

  app.delete("/api/social-accounts/:id", async (req, res) => {
    try {
      await storage.deleteSocialAccount(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete social account" });
    }
  });

  // ===== CAMPAIGNS =====
  
  app.get("/api/campaigns", async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      const campaigns = await storage.getCampaigns(status);
      res.json(campaigns);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch campaigns" });
    }
  });

  app.get("/api/campaigns/:id", async (req, res) => {
    try {
      const campaign = await storage.getCampaign(req.params.id);
      if (!campaign) {
        return res.status(404).json({ error: "Campaign not found" });
      }
      res.json(campaign);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch campaign" });
    }
  });

  app.post("/api/campaigns", async (req, res) => {
    try {
      const parsed = insertCampaignSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid campaign data", details: parsed.error });
      }
      const campaign = await storage.createCampaign(parsed.data);
      res.status(201).json(campaign);
    } catch (error) {
      res.status(500).json({ error: "Failed to create campaign" });
    }
  });

  app.patch("/api/campaigns/:id", async (req, res) => {
    try {
      const campaign = await storage.updateCampaign(req.params.id, req.body);
      if (!campaign) {
        return res.status(404).json({ error: "Campaign not found" });
      }
      res.json(campaign);
    } catch (error) {
      res.status(500).json({ error: "Failed to update campaign" });
    }
  });

  app.delete("/api/campaigns/:id", async (req, res) => {
    try {
      await storage.deleteCampaign(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete campaign" });
    }
  });

  // Generate content for campaign
  app.post("/api/campaigns/generate-content", async (req, res) => {
    try {
      const { productId, platform } = req.body;
      
      const product = await storage.getMarketplaceProduct(productId);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      // Generate platform-specific content
      const templates: Record<string, { content: string; hashtags: string[] }> = {
        twitter: {
          content: `Struggling with ${product.category?.toLowerCase() || 'this issue'}? Check out ${product.name} - it's been helping thousands of people! 🔥\n\n${product.hopLink}`,
          hashtags: ['affiliate', product.category?.replace(/\s+/g, '') || 'health', 'recommended', 'musthave'],
        },
        instagram: {
          content: `📢 Just discovered ${product.name}!\n\n${product.description?.slice(0, 200) || `Amazing product for ${product.category}`}\n\n💰 Commission: ${product.commission}%\n🌟 Link in bio!`,
          hashtags: ['affiliate', 'affiliatemarketing', product.category?.replace(/\s+/g, '') || 'health', 'productreview', 'recommended'],
        },
        facebook: {
          content: `🔥 Have you tried ${product.name}?\n\n${product.description || `This is one of the best products I've found for ${product.category}!`}\n\n✅ Top-rated by thousands\n✅ ${product.commission}% commission for affiliates\n\nCheck it out: ${product.hopLink}`,
          hashtags: ['affiliate', product.category?.replace(/\s+/g, '') || 'health'],
        },
        tiktok: {
          content: `POV: You just discovered ${product.name} 🤯\n\n${product.category} game changer! Link in bio 🔗`,
          hashtags: ['fyp', 'viral', product.category?.replace(/\s+/g, '')?.toLowerCase() || 'health', 'recommended', 'musthave'],
        },
      };

      const template = templates[platform] || templates.twitter;
      
      res.json({
        content: template.content,
        hashtags: template.hashtags,
        productName: product.name,
        hopLink: product.hopLink,
      });
    } catch (error) {
      console.error("Content generation error:", error);
      res.status(500).json({ error: "Failed to generate content" });
    }
  });

  // ===== AUTOMATION STATUS =====
  
  app.get("/api/automation/status", async (req, res) => {
    try {
      const status = await getAutomationStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch automation status" });
    }
  });

  app.post("/api/automation/start", async (req, res) => {
    try {
      startAutomationEngine();
      await storage.createActivityLog({
        action: "automation_started",
        category: "automation",
        details: "Automation engine started",
        severity: "info",
      });
      res.json({ success: true, message: "Automation engine started" });
    } catch (error) {
      res.status(500).json({ error: "Failed to start automation" });
    }
  });

  app.post("/api/automation/stop", async (req, res) => {
    try {
      stopAutomationEngine();
      await storage.createActivityLog({
        action: "automation_stopped",
        category: "automation",
        details: "Automation engine stopped",
        severity: "info",
      });
      res.json({ success: true, message: "Automation engine stopped" });
    } catch (error) {
      res.status(500).json({ error: "Failed to stop automation" });
    }
  });

  app.post("/api/automation/auto-discover", async (req, res) => {
    try {
      const { networkId, limit } = req.body;
      const result = await discoverAndPromoteProducts(networkId, limit || 5);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to auto-discover products" });
    }
  });

  // ===== SYSTEM HEALTH & SELF-HEALING =====
  
  app.get("/api/health", async (req, res) => {
    try {
      const health = await getSystemHealth();
      res.json(health);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch system health" });
    }
  });

  app.post("/api/health/check", async (req, res) => {
    try {
      const health = await runHealthChecks();
      res.json(health);
    } catch (error) {
      res.status(500).json({ error: "Failed to run health check" });
    }
  });

  app.post("/api/health/recover", async (req, res) => {
    try {
      const result = await triggerManualRecovery();
      
      await storage.createActivityLog({
        action: "manual_recovery_triggered",
        category: "system",
        details: result.message,
        severity: result.success ? "info" : "warning",
      });
      
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to trigger recovery" });
    }
  });

  // ===== POST QUEUE =====
  
  app.get("/api/post-queue", async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      const queue = await storage.getPostQueue(status);
      res.json(queue);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch post queue" });
    }
  });

  app.post("/api/post-queue", async (req, res) => {
    try {
      const data = {
        ...req.body,
        scheduledFor: req.body.scheduledFor ? new Date(req.body.scheduledFor) : new Date(),
      };
      const post = await storage.createPostQueue(data);
      res.status(201).json(post);
    } catch (error: any) {
      console.error("[POST QUEUE] Create error:", error);
      res.status(500).json({ error: "Failed to create post", details: error.message });
    }
  });

  app.patch("/api/post-queue/:id", async (req, res) => {
    try {
      const post = await storage.updatePostQueue(req.params.id, req.body);
      if (!post) {
        return res.status(404).json({ error: "Post not found" });
      }
      res.json(post);
    } catch (error) {
      res.status(500).json({ error: "Failed to update post" });
    }
  });

  app.delete("/api/post-queue/:id", async (req, res) => {
    try {
      await storage.deletePostQueue(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete post" });
    }
  });

  // ===== NOTIFICATIONS =====
  
  app.get("/api/notifications", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const notificationsList = await storage.getNotifications(limit);
      res.json(notificationsList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });

  app.get("/api/notifications/unread", async (req, res) => {
    try {
      const unread = await storage.getUnreadNotifications();
      res.json(unread);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch unread notifications" });
    }
  });

  app.patch("/api/notifications/:id/read", async (req, res) => {
    try {
      await storage.markNotificationRead(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to mark notification read" });
    }
  });

  app.post("/api/notifications/read-all", async (req, res) => {
    try {
      await storage.markAllNotificationsRead();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to mark all notifications read" });
    }
  });

  app.post("/api/notifications", async (req, res) => {
    try {
      const notification = await storage.createNotification(req.body);
      res.status(201).json(notification);
    } catch (error: any) {
      console.error("[NOTIFICATIONS] Create error:", error);
      res.status(500).json({ error: "Failed to create notification", details: error.message });
    }
  });

  // ===== NOTIFICATION SETTINGS =====
  
  app.get("/api/notification-settings", async (req, res) => {
    try {
      const settings = await storage.getNotificationSettings();
      res.json(settings || {
        emailEnabled: false,
        pushEnabled: true,
        notifyOnSale: true,
        notifyOnFailure: true,
        notifyDailyReport: true,
        notifyWeeklyReport: true,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notification settings" });
    }
  });

  app.post("/api/notification-settings", async (req, res) => {
    try {
      const settings = await storage.upsertNotificationSettings(req.body);
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: "Failed to save notification settings" });
    }
  });

  // ===== A/B TEST VARIANTS =====

  app.get("/api/ab-tests", async (req, res) => {
    try {
      const allVariants = await storage.getAllAbTestVariants();
      res.json(allVariants);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch A/B tests" });
    }
  });

  app.post("/api/ab-tests", async (req, res) => {
    try {
      const variant = await storage.createAbTestVariant(req.body);
      res.status(201).json(variant);
    } catch (error: any) {
      console.error("[AB TESTS] Create error:", error);
      res.status(500).json({ error: "Failed to create A/B test", details: error.message });
    }
  });
  
  app.get("/api/campaigns/:id/ab-variants", async (req, res) => {
    try {
      const variants = await storage.getAbTestVariants(req.params.id);
      res.json(variants);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch A/B variants" });
    }
  });

  app.post("/api/campaigns/:id/ab-variants", async (req, res) => {
    try {
      const variant = await storage.createAbTestVariant({
        ...req.body,
        campaignId: req.params.id,
      });
      res.status(201).json(variant);
    } catch (error) {
      res.status(500).json({ error: "Failed to create A/B variant" });
    }
  });

  app.patch("/api/ab-variants/:id", async (req, res) => {
    try {
      const variant = await storage.updateAbTestVariant(req.params.id, req.body);
      if (!variant) {
        return res.status(404).json({ error: "Variant not found" });
      }
      res.json(variant);
    } catch (error) {
      res.status(500).json({ error: "Failed to update A/B variant" });
    }
  });

  app.delete("/api/ab-variants/:id", async (req, res) => {
    try {
      await storage.deleteAbTestVariant(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete A/B variant" });
    }
  });

  // ===== POST TEMPLATES =====
  
  app.get("/api/templates", async (req, res) => {
    try {
      const platform = req.query.platform as string | undefined;
      const templates = await storage.getPostTemplates(platform);
      res.json(templates);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch templates" });
    }
  });

  app.get("/api/templates/:id", async (req, res) => {
    try {
      const template = await storage.getPostTemplate(req.params.id);
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }
      res.json(template);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch template" });
    }
  });

  app.post("/api/templates", async (req, res) => {
    try {
      const template = await storage.createPostTemplate(req.body);
      res.status(201).json(template);
    } catch (error) {
      res.status(500).json({ error: "Failed to create template" });
    }
  });

  app.patch("/api/templates/:id", async (req, res) => {
    try {
      const template = await storage.updatePostTemplate(req.params.id, req.body);
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }
      res.json(template);
    } catch (error) {
      res.status(500).json({ error: "Failed to update template" });
    }
  });

  app.delete("/api/templates/:id", async (req, res) => {
    try {
      await storage.deletePostTemplate(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete template" });
    }
  });

  // ===== ANALYTICS =====
  
  app.get("/api/analytics/snapshots", async (req, res) => {
    try {
      const days = parseInt(req.query.days as string) || 30;
      const snapshots = await storage.getAnalyticsSnapshots(days);
      res.json(snapshots);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analytics snapshots" });
    }
  });

  app.get("/api/analytics/today", async (req, res) => {
    try {
      const snapshot = await storage.getTodaySnapshot();
      const salesToday = await storage.getSalesToday();
      res.json({
        snapshot,
        sales: salesToday,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch today's analytics" });
    }
  });

  app.post("/api/analytics/snapshot", async (req, res) => {
    try {
      const snapshot = await storage.createAnalyticsSnapshot(req.body);
      res.status(201).json(snapshot);
    } catch (error) {
      res.status(500).json({ error: "Failed to create analytics snapshot" });
    }
  });

  // ===== RATE LIMITS =====
  
  app.get("/api/rate-limits", async (req, res) => {
    try {
      const limits = await storage.getRateLimits();
      res.json(limits);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch rate limits" });
    }
  });

  app.get("/api/rate-limits/:accountId", async (req, res) => {
    try {
      const limit = await storage.getRateLimit(req.params.accountId);
      res.json(limit || { postsToday: 0, postsThisHour: 0, dailyLimit: 10, hourlyLimit: 2 });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch rate limit" });
    }
  });

  app.post("/api/rate-limits", async (req, res) => {
    try {
      const limit = await storage.upsertRateLimit(req.body);
      res.json(limit);
    } catch (error) {
      res.status(500).json({ error: "Failed to update rate limit" });
    }
  });

  // ===== SALES TRACKING =====
  
  app.get("/api/sales", async (req, res) => {
    try {
      const networkId = req.query.networkId as string | undefined;
      const sales = await storage.getSalesTracking(networkId);
      res.json(sales);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sales" });
    }
  });

  app.get("/api/sales/today", async (req, res) => {
    try {
      const salesToday = await storage.getSalesToday();
      res.json(salesToday);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch today's sales" });
    }
  });

  app.post("/api/sales", async (req, res) => {
    try {
      const sale = await storage.createSalesTracking(req.body);
      res.status(201).json(sale);
    } catch (error) {
      res.status(500).json({ error: "Failed to record sale" });
    }
  });

  // ClickBank IPN (Instant Payment Notification) webhook
  app.post("/api/webhooks/clickbank", async (req, res) => {
    try {
      const { transactionType, receipt, amount, vendor, affiliate, trackingCodes } = req.body;
      
      if (transactionType === 'SALE' || transactionType === 'TEST_SALE') {
        await storage.createSalesTracking({
          networkId: null,
          productId: vendor,
          transactionId: receipt,
          amount: amount.toString(),
          commission: (parseFloat(amount) * 0.5).toString(),
          trackingId: trackingCodes?.[0] || null,
          status: 'completed',
          saleType: 'initial',
          saleDate: new Date(),
        });
        
        await storage.createActivityLog({
          action: 'sale_received',
          category: 'affiliate',
          details: `New sale! $${amount} from ${vendor}`,
          severity: 'info',
        });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error('ClickBank webhook error:', error);
      res.status(500).json({ error: 'Webhook processing failed' });
    }
  });

  // ===== CAMPAIGN DUPLICATION =====
  
  app.post("/api/campaigns/:id/duplicate", async (req, res) => {
    try {
      const duplicate = await storage.getDuplicateCampaign(req.params.id);
      if (!duplicate) {
        return res.status(404).json({ error: "Campaign not found" });
      }
      res.status(201).json(duplicate);
    } catch (error) {
      res.status(500).json({ error: "Failed to duplicate campaign" });
    }
  });

  // ===== AYRSHARE SOCIAL MEDIA API =====

  // Test Ayrshare connection
  app.get("/api/ayrshare/status", async (req, res) => {
    try {
      const client = getAyrshareClient();
      if (!client) {
        return res.json({ 
          connected: false, 
          message: "AYRSHARE_API_KEY not configured. Get your free API key at ayrshare.com" 
        });
      }
      
      const user = await client.getUser();
      res.json({ 
        connected: true, 
        user: {
          email: user.email,
          displayName: user.displayName,
          activeSocialAccounts: user.activeSocialAccounts || [],
        }
      });
    } catch (error: any) {
      res.json({ 
        connected: false, 
        error: error.message || "Connection failed" 
      });
    }
  });

  // Get post history from Ayrshare
  app.get("/api/ayrshare/history", async (req, res) => {
    try {
      const client = getAyrshareClient();
      if (!client) {
        return res.status(400).json({ error: "Ayrshare not configured" });
      }
      
      const platform = req.query.platform as string | undefined;
      const history = await client.getHistory(platform);
      res.json(history);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to get history" });
    }
  });

  // Post to social media via Ayrshare
  app.post("/api/ayrshare/post", async (req, res) => {
    try {
      const client = getAyrshareClient();
      if (!client) {
        return res.status(400).json({ error: "Ayrshare not configured. Add AYRSHARE_API_KEY to secrets." });
      }
      
      const { post, platforms, mediaUrls, scheduleDate, autoHashtag, maxHashtags, autoRepost } = req.body;
      
      if (!post || !platforms?.length) {
        return res.status(400).json({ error: "post and platforms are required" });
      }

      const result = await postToAyrshare(post, platforms, {
        scheduleDate: scheduleDate ? new Date(scheduleDate) : undefined,
        autoHashtag: autoHashtag ?? true,
        maxHashtags: maxHashtags ?? 3,
        autoRepost,
      });
      
      if (result) {
        res.json(result);
      } else {
        res.status(500).json({ error: "Post failed" });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to post" });
    }
  });

  // Post with platform-specific content
  app.post("/api/ayrshare/post-custom", async (req, res) => {
    try {
      const client = getAyrshareClient();
      if (!client) {
        return res.status(400).json({ error: "Ayrshare not configured" });
      }
      
      // Accepts full Ayrshare post format with platform-specific content
      const result = await client.post(req.body);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to post" });
    }
  });

  // Get analytics for a post
  app.get("/api/ayrshare/analytics/:postId", async (req, res) => {
    try {
      const client = getAyrshareClient();
      if (!client) {
        return res.status(400).json({ error: "Ayrshare not configured" });
      }
      
      const platforms = (req.query.platforms as string)?.split(",") || ["twitter", "facebook", "instagram"];
      const analytics = await client.getAnalytics(req.params.postId, platforms);
      res.json(analytics);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to get analytics" });
    }
  });

  // Delete a post
  app.delete("/api/ayrshare/post/:postId", async (req, res) => {
    try {
      const client = getAyrshareClient();
      if (!client) {
        return res.status(400).json({ error: "Ayrshare not configured" });
      }
      
      const result = await client.deletePost(req.params.postId);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to delete post" });
    }
  });

  // Send direct message (Business Plan)
  app.post("/api/ayrshare/message/:platform", async (req, res) => {
    try {
      const client = getAyrshareClient();
      if (!client) {
        return res.status(400).json({ error: "Ayrshare not configured" });
      }
      
      const platform = req.params.platform as "facebook" | "instagram" | "twitter";
      const { recipientId, message, mediaUrls } = req.body;
      
      if (!recipientId) {
        return res.status(400).json({ error: "recipientId is required" });
      }
      
      const result = await client.sendMessage(platform, recipientId, message || "", mediaUrls);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to send message" });
    }
  });

  // Profile management
  app.get("/api/ayrshare/profiles", async (req, res) => {
    try {
      const client = getAyrshareClient();
      if (!client) {
        return res.status(400).json({ error: "Ayrshare not configured" });
      }
      
      const profiles = await client.getProfiles();
      res.json(profiles);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to get profiles" });
    }
  });

  app.post("/api/ayrshare/profiles", async (req, res) => {
    try {
      const client = getAyrshareClient();
      if (!client) {
        return res.status(400).json({ error: "Ayrshare not configured" });
      }
      
      const { title } = req.body;
      if (!title) {
        return res.status(400).json({ error: "title is required" });
      }
      
      const profile = await client.createProfile(title);
      res.json(profile);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to create profile" });
    }
  });

  // ===== BLOG POSTS (Automated SEO Content) =====

  // Get all blog posts (admin)
  app.get("/api/blog/posts", async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      const posts = await storage.getBlogPosts(status);
      res.json(posts);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to fetch blog posts" });
    }
  });

  // Get single blog post by ID (admin)
  app.get("/api/blog/posts/:id", async (req, res) => {
    try {
      const post = await storage.getBlogPost(req.params.id);
      if (!post) {
        return res.status(404).json({ error: "Blog post not found" });
      }
      res.json(post);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to fetch blog post" });
    }
  });

  // Create blog post
  app.post("/api/blog/posts", async (req, res) => {
    try {
      const parsed = insertBlogPostSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid blog post data", details: parsed.error });
      }
      const post = await storage.createBlogPost(parsed.data);
      res.status(201).json(post);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to create blog post" });
    }
  });

  // Update blog post
  app.put("/api/blog/posts/:id", async (req, res) => {
    try {
      const post = await storage.updateBlogPost(req.params.id, req.body);
      if (!post) {
        return res.status(404).json({ error: "Blog post not found" });
      }
      res.json(post);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to update blog post" });
    }
  });

  // Delete blog post
  app.delete("/api/blog/posts/:id", async (req, res) => {
    try {
      await storage.deleteBlogPost(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to delete blog post" });
    }
  });

  // Publish blog post
  app.post("/api/blog/posts/:id/publish", async (req, res) => {
    try {
      const post = await storage.updateBlogPost(req.params.id, {
        status: "published",
        publishedAt: new Date(),
      });
      if (!post) {
        return res.status(404).json({ error: "Blog post not found" });
      }
      
      await storage.createActivityLog({
        action: "blog_post_published",
        category: "content",
        details: `Blog post "${post.title}" published`,
        severity: "info",
      });
      
      res.json(post);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to publish blog post" });
    }
  });

  // ===== PUBLIC BLOG ROUTES (SEO-friendly) =====

  // Get published posts (public)
  app.get("/api/public/blog", async (req, res) => {
    try {
      const posts = await storage.getPublishedBlogPosts();
      res.json(posts);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to fetch blog posts" });
    }
  });

  // Get post by slug (public) - increments view count
  app.get("/api/public/blog/:slug", async (req, res) => {
    try {
      const post = await storage.getBlogPostBySlug(req.params.slug);
      if (!post || post.status !== "published") {
        return res.status(404).json({ error: "Blog post not found" });
      }
      
      // Increment view count
      await storage.incrementBlogViews(post.id);
      
      res.json(post);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to fetch blog post" });
    }
  });

  // Track affiliate link click (public)
  app.post("/api/public/blog/:id/click", async (req, res) => {
    try {
      await storage.incrementBlogClicks(req.params.id);
      
      const post = await storage.getBlogPost(req.params.id);
      if (post?.affiliateLink) {
        res.json({ redirect: post.affiliateLink });
      } else {
        res.status(404).json({ error: "Affiliate link not found" });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to track click" });
    }
  });

  // ===== CONTENT QUEUE =====

  // Get content queue
  app.get("/api/content/queue", async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      const queue = await storage.getContentQueue(status);
      res.json(queue);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to fetch content queue" });
    }
  });

  // Add product to content queue for auto-generation
  app.post("/api/content/queue", async (req, res) => {
    try {
      const { productId, contentType, priority, scheduledFor } = req.body;
      
      if (!productId) {
        return res.status(400).json({ error: "productId is required" });
      }
      
      const item = await storage.createContentQueueItem({
        productId,
        contentType: contentType || "review",
        priority: priority || 5,
        status: "pending",
        scheduledFor: scheduledFor ? new Date(scheduledFor) : new Date(),
      });
      
      res.status(201).json(item);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to add to content queue" });
    }
  });

  // Queue all products for content generation
  app.post("/api/content/queue-all", async (req, res) => {
    try {
      const products = await storage.getMarketplaceProducts();
      const activeProducts = products.filter(p => p.isPromoting);
      
      let queued = 0;
      for (const product of activeProducts) {
        await storage.createContentQueueItem({
          productId: product.id,
          contentType: "review",
          priority: 5,
          status: "pending",
          scheduledFor: new Date(),
        });
        queued++;
      }
      
      await storage.createActivityLog({
        action: "content_queue_bulk_add",
        category: "content",
        details: `Queued ${queued} products for content generation`,
        severity: "info",
      });
      
      res.json({ queued, message: `${queued} products added to content queue` });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to queue products" });
    }
  });

  // Trigger auto-generation of content
  app.post("/api/content/generate", async (req, res) => {
    try {
      await autoGenerateContent();
      const stats = await getContentStats();
      res.json({ 
        success: true, 
        message: "Content generation triggered",
        stats 
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to generate content" });
    }
  });

  // Process content queue
  app.post("/api/content/process-queue", async (req, res) => {
    try {
      const result = await processContentQueue();
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to process queue" });
    }
  });

  // Get content statistics
  app.get("/api/content/stats", async (req, res) => {
    try {
      const stats = await getContentStats();
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to get stats" });
    }
  });

  // ===== CLICKBANK INSTANT PAYMENT NOTIFICATION (IPN) WEBHOOK =====
  app.post("/api/webhooks/clickbank", async (req, res) => {
    try {
      const crypto = await import("crypto");
      const secretKey = process.env.CLICKBANK_SECRET_KEY || process.env.CLICKBANK_CLERK_KEY;
      
      let notification = req.body;
      let verified = false;
      
      // ClickBank IPN Version 7.0+ uses AES-256-CBC encryption
      if (notification.notification && notification.iv && secretKey) {
        try {
          // Decrypt AES-256-CBC encrypted payload
          // Key derivation: SHA-1 hash of secret, take first 32 hex chars, use as raw bytes
          const sha1Hash = crypto.createHash('sha1').update(secretKey).digest('hex');
          const keyHex = sha1Hash.substring(0, 32);
          const key = Buffer.from(keyHex, 'utf8'); // ClickBank uses UTF-8 string of hex chars as key
          const iv = Buffer.from(notification.iv, 'base64');
          const encrypted = Buffer.from(notification.notification, 'base64');
          
          const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
          decipher.setAutoPadding(true);
          let decrypted = decipher.update(encrypted);
          decrypted = Buffer.concat([decrypted, decipher.final()]);
          
          // Remove null padding and parse JSON
          const decryptedStr = decrypted.toString('utf8').replace(/[\x00-\x1f]/g, '').trim();
          notification = JSON.parse(decryptedStr);
          verified = true;
          console.log("[WEBHOOK] ClickBank IPN v7.0+ verified via AES decryption");
        } catch (decryptError) {
          console.error("[WEBHOOK] Failed to decrypt ClickBank IPN:", decryptError);
          // Log attempt for debugging
          await storage.createActivityLog({
            action: "webhook_decrypt_failed",
            category: "security",
            details: `ClickBank IPN decryption failed: ${decryptError}`,
            severity: "warning",
          });
          return res.status(403).json({ error: "IPN verification failed - invalid encryption" });
        }
      }
      // Legacy ClickBank IPN (v4.0-6.0) uses cverify SHA-1 hash
      else if (notification.cverify && secretKey) {
        // Build verification string: sorted param values joined by | then secret key
        const sortedKeys = Object.keys(notification).filter(k => k !== 'cverify').sort();
        const verifyString = sortedKeys.map(k => notification[k]).join('|') + '|' + secretKey;
        
        // SHA-1 hash, first 8 chars uppercase
        const expectedHash = crypto.createHash('sha1')
          .update(Buffer.from(verifyString, 'utf8'))
          .digest('hex')
          .substring(0, 8)
          .toUpperCase();
        
        if (notification.cverify.toUpperCase() === expectedHash) {
          verified = true;
          console.log("[WEBHOOK] ClickBank legacy IPN verified via cverify");
        } else {
          console.warn("[WEBHOOK] ClickBank cverify mismatch - rejecting");
          await storage.createActivityLog({
            action: "webhook_rejected",
            category: "security",
            details: "ClickBank IPN signature verification failed",
            severity: "warning",
          });
          return res.status(403).json({ error: "IPN verification failed - invalid signature" });
        }
      }
      // No secret key configured - log warning but allow (for testing)
      else if (!secretKey) {
        console.warn("[WEBHOOK] No CLICKBANK_SECRET_KEY configured - accepting unverified IPN");
        verified = false; // Mark as unverified
      }
      // Has payload but no verification method available
      else {
        console.warn("[WEBHOOK] IPN received without verification data");
        return res.status(400).json({ error: "Invalid IPN format - no verification data" });
      }
      
      // Extract transaction data from notification
      const transactionId = notification.receipt || notification.ctransreceipt || notification.transactionId;
      const email = notification.email || notification.customerEmail || notification.ccustemail;
      const transactionType = notification.transactionType || notification.ctransaction;
      
      // Only process SALE transactions (not refunds, chargebacks, etc.)
      if (transactionType && !['SALE', 'TEST_SALE', 'TEST'].includes(transactionType.toUpperCase())) {
        console.log(`[WEBHOOK] Ignoring non-sale transaction: ${transactionType}`);
        return res.json({ success: true, message: "Non-sale transaction ignored" });
      }
      
      if (!transactionId || !email) {
        return res.status(400).json({ error: "Missing required fields: receipt and email" });
      }
      
      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ error: "Invalid email format" });
      }
      
      // Check if purchase already exists
      const existing = await storage.getCustomerPurchaseByTransaction(transactionId);
      if (existing) {
        return res.json({ success: true, message: "Purchase already recorded" });
      }
      
      const name = `${notification.ccustfirstname || notification.firstName || ''} ${notification.ccustlastname || notification.lastName || ''}`.trim() || notification.name || "";
      const productName = notification.cprodtitle || notification.productTitle || notification.productName || "Privately App";
      const amount = parseFloat(notification.ctransamount || notification.totalAccountAmount || notification.amount || "47") / 100; // ClickBank sends cents
      
      // Generate secure access token
      const accessToken = `priv_${crypto.randomBytes(32).toString('hex')}`;
      
      // Create purchase record
      const purchase = await storage.createCustomerPurchase({
        email,
        name,
        transactionId,
        productName,
        amount: amount.toString(),
        accessToken,
        purchasedAt: new Date(),
      });
      
      // Log the sale with verification status
      await storage.createActivityLog({
        action: "new_sale",
        category: "sales",
        details: `New sale: ${productName} to ${email} for $${amount}${verified ? ' (verified)' : ' (unverified)'}`,
        severity: "info",
      });
      
      console.log(`[SALE] New purchase: ${transactionId} - ${email} - $${amount} (verified: ${verified})`);
      
      res.json({ 
        success: true, 
        purchaseId: purchase.id,
        accessToken: purchase.accessToken,
        downloadUrl: `/download/${purchase.accessToken}`,
        verified
      });
    } catch (error: any) {
      console.error("[WEBHOOK] ClickBank IPN error:", error);
      res.status(500).json({ error: error.message || "Failed to process notification" });
    }
  });

  // Verify purchase and get download access
  app.get("/api/purchase/verify/:token", async (req, res) => {
    try {
      const { token } = req.params;
      const purchase = await storage.getCustomerPurchaseByToken(token);
      
      if (!purchase) {
        return res.status(404).json({ error: "Purchase not found" });
      }
      
      res.json({
        valid: true,
        productName: purchase.productName,
        purchasedAt: purchase.purchasedAt,
        email: purchase.email,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to verify purchase" });
    }
  });

  // Get all purchases (admin)
  app.get("/api/purchases", async (req, res) => {
    try {
      const purchases = await storage.getCustomerPurchases();
      res.json(purchases);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to get purchases" });
    }
  });

  // Secure download endpoint - requires valid purchase token
  app.get("/api/download/:token", async (req, res) => {
    try {
      const { token } = req.params;
      const archiver = await import("archiver");
      const path = await import("path");
      const fs = await import("fs");
      
      // Validate token format
      if (!token || !token.startsWith('priv_')) {
        return res.status(400).json({ error: "Invalid download token" });
      }
      
      // Verify purchase
      const purchase = await storage.getCustomerPurchaseByToken(token);
      if (!purchase) {
        return res.status(403).json({ error: "Invalid or expired access token. Please contact support." });
      }
      
      // Increment download count
      await storage.incrementDownloadCount(purchase.id);
      
      // Log download
      await storage.createActivityLog({
        action: "download",
        category: "sales",
        details: `Download initiated for ${purchase.email} (download #${(purchase.downloadCount || 0) + 1})`,
        severity: "info",
      });
      
      console.log(`[DOWNLOAD] Serving file to ${purchase.email}`);
      
      // Check if resale_app folder exists
      const resalePath = path.resolve(process.cwd(), "resale_app");
      
      if (fs.existsSync(resalePath)) {
        // Create and stream a zip file of the resale_app folder
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', 'attachment; filename="privately-app.zip"');
        
        const archive = archiver.default('zip', {
          zlib: { level: 9 }
        });
        
        // Handle archive errors
        archive.on('error', (err: Error) => {
          console.error("[DOWNLOAD] Archive error:", err);
          if (!res.headersSent) {
            res.status(500).json({ error: "Failed to create download package" });
          }
        });
        
        // Pipe archive to response
        archive.pipe(res);
        
        // Add the resale_app directory to the archive
        archive.directory(resalePath, 'privately-app');
        
        // Finalize the archive
        await archive.finalize();
        
        console.log(`[DOWNLOAD] Successfully served zip to ${purchase.email}`);
      } else {
        // Fallback: provide download instructions if resale folder doesn't exist
        res.json({
          success: false,
          message: "Download package is being prepared. Please try again in a few minutes or contact support.",
          email: purchase.email,
          productName: purchase.productName,
          supportEmail: "support@privately.app"
        });
      }
    } catch (error: any) {
      console.error("[DOWNLOAD] Error:", error);
      if (!res.headersSent) {
        res.status(500).json({ error: error.message || "Download failed" });
      }
    }
  });

  // ===== CUSTOMER SUPPORT SYSTEM =====
  
  // Create support ticket
  app.post("/api/support/tickets", async (req, res) => {
    try {
      const { email, name, subject, message, category } = req.body;
      
      if (!email || !subject || !message) {
        return res.status(400).json({ error: "Email, subject and message are required" });
      }
      
      // Create ticket
      const ticket = await storage.createSupportTicket({
        customerEmail: email,
        customerName: name,
        subject,
        message,
        category: category || "general",
        priority: "normal",
        status: "open",
      });
      
      // Create initial message
      await storage.createSupportMessage({
        ticketId: ticket.id,
        senderType: "customer",
        message,
        isAiGenerated: false,
      });
      
      // Generate AI auto-response
      const aiResponse = generateSupportResponse(subject, message, category);
      
      // Save AI response
      await storage.createSupportMessage({
        ticketId: ticket.id,
        senderType: "support",
        message: aiResponse,
        isAiGenerated: true,
      });
      
      // Update ticket with AI response
      await storage.updateSupportTicket(ticket.id, {
        aiResponse,
        respondedAt: new Date(),
      });
      
      await storage.createActivityLog({
        action: "support_ticket_created",
        category: "support",
        details: `New support ticket from ${email}: ${subject}`,
        severity: "info",
      });
      
      res.json({
        success: true,
        ticketId: ticket.id,
        aiResponse,
        message: "Your ticket has been submitted. Our AI assistant has provided an initial response.",
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to create ticket" });
    }
  });

  // Get support tickets
  app.get("/api/support/tickets", async (req, res) => {
    try {
      const { status } = req.query;
      const tickets = await storage.getSupportTickets(status as string);
      res.json(tickets);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to get tickets" });
    }
  });

  // Get single ticket with messages
  app.get("/api/support/tickets/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const ticket = await storage.getSupportTicket(id);
      
      if (!ticket) {
        return res.status(404).json({ error: "Ticket not found" });
      }
      
      const messages = await storage.getTicketMessages(id);
      
      res.json({ ticket, messages });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to get ticket" });
    }
  });

  // Reply to ticket
  app.post("/api/support/tickets/:id/reply", async (req, res) => {
    try {
      const { id } = req.params;
      const { message, senderType } = req.body;
      
      const ticket = await storage.getSupportTicket(id);
      if (!ticket) {
        return res.status(404).json({ error: "Ticket not found" });
      }
      
      // Create reply message
      await storage.createSupportMessage({
        ticketId: id,
        senderType: senderType || "customer",
        message,
        isAiGenerated: false,
      });
      
      // If customer reply, generate AI response
      if (senderType === "customer" || !senderType) {
        const aiResponse = generateSupportResponse(ticket.subject, message, ticket.category || "general");
        
        await storage.createSupportMessage({
          ticketId: id,
          senderType: "support",
          message: aiResponse,
          isAiGenerated: true,
        });
        
        await storage.updateSupportTicket(id, {
          aiResponse,
          respondedAt: new Date(),
        });
        
        res.json({ success: true, aiResponse });
      } else {
        res.json({ success: true });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to reply to ticket" });
    }
  });

  // Close ticket
  app.post("/api/support/tickets/:id/close", async (req, res) => {
    try {
      const { id } = req.params;
      
      await storage.updateSupportTicket(id, {
        status: "closed",
        resolvedAt: new Date(),
      });
      
      res.json({ success: true, message: "Ticket closed" });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to close ticket" });
    }
  });

  // ===== TEST ENVIRONMENT ENDPOINTS =====
  
  // Simulate a test purchase (for testing the delivery system)
  app.post("/api/test/simulate-purchase", async (req, res) => {
    try {
      const { email, name, productName, amount } = req.body;
      
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      
      // Generate test transaction ID
      const testTransactionId = `TEST_${Date.now()}_${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      
      // Generate secure access token
      const crypto = await import("crypto");
      const accessToken = `priv_${crypto.randomBytes(32).toString('hex')}`;
      
      // Create purchase record
      const purchase = await storage.createCustomerPurchase({
        email,
        name: name || "Test Customer",
        transactionId: testTransactionId,
        productName: productName || "Privately App (TEST)",
        amount: (amount || "47.00").toString(),
        accessToken,
        purchasedAt: new Date(),
      });
      
      // Log the test sale
      await storage.createActivityLog({
        action: "test_sale",
        category: "testing",
        details: `Test purchase simulated: ${testTransactionId} - ${email}`,
        severity: "info",
      });
      
      console.log(`[TEST] Simulated purchase: ${testTransactionId} - ${email}`);
      
      res.json({ 
        success: true,
        message: "Test purchase created successfully",
        purchase: {
          id: purchase.id,
          transactionId: testTransactionId,
          email,
          accessToken,
          downloadUrl: `/thank-you/${accessToken}`,
          verifyUrl: `/api/purchase/verify/${accessToken}`,
        }
      });
    } catch (error: any) {
      console.error("[TEST] Error simulating purchase:", error);
      res.status(500).json({ error: error.message || "Failed to simulate purchase" });
    }
  });
  
  // Test the automation content generation
  app.post("/api/test/generate-content", async (req, res) => {
    try {
      // Run the auto-generate content function
      await autoGenerateContent();
      
      // Get the latest blog posts to show what was generated
      const blogPosts = await storage.getBlogPosts();
      const recentPosts = blogPosts.slice(0, 5);
      
      await storage.createActivityLog({
        action: "test_content_generated",
        category: "testing",
        details: `Test content generation triggered`,
        severity: "info",
      });
      
      res.json({
        success: true,
        message: "Content generation triggered successfully",
        recentPosts: recentPosts.map(p => ({
          id: p.id,
          title: p.title,
          status: p.status,
          createdAt: p.createdAt,
        })),
      });
    } catch (error: any) {
      console.error("[TEST] Error generating content:", error);
      res.status(500).json({ error: error.message || "Failed to generate test content" });
    }
  });
  
  // Get test environment status
  app.get("/api/test/status", async (req, res) => {
    try {
      const purchases = await storage.getCustomerPurchases();
      const testPurchases = purchases.filter(p => p.transactionId.startsWith("TEST_"));
      
      const tickets = await storage.getSupportTickets();
      const products = await storage.getAffiliateProducts();
      const automationStatus = getAutomationStatus();
      const healthStatus = await getSystemHealth();
      
      res.json({
        testEnvironment: {
          active: true,
          testPurchases: testPurchases.length,
          totalPurchases: purchases.length,
          supportTickets: tickets.length,
          products: products.length,
        },
        automation: automationStatus,
        health: healthStatus,
        endpoints: {
          simulatePurchase: "POST /api/test/simulate-purchase",
          generateContent: "POST /api/test/generate-content",
          verifyPurchase: "GET /api/purchase/verify/:token",
          thankYouPage: "/thank-you/:token",
          supportPage: "/support",
        }
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to get test status" });
    }
  });
  
  // Clear test data (only removes TEST_ prefixed transactions)
  app.delete("/api/test/clear", async (req, res) => {
    try {
      const purchases = await storage.getCustomerPurchases();
      const testPurchases = purchases.filter(p => p.transactionId.startsWith("TEST_"));
      
      let deleted = 0;
      for (const purchase of testPurchases) {
        await storage.deleteCustomerPurchase(purchase.id);
        deleted++;
      }
      
      await storage.createActivityLog({
        action: "test_data_cleared",
        category: "testing",
        details: `Cleared ${deleted} test purchases`,
        severity: "info",
      });
      
      res.json({
        success: true,
        message: `Cleared ${deleted} test purchases`,
        deleted,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to clear test data" });
    }
  });

  return httpServer;
}

// AI Support Response Generator
function generateSupportResponse(subject: string, message: string, category: string): string {
  const subjectLower = subject.toLowerCase();
  const messageLower = message.toLowerCase();
  
  // Download/Access issues
  if (subjectLower.includes("download") || messageLower.includes("download") || 
      messageLower.includes("access") || messageLower.includes("can't get")) {
    return `Thank you for reaching out! I understand you're having trouble accessing your download.

Here's what you can do:
1. Check your email for the purchase confirmation with your unique download link
2. If you can't find it, check your spam folder
3. Make sure you're using the same email address you used for purchase

If you still can't access your download, please reply with your ClickBank receipt number and we'll resend your access link right away.

Your satisfaction is our priority!`;
  }
  
  // Refund requests
  if (subjectLower.includes("refund") || messageLower.includes("refund") || 
      messageLower.includes("money back")) {
    return `Thank you for contacting us about a refund.

We have a 60-day money-back guarantee through ClickBank. To request a refund:
1. Log into your ClickBank account
2. Go to Order History
3. Find your purchase and click "Get Support" or "Request Refund"

Alternatively, you can contact ClickBank directly at:
- Website: clkbank.com/#!/
- Phone: 1-800-390-6035

We're sorry to see you go. If there's anything we can do to improve your experience, please let us know!`;
  }
  
  // Technical issues
  if (subjectLower.includes("error") || subjectLower.includes("bug") || 
      messageLower.includes("not working") || messageLower.includes("broken")) {
    return `Thank you for reporting this issue! I'm sorry you're experiencing technical difficulties.

To help resolve this quickly, please provide:
1. What specifically isn't working?
2. Any error messages you're seeing
3. Your device type and browser (if applicable)
4. Steps to reproduce the issue

Our technical team will review your case and get back to you with a solution as soon as possible.

In the meantime, try:
- Clearing your browser cache
- Using a different browser
- Restarting the application

Thank you for your patience!`;
  }
  
  // Setup/Getting started
  if (subjectLower.includes("setup") || subjectLower.includes("start") || 
      messageLower.includes("how to") || messageLower.includes("getting started")) {
    return `Welcome to Privately! I'm excited to help you get started.

Here's a quick setup guide:
1. Download and install the application
2. Launch the dashboard
3. Go to "Account Setup" to connect your affiliate networks
4. Add your ClickBank API credentials in the settings
5. The automation engine will handle the rest!

Key features to explore:
- Dashboard: Overview of your security and earnings
- Automation: Set up hands-free affiliate marketing
- Analytics: Track your performance in real-time

If you need help with any specific feature, just let me know!`;
  }
  
  // Default response
  return `Thank you for contacting Privately Support!

I've received your message and want to help you as quickly as possible.

Based on your inquiry about "${subject}", here's what I can tell you:

Our support team actively monitors all tickets and aims to respond within 24 hours for complex issues. For immediate assistance:

1. Check our FAQ section for common questions
2. Review the setup guide in the application
3. Make sure your software is up to date

If this is urgent, please reply with more details about your issue and we'll prioritize your request.

Is there anything specific I can help clarify right now?`;
}
