# Privately - Android Security & Affiliate Marketing Dashboard

A powerful dual-purpose application combining privacy management with automated affiliate marketing.

## Features

### Privacy & Security Dashboard
- Identity compartmentalization
- Network connection monitoring
- App permission auditing
- Data breach alerts
- Encrypted vault storage
- Activity logging

### Affiliate Marketing System
- ClickBank API integration
- Automated product discovery
- Real-time sales tracking
- AI-powered campaign optimization
- Self-healing error recovery
- Automated blog content generation

## Setup Instructions

### 1. Install Dependencies
```bash
npm install
```

### 2. Set Up Database
Create a PostgreSQL database and set the `DATABASE_URL` environment variable.

### 3. Configure Environment Variables
Create these secrets in your Replit environment:

- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Random string for session encryption

### 4. Configure ClickBank (Optional)
Add your ClickBank credentials:
- `CLICKBANK_API_KEY` - Your ClickBank API key
- `CLICKBANK_CLERK_KEY` - Your clerk API key
- `CLICKBANK_ACCOUNT_ID` - Your ClickBank account nickname

### 5. Run Database Migrations
```bash
npm run db:push
```

### 6. Start the Application
```bash
npm run dev
```

## Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **Styling**: Cyberpunk theme with neon accents

## License

Proprietary software. All rights reserved.
