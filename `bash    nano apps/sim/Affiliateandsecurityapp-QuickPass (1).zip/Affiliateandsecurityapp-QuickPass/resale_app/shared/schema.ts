import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Affiliate Networks (ClickBank, ShareASale, CJ, etc.)
export const affiliateNetworks = pgTable("affiliate_networks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  apiKey: text("api_key"),
  accountId: text("account_id"),
  apiSecret: text("api_secret"),
  status: text("status").notNull().default("pending"),
  lastSync: timestamp("last_sync"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAffiliateNetworkSchema = createInsertSchema(affiliateNetworks).omit({
  id: true,
  lastSync: true,
  createdAt: true,
});

export type InsertAffiliateNetwork = z.infer<typeof insertAffiliateNetworkSchema>;
export type AffiliateNetwork = typeof affiliateNetworks.$inferSelect;

// Affiliate Products/Offers
export const affiliateProducts = pgTable("affiliate_products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  networkId: varchar("network_id").references(() => affiliateNetworks.id),
  externalId: text("external_id"),
  name: text("name").notNull(),
  description: text("description"),
  affiliateLink: text("affiliate_link").notNull(),
  commission: decimal("commission", { precision: 10, scale: 2 }),
  commissionType: text("commission_type").default("percentage"),
  category: text("category"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAffiliateProductSchema = createInsertSchema(affiliateProducts).omit({
  id: true,
  createdAt: true,
});

export type InsertAffiliateProduct = z.infer<typeof insertAffiliateProductSchema>;
export type AffiliateProduct = typeof affiliateProducts.$inferSelect;

// Earnings/Transactions
export const affiliateEarnings = pgTable("affiliate_earnings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  networkId: varchar("network_id").references(() => affiliateNetworks.id),
  productId: varchar("product_id").references(() => affiliateProducts.id),
  transactionId: text("transaction_id"),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("USD"),
  status: text("status").notNull().default("pending"),
  saleDate: timestamp("sale_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAffiliateEarningSchema = createInsertSchema(affiliateEarnings).omit({
  id: true,
  createdAt: true,
});

export type InsertAffiliateEarning = z.infer<typeof insertAffiliateEarningSchema>;
export type AffiliateEarning = typeof affiliateEarnings.$inferSelect;

// Click Tracking
export const affiliateClicks = pgTable("affiliate_clicks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productId: varchar("product_id").references(() => affiliateProducts.id),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  referrer: text("referrer"),
  clickedAt: timestamp("clicked_at").defaultNow(),
});

export const insertAffiliateClickSchema = createInsertSchema(affiliateClicks).omit({
  id: true,
  clickedAt: true,
});

export type InsertAffiliateClick = z.infer<typeof insertAffiliateClickSchema>;
export type AffiliateClick = typeof affiliateClicks.$inferSelect;

// Payouts
export const affiliatePayouts = pgTable("affiliate_payouts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  networkId: varchar("network_id").references(() => affiliateNetworks.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("USD"),
  status: text("status").notNull().default("pending"),
  payoutDate: timestamp("payout_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAffiliatePayoutSchema = createInsertSchema(affiliatePayouts).omit({
  id: true,
  createdAt: true,
});

export type InsertAffiliatePayout = z.infer<typeof insertAffiliatePayoutSchema>;
export type AffiliatePayout = typeof affiliatePayouts.$inferSelect;

// Secure Vault Items (encrypted storage)
export const secureVaultItems = pgTable("secure_vault_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull().default("text"),
  encryptedContent: text("encrypted_content"),
  category: text("category"),
  tags: text("tags").array(),
  isLocked: boolean("is_locked").default(true),
  lastAccessed: timestamp("last_accessed"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertSecureVaultItemSchema = createInsertSchema(secureVaultItems).omit({
  id: true,
  lastAccessed: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertSecureVaultItem = z.infer<typeof insertSecureVaultItemSchema>;
export type SecureVaultItem = typeof secureVaultItems.$inferSelect;

// Activity Logs (security audit trail)
export const activityLogs = pgTable("activity_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  action: text("action").notNull(),
  category: text("category").notNull(),
  details: text("details"),
  severity: text("severity").default("info"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;

// Social Media Accounts (for automated posting)
export const socialAccounts = pgTable("social_accounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  platform: text("platform").notNull(),
  accountName: text("account_name"),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  tokenExpiry: timestamp("token_expiry"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSocialAccountSchema = createInsertSchema(socialAccounts).omit({
  id: true,
  createdAt: true,
});

export type InsertSocialAccount = z.infer<typeof insertSocialAccountSchema>;
export type SocialAccount = typeof socialAccounts.$inferSelect;

// Marketplace Products (products to promote from affiliate networks)
export const marketplaceProducts = pgTable("marketplace_products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  networkId: varchar("network_id").references(() => affiliateNetworks.id),
  externalId: text("external_id"),
  name: text("name").notNull(),
  description: text("description"),
  vendorId: text("vendor_id"),
  category: text("category"),
  gravity: decimal("gravity", { precision: 10, scale: 2 }),
  commission: decimal("commission", { precision: 10, scale: 2 }),
  initialPrice: decimal("initial_price", { precision: 10, scale: 2 }),
  avgEarningsPerSale: decimal("avg_earnings_per_sale", { precision: 10, scale: 2 }),
  hopLink: text("hop_link"),
  imageUrl: text("image_url"),
  isPromoting: boolean("is_promoting").default(false),
  lastUpdated: timestamp("last_updated").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMarketplaceProductSchema = createInsertSchema(marketplaceProducts).omit({
  id: true,
  lastUpdated: true,
  createdAt: true,
});

export type InsertMarketplaceProduct = z.infer<typeof insertMarketplaceProductSchema>;
export type MarketplaceProduct = typeof marketplaceProducts.$inferSelect;

// Campaigns (automated social media posts)
export const campaigns = pgTable("campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  productId: varchar("product_id").references(() => marketplaceProducts.id),
  socialAccountId: varchar("social_account_id").references(() => socialAccounts.id),
  postContent: text("post_content"),
  hashtags: text("hashtags").array(),
  scheduledTime: timestamp("scheduled_time"),
  status: text("status").notNull().default("draft"),
  postUrl: text("post_url"),
  impressions: integer("impressions").default(0),
  clicks: integer("clicks").default(0),
  conversions: integer("conversions").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCampaignSchema = createInsertSchema(campaigns).omit({
  id: true,
  postUrl: true,
  impressions: true,
  clicks: true,
  conversions: true,
  createdAt: true,
});

export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Campaign = typeof campaigns.$inferSelect;

// Post Queue (for rate limiting and scheduling)
export const postQueue = pgTable("post_queue", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: varchar("campaign_id").references(() => campaigns.id),
  socialAccountId: varchar("social_account_id").references(() => socialAccounts.id),
  content: text("content").notNull(),
  hashtags: text("hashtags").array(),
  scheduledFor: timestamp("scheduled_for").notNull(),
  priority: integer("priority").default(5),
  status: text("status").notNull().default("pending"),
  attempts: integer("attempts").default(0),
  maxAttempts: integer("max_attempts").default(3),
  lastError: text("last_error"),
  postUrl: text("post_url"),
  processedAt: timestamp("processed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPostQueueSchema = createInsertSchema(postQueue).omit({
  id: true,
  attempts: true,
  lastError: true,
  postUrl: true,
  processedAt: true,
  createdAt: true,
});

export type InsertPostQueue = z.infer<typeof insertPostQueueSchema>;
export type PostQueue = typeof postQueue.$inferSelect;

// Notification Settings
export const notificationSettings = pgTable("notification_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  emailEnabled: boolean("email_enabled").default(false),
  email: text("email"),
  pushEnabled: boolean("push_enabled").default(true),
  notifyOnSale: boolean("notify_on_sale").default(true),
  notifyOnFailure: boolean("notify_on_failure").default(true),
  notifyDailyReport: boolean("notify_daily_report").default(true),
  notifyWeeklyReport: boolean("notify_weekly_report").default(true),
  quietHoursStart: integer("quiet_hours_start"),
  quietHoursEnd: integer("quiet_hours_end"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertNotificationSettingsSchema = createInsertSchema(notificationSettings).omit({
  id: true,
  updatedAt: true,
});

export type InsertNotificationSettings = z.infer<typeof insertNotificationSettingsSchema>;
export type NotificationSettings = typeof notificationSettings.$inferSelect;

// Notifications (log of sent notifications)
export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  data: text("data"),
  isRead: boolean("is_read").default(false),
  sentAt: timestamp("sent_at").defaultNow(),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  isRead: true,
  sentAt: true,
});

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

// A/B Test Variants
export const abTestVariants = pgTable("ab_test_variants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: varchar("campaign_id").references(() => campaigns.id),
  variantName: text("variant_name").notNull(),
  content: text("content").notNull(),
  hashtags: text("hashtags").array(),
  impressions: integer("impressions").default(0),
  clicks: integer("clicks").default(0),
  conversions: integer("conversions").default(0),
  conversionRate: decimal("conversion_rate", { precision: 5, scale: 2 }).default("0"),
  isWinner: boolean("is_winner").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAbTestVariantSchema = createInsertSchema(abTestVariants).omit({
  id: true,
  impressions: true,
  clicks: true,
  conversions: true,
  conversionRate: true,
  isWinner: true,
  createdAt: true,
});

export type InsertAbTestVariant = z.infer<typeof insertAbTestVariantSchema>;
export type AbTestVariant = typeof abTestVariants.$inferSelect;

// Post Templates
export const postTemplates = pgTable("post_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  platform: text("platform").notNull(),
  category: text("category"),
  content: text("content").notNull(),
  hashtags: text("hashtags").array(),
  usageCount: integer("usage_count").default(0),
  conversionRate: decimal("conversion_rate", { precision: 5, scale: 2 }).default("0"),
  isBuiltIn: boolean("is_built_in").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPostTemplateSchema = createInsertSchema(postTemplates).omit({
  id: true,
  usageCount: true,
  conversionRate: true,
  createdAt: true,
});

export type InsertPostTemplate = z.infer<typeof insertPostTemplateSchema>;
export type PostTemplate = typeof postTemplates.$inferSelect;

// Analytics Snapshots (for historical tracking)
export const analyticsSnapshots = pgTable("analytics_snapshots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: timestamp("date").notNull(),
  totalEarnings: decimal("total_earnings", { precision: 10, scale: 2 }).default("0"),
  totalClicks: integer("total_clicks").default(0),
  totalConversions: integer("total_conversions").default(0),
  totalImpressions: integer("total_impressions").default(0),
  topProductId: varchar("top_product_id"),
  topPlatform: text("top_platform"),
  conversionRate: decimal("conversion_rate", { precision: 5, scale: 2 }).default("0"),
  roi: decimal("roi", { precision: 10, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAnalyticsSnapshotSchema = createInsertSchema(analyticsSnapshots).omit({
  id: true,
  createdAt: true,
});

export type InsertAnalyticsSnapshot = z.infer<typeof insertAnalyticsSnapshotSchema>;
export type AnalyticsSnapshot = typeof analyticsSnapshots.$inferSelect;

// Rate Limits (track API usage to avoid bans)
export const rateLimits = pgTable("rate_limits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  platform: text("platform").notNull(),
  accountId: varchar("account_id").references(() => socialAccounts.id),
  postsToday: integer("posts_today").default(0),
  postsThisHour: integer("posts_this_hour").default(0),
  lastPostAt: timestamp("last_post_at"),
  dailyLimit: integer("daily_limit").default(10),
  hourlyLimit: integer("hourly_limit").default(2),
  isPaused: boolean("is_paused").default(false),
  pauseReason: text("pause_reason"),
  pauseUntil: timestamp("pause_until"),
  resetAt: timestamp("reset_at"),
});

export const insertRateLimitSchema = createInsertSchema(rateLimits).omit({
  id: true,
});

export type InsertRateLimit = z.infer<typeof insertRateLimitSchema>;
export type RateLimit = typeof rateLimits.$inferSelect;

// Sales Tracking (real-time ClickBank notifications)
export const salesTracking = pgTable("sales_tracking", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  networkId: varchar("network_id").references(() => affiliateNetworks.id),
  productId: varchar("product_id"),
  transactionId: text("transaction_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  commission: decimal("commission", { precision: 10, scale: 2 }).notNull(),
  customerEmail: text("customer_email"),
  trackingId: text("tracking_id"),
  campaignId: varchar("campaign_id").references(() => campaigns.id),
  status: text("status").notNull().default("pending"),
  saleType: text("sale_type").default("initial"),
  refundAmount: decimal("refund_amount", { precision: 10, scale: 2 }),
  isNotified: boolean("is_notified").default(false),
  saleDate: timestamp("sale_date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSalesTrackingSchema = createInsertSchema(salesTracking).omit({
  id: true,
  isNotified: true,
  createdAt: true,
});

export type InsertSalesTracking = z.infer<typeof insertSalesTrackingSchema>;
export type SalesTracking = typeof salesTracking.$inferSelect;

// Blog Posts (automated SEO content - no social media needed)
export const blogPosts = pgTable("blog_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productId: varchar("product_id").references(() => marketplaceProducts.id),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  content: text("content").notNull(),
  excerpt: text("excerpt"),
  metaTitle: text("meta_title"),
  metaDescription: text("meta_description"),
  keywords: text("keywords").array(),
  category: text("category"),
  affiliateLink: text("affiliate_link"),
  viewCount: integer("view_count").default(0),
  clickCount: integer("click_count").default(0),
  conversionCount: integer("conversion_count").default(0),
  status: text("status").notNull().default("draft"),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertBlogPostSchema = createInsertSchema(blogPosts).omit({
  id: true,
  viewCount: true,
  clickCount: true,
  conversionCount: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;
export type BlogPost = typeof blogPosts.$inferSelect;

// Content Generation Queue (for automatic blog post creation)
export const contentQueue = pgTable("content_queue", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productId: varchar("product_id").references(() => marketplaceProducts.id),
  contentType: text("content_type").notNull().default("review"),
  priority: integer("priority").default(5),
  status: text("status").notNull().default("pending"),
  attempts: integer("attempts").default(0),
  lastError: text("last_error"),
  generatedBlogId: varchar("generated_blog_id").references(() => blogPosts.id),
  scheduledFor: timestamp("scheduled_for"),
  processedAt: timestamp("processed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertContentQueueSchema = createInsertSchema(contentQueue).omit({
  id: true,
  attempts: true,
  lastError: true,
  generatedBlogId: true,
  processedAt: true,
  createdAt: true,
});

export type InsertContentQueue = z.infer<typeof insertContentQueueSchema>;
export type ContentQueue = typeof contentQueue.$inferSelect;

// Customer Purchases (for instant delivery after ClickBank payment)
export const customerPurchases = pgTable("customer_purchases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull(),
  name: text("name"),
  transactionId: text("transaction_id").notNull().unique(),
  productName: text("product_name").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("USD"),
  paymentMethod: text("payment_method").default("clickbank"),
  status: text("status").notNull().default("completed"),
  downloadCount: integer("download_count").default(0),
  accessToken: text("access_token"),
  purchasedAt: timestamp("purchased_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCustomerPurchaseSchema = createInsertSchema(customerPurchases).omit({
  id: true,
  downloadCount: true,
  createdAt: true,
});

export type InsertCustomerPurchase = z.infer<typeof insertCustomerPurchaseSchema>;
export type CustomerPurchase = typeof customerPurchases.$inferSelect;

// Support Tickets (automated customer service)
export const supportTickets = pgTable("support_tickets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerEmail: text("customer_email").notNull(),
  customerName: text("customer_name"),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  category: text("category").default("general"),
  priority: text("priority").default("normal"),
  status: text("status").notNull().default("open"),
  aiResponse: text("ai_response"),
  respondedAt: timestamp("responded_at"),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSupportTicketSchema = createInsertSchema(supportTickets).omit({
  id: true,
  aiResponse: true,
  respondedAt: true,
  resolvedAt: true,
  createdAt: true,
});

export type InsertSupportTicket = z.infer<typeof insertSupportTicketSchema>;
export type SupportTicket = typeof supportTickets.$inferSelect;

// Support Ticket Messages (conversation thread)
export const supportMessages = pgTable("support_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ticketId: varchar("ticket_id").references(() => supportTickets.id),
  senderType: text("sender_type").notNull().default("customer"),
  message: text("message").notNull(),
  isAiGenerated: boolean("is_ai_generated").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSupportMessageSchema = createInsertSchema(supportMessages).omit({
  id: true,
  createdAt: true,
});

export type InsertSupportMessage = z.infer<typeof insertSupportMessageSchema>;
export type SupportMessage = typeof supportMessages.$inferSelect;
