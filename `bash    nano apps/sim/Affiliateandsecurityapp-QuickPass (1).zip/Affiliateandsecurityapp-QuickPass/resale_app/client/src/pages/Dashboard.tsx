import { Sidebar } from "@/components/layout/Sidebar";
import { SecurityScore } from "@/components/dashboard/SecurityScore";
import { ThreatMap } from "@/components/dashboard/ThreatMap";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Wifi, Globe, Smartphone, Search, ScanEye } from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { useIsMobile } from "@/hooks/use-mobile";

export default function Dashboard() {
  const { toast } = useToast();
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [showScanner, setShowScanner] = useState(false);
  const isMobile = useIsMobile();

  const handleQuickScan = () => {
    toast({
      title: "Initiating Quick Scan",
      description: "Checking system integrity and background processes...",
    });
    setShowScanner(true);
    setScanProgress(0);
    setIsScanning(true);

    // Simulate scan
    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsScanning(false);
          toast({
            title: "Scan Complete",
            description: "No immediate threats detected. System secure.",
            variant: "default",
            className: "border-primary text-primary",
          });
          return 100;
        }
        return prev + 5;
      });
    }, 100);
  };

  const handleLockdown = () => {
    toast({
      title: "LOCKDOWN ACTIVATED",
      description: "All non-essential connections severed. Biometric auth required for app access.",
      variant: "destructive",
    });
  };

  const handleVPN = () => {
    toast({
      title: "Secure VPN Connected",
      description: "Traffic routed through encrypted tunnel (Tokyo Node #429).",
      className: "border-primary text-primary",
    });
  };

  const handlePrivateBrowsing = () => {
    toast({
      title: "Incognito Launcher",
      description: "Opening secure browser session with temporary fingerprint...",
    });
    setTimeout(() => {
      window.open("about:blank", "_blank");
    }, 1000);
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative ${isMobile ? 'pt-16' : ''}`}>
        <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6 md:space-y-8">
          
          {/* Header */}
          <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-white">System Status</h1>
              <p className="text-sm md:text-base text-muted-foreground">Real-time protection active • Samsung S25 Ultra</p>
            </div>
            <div className="flex gap-4 w-full md:w-auto">
              <Button 
                variant="outline" 
                onClick={handleQuickScan}
                className="flex-1 md:flex-none border-primary/50 text-primary hover:bg-primary/10 font-mono text-xs uppercase"
              >
                Quick Scan
              </Button>
              <Button 
                onClick={handleLockdown}
                className="flex-1 md:flex-none bg-primary text-primary-foreground hover:bg-primary/90 font-mono text-xs uppercase shadow-[0_0_15px_var(--color-primary)]"
              >
                Activate Lockdown
              </Button>
            </div>
          </header>

          {/* Top Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            {[
              { label: "Apps Monitored", value: "142", icon: Smartphone, status: "Active" },
              { label: "Network Shield", value: "On", icon: Globe, status: "Protected" },
              { label: "Data Leaks", value: "0", icon: Shield, status: "Clean" },
              { label: "Active Conns", value: "12", icon: Wifi, status: "Encrypted" },
            ].map((stat, i) => (
              <Card key={i} className="glass-panel border-white/5 bg-card/50">
                <CardContent className="p-3 md:p-4 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] md:text-xs text-muted-foreground uppercase font-mono mb-1">{stat.label}</p>
                    <h3 className="text-xl md:text-2xl font-display font-bold">{stat.value}</h3>
                    <span className="text-[10px] text-primary flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                      {stat.status}
                    </span>
                  </div>
                  <div className="p-2 md:p-3 rounded-full bg-primary/10 text-primary">
                    <stat.icon size={16} className="md:w-5 md:h-5" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Main Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Security Score - Large Card */}
            <Card className="lg:col-span-1 glass-panel border-white/5">
              <CardHeader>
                <CardTitle className="text-lg font-medium">Security Index</CardTitle>
              </CardHeader>
              <CardContent className="h-[300px]">
                <SecurityScore />
                <div className="mt-4 grid grid-cols-2 gap-4 text-center">
                  <div className="p-2 rounded bg-white/5">
                    <div className="text-2xl font-bold text-primary">A+</div>
                    <div className="text-xs text-muted-foreground">Identity Score</div>
                  </div>
                  <div className="p-2 rounded bg-white/5">
                    <div className="text-2xl font-bold text-primary">98%</div>
                    <div className="text-xs text-muted-foreground">Network Health</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Threat Map - Wide Card */}
            <Card className="lg:col-span-2 glass-panel border-white/5">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-medium">Global Connection Tracker</CardTitle>
                <div className="flex gap-2">
                  <span className="flex items-center gap-1 text-xs text-muted-foreground"><div className="w-2 h-2 rounded-full bg-primary" /> Safe</span>
                  <span className="flex items-center gap-1 text-xs text-muted-foreground"><div className="w-2 h-2 rounded-full bg-destructive" /> Threat</span>
                </div>
              </CardHeader>
              <CardContent>
                <ThreatMap />
                <div className="mt-4 grid grid-cols-3 gap-4 text-xs font-mono text-muted-foreground">
                  <div>OUTBOUND: 4.2 MB/s</div>
                  <div>INBOUND: 1.1 MB/s</div>
                  <div className="text-right">LATENCY: 42ms</div>
                </div>
              </CardContent>
            </Card>

            {/* Activity Feed */}
            <Card className="lg:col-span-2 glass-panel border-white/5">
              <CardHeader>
                <CardTitle className="text-lg font-medium">Recent Events</CardTitle>
              </CardHeader>
              <CardContent>
                <ActivityFeed />
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="lg:col-span-1 glass-panel border-white/5 bg-gradient-to-b from-primary/5 to-transparent">
              <CardHeader>
                <CardTitle className="text-lg font-medium">Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button onClick={() => toast({ title: "Auditor Running", description: "Scanning app permissions in background." })} variant="secondary" className="w-full justify-start gap-2 bg-white/5 hover:bg-white/10 border border-white/10">
                  <Shield size={16} className="text-primary" /> Permission Audit
                </Button>
                <Button onClick={handlePrivateBrowsing} variant="secondary" className="w-full justify-start gap-2 bg-white/5 hover:bg-white/10 border border-white/10">
                  <Globe size={16} className="text-primary" /> Anonymous Browsing
                </Button>
                <Button onClick={handleVPN} variant="secondary" className="w-full justify-start gap-2 bg-white/5 hover:bg-white/10 border border-white/10">
                  <Wifi size={16} className="text-primary" /> VPN Settings
                </Button>
                <Button onClick={() => setShowScanner(true)} variant="secondary" className="w-full justify-start gap-2 bg-white/5 hover:bg-white/10 border border-white/10">
                  <ScanEye size={16} className="text-primary" /> Digital Footprint Scan
                </Button>
              </CardContent>
            </Card>

          </div>
        </div>

        {/* Scanner Modal */}
        <Dialog open={showScanner} onOpenChange={setShowScanner}>
          <DialogContent className="bg-card border-white/10 text-foreground sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <ScanEye className="text-primary animate-pulse" /> 
                {isScanning ? "Scanning Digital Footprint..." : "Scan Complete"}
              </DialogTitle>
              <DialogDescription>
                Searching public databases, social media, and dark web for your personal information.
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-6 space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-mono text-muted-foreground">
                  <span>PROGRESS</span>
                  <span>{scanProgress}%</span>
                </div>
                <Progress value={scanProgress} className="h-2 bg-white/10" />
              </div>
              
              <div className="space-y-2">
                <p className="text-sm font-medium">Live Log:</p>
                <div className="h-32 bg-black/40 rounded-md p-3 font-mono text-xs text-green-500/80 overflow-y-auto space-y-1">
                   {scanProgress > 10 && <div>[OK] Database connection established...</div>}
                   {scanProgress > 25 && <div>[SCAN] Checking public social profiles...</div>}
                   {scanProgress > 40 && <div>[WARN] Partial match found on LinkedIn...</div>}
                   {scanProgress > 60 && <div>[SCAN] Deep web search initiated...</div>}
                   {scanProgress > 80 && <div>[OK] No critical password leaks found...</div>}
                   {scanProgress >= 100 && <div className="text-primary font-bold">[COMPLETE] Scan finished. 0 Critical Threats.</div>}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>

      </main>
    </div>
  );
}
