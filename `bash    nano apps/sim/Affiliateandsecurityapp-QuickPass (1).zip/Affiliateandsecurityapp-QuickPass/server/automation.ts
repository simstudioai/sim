import { storage } from "./storage";
import { getAyrshareClient, postToAyrshare } from "./ayrshare";

interface AutomationConfig {
  autoDiscoverProducts: boolean;
  autoGenerateContent: boolean;
  postingFrequencyMinutes: number;
  maxDailyPosts: number;
  maxHourlyPosts: number;
  retryAttempts: number;
  retryDelayMinutes: number;
}

// Ayrshare recommended daily posting limits per platform
const PLATFORM_DAILY_LIMITS: Record<string, number> = {
  twitter: 50,
  facebook: 25,
  instagram: 30,
  linkedin: 25,
  tiktok: 15,
  pinterest: 20,
  youtube: 10,
  threads: 50,
  bluesky: 50,
};

// Track posts per platform to avoid exceeding limits
const dailyPostCounts: Map<string, { count: number; resetAt: Date }> = new Map();

function canPostToPlatform(platform: string): boolean {
  const limit = PLATFORM_DAILY_LIMITS[platform.toLowerCase()] || 10;
  const now = new Date();
  const tracking = dailyPostCounts.get(platform.toLowerCase());
  
  if (!tracking || tracking.resetAt < now) {
    const resetAt = new Date(now);
    resetAt.setHours(24, 0, 0, 0);
    dailyPostCounts.set(platform.toLowerCase(), { count: 0, resetAt });
    return true;
  }
  
  return tracking.count < limit;
}

function recordPostToPlatform(platform: string): void {
  const tracking = dailyPostCounts.get(platform.toLowerCase());
  if (tracking) {
    tracking.count++;
  }
}

const defaultConfig: AutomationConfig = {
  autoDiscoverProducts: true,
  autoGenerateContent: true,
  postingFrequencyMinutes: 60,
  maxDailyPosts: 10,
  maxHourlyPosts: 2,
  retryAttempts: 3,
  retryDelayMinutes: 15,
};

// ============ SELF-HEALING SYSTEM ============
interface SystemHealth {
  status: "healthy" | "degraded" | "critical";
  lastCheck: Date;
  components: {
    database: ComponentHealth;
    ayrshare: ComponentHealth;
    clickbank: ComponentHealth;
    automation: ComponentHealth;
  };
  issues: HealthIssue[];
  autoRecoveryAttempts: number;
  lastRecoveryAt: Date | null;
}

interface ComponentHealth {
  status: "healthy" | "degraded" | "down";
  lastSuccessful: Date | null;
  consecutiveFailures: number;
  errorMessage?: string;
}

interface HealthIssue {
  component: string;
  severity: "warning" | "error" | "critical";
  message: string;
  detectedAt: Date;
  resolvedAt?: Date;
  autoResolved: boolean;
}

interface CircuitBreaker {
  isOpen: boolean;
  failures: number;
  lastFailure: Date | null;
  nextRetry: Date | null;
  threshold: number;
  resetTimeout: number;
}

const circuitBreakers: Map<string, CircuitBreaker> = new Map();

const systemHealth: SystemHealth = {
  status: "healthy",
  lastCheck: new Date(),
  components: {
    database: { status: "healthy", lastSuccessful: null, consecutiveFailures: 0 },
    ayrshare: { status: "healthy", lastSuccessful: null, consecutiveFailures: 0 },
    clickbank: { status: "healthy", lastSuccessful: null, consecutiveFailures: 0 },
    automation: { status: "healthy", lastSuccessful: null, consecutiveFailures: 0 },
  },
  issues: [],
  autoRecoveryAttempts: 0,
  lastRecoveryAt: null,
};

// Circuit breaker pattern for external services
function getCircuitBreaker(service: string): CircuitBreaker {
  if (!circuitBreakers.has(service)) {
    circuitBreakers.set(service, {
      isOpen: false,
      failures: 0,
      lastFailure: null,
      nextRetry: null,
      threshold: 5,
      resetTimeout: 60000, // 1 minute
    });
  }
  return circuitBreakers.get(service)!;
}

function recordSuccess(service: string): void {
  const cb = getCircuitBreaker(service);
  cb.failures = 0;
  cb.isOpen = false;
  cb.lastFailure = null;
  cb.nextRetry = null;
  
  const component = systemHealth.components[service as keyof typeof systemHealth.components];
  if (component) {
    component.status = "healthy";
    component.lastSuccessful = new Date();
    component.consecutiveFailures = 0;
    component.errorMessage = undefined;
  }
}

function recordFailure(service: string, error: string): void {
  const cb = getCircuitBreaker(service);
  cb.failures++;
  cb.lastFailure = new Date();
  
  if (cb.failures >= cb.threshold) {
    cb.isOpen = true;
    cb.nextRetry = new Date(Date.now() + cb.resetTimeout);
    console.log(`[SELF-HEALING] Circuit breaker OPENED for ${service} after ${cb.failures} failures`);
    
    addHealthIssue({
      component: service,
      severity: "critical",
      message: `Service ${service} circuit breaker opened after ${cb.failures} consecutive failures: ${error}`,
      detectedAt: new Date(),
      autoResolved: false,
    });
  }
  
  const component = systemHealth.components[service as keyof typeof systemHealth.components];
  if (component) {
    component.consecutiveFailures++;
    component.errorMessage = error;
    component.status = cb.isOpen ? "down" : "degraded";
  }
}

function canCallService(service: string): boolean {
  const cb = getCircuitBreaker(service);
  
  if (!cb.isOpen) return true;
  
  // Check if we can retry (half-open state)
  if (cb.nextRetry && new Date() >= cb.nextRetry) {
    console.log(`[SELF-HEALING] Attempting half-open retry for ${service}`);
    return true;
  }
  
  return false;
}

function addHealthIssue(issue: HealthIssue): void {
  systemHealth.issues = systemHealth.issues.filter(i => 
    !(i.component === issue.component && !i.resolvedAt)
  );
  systemHealth.issues.push(issue);
  
  // Keep only last 100 issues
  if (systemHealth.issues.length > 100) {
    systemHealth.issues = systemHealth.issues.slice(-100);
  }
  
  updateOverallHealth();
}

function resolveHealthIssue(component: string, autoResolved: boolean = false): void {
  const issue = systemHealth.issues.find(i => i.component === component && !i.resolvedAt);
  if (issue) {
    issue.resolvedAt = new Date();
    issue.autoResolved = autoResolved;
    console.log(`[SELF-HEALING] Issue resolved for ${component}${autoResolved ? ' (auto-recovered)' : ''}`);
  }
  updateOverallHealth();
}

function updateOverallHealth(): void {
  const components = Object.values(systemHealth.components);
  const downCount = components.filter(c => c.status === "down").length;
  const degradedCount = components.filter(c => c.status === "degraded").length;
  
  if (downCount > 1) {
    systemHealth.status = "critical";
  } else if (downCount === 1 || degradedCount > 1) {
    systemHealth.status = "degraded";
  } else {
    systemHealth.status = "healthy";
  }
  
  systemHealth.lastCheck = new Date();
}

// ============ SELF-UPDATE SYSTEM ============
interface ContentStrategy {
  productId: string;
  platform: string;
  templateVariant: number;
  impressions: number;
  clicks: number;
  conversions: number;
  lastUsed: Date;
  performanceScore: number;
}

interface OptimizationConfig {
  contentRotationEnabled: boolean;
  autoOptimizeEnabled: boolean;
  abTestingEnabled: boolean;
  refreshIntervalMinutes: number;
  minDataPointsForOptimization: number;
  performanceThreshold: number;
}

const optimizationConfig: OptimizationConfig = {
  contentRotationEnabled: true,
  autoOptimizeEnabled: true,
  abTestingEnabled: true,
  refreshIntervalMinutes: 240, // 4 hours
  minDataPointsForOptimization: 10,
  performanceThreshold: 0.02, // 2% conversion threshold
};

const contentStrategies: Map<string, ContentStrategy[]> = new Map();
const productRotationQueue: string[] = [];
let lastContentRefresh = new Date(0); // Start with past date so first run triggers immediately
let lastOptimizationRun = new Date(0); // Start with past date so first run triggers immediately

// Content templates with A/B variants
const contentTemplates: Record<string, Record<number, (product: any) => string>> = {
  twitter: {
    0: (p) => `Just discovered ${p.name}! 🔥 ${p.description?.slice(0, 80) || 'Amazing product'}... ${p.hopLink}`,
    1: (p) => `🚀 ${p.name} is changing the game! ${p.commission}% off with my link: ${p.hopLink}`,
    2: (p) => `Been using ${p.name} for a week - here's my honest review 👇 ${p.hopLink}`,
    3: (p) => `${p.category} lovers, you NEED to see this: ${p.name} ${p.hopLink}`,
  },
  instagram: {
    0: (p) => `✨ NEW FIND ✨\n\n${p.name}\n\n${p.description?.slice(0, 150) || 'Must-have product!'}\n\n💰 Get it here: Link in bio\n#${p.category?.replace(/\s+/g, '')} #affiliate`,
    1: (p) => `GAME CHANGER 🙌\n\n${p.name} just dropped and it's incredible!\n\n⭐ ${p.commission}% savings available\n🔗 Link in bio`,
    2: (p) => `My honest review of ${p.name} 📝\n\n${p.description?.slice(0, 100) || 'Check this out!'}\n\nWorth every penny! Link in bio 👆`,
  },
  facebook: {
    0: (p) => `🔥 Just found something amazing!\n\n${p.name}\n\n${p.description || 'You have to check this out!'}\n\n👉 Learn more: ${p.hopLink}`,
    1: (p) => `HIGHLY RECOMMEND! 👏\n\n${p.name} has been a game-changer for me.\n\n✅ Great quality\n✅ Amazing results\n✅ Worth the investment\n\nCheck it out: ${p.hopLink}`,
  },
  tiktok: {
    0: (p) => `POV: You just found ${p.name} 🤯 Link in bio for the best deal! #fyp #viral`,
    1: (p) => `This ${p.category?.toLowerCase() || 'product'} hack changed everything 😱 Get ${p.name} - link in bio!`,
  },
  linkedin: {
    0: (p) => `I've been exploring solutions in ${p.category} and came across ${p.name}.\n\nThe results speak for themselves - highly recommend checking it out.\n\n${p.hopLink}`,
  },
};

function getOptimalTemplate(productId: string, platform: string): number {
  const key = `${productId}-${platform}`;
  const strategies = contentStrategies.get(key) || [];
  
  if (strategies.length < optimizationConfig.minDataPointsForOptimization) {
    // Not enough data, use random template for A/B testing
    const templates = contentTemplates[platform] || contentTemplates.twitter;
    return Math.floor(Math.random() * Object.keys(templates).length);
  }
  
  // Find best performing template
  const bestStrategy = strategies.reduce((best, current) => 
    current.performanceScore > best.performanceScore ? current : best
  );
  
  return bestStrategy.templateVariant;
}

function recordContentPerformance(
  productId: string, 
  platform: string, 
  templateVariant: number,
  metrics: { impressions?: number; clicks?: number; conversions?: number }
): void {
  const key = `${productId}-${platform}`;
  if (!contentStrategies.has(key)) {
    contentStrategies.set(key, []);
  }
  
  const strategies = contentStrategies.get(key)!;
  let strategy = strategies.find(s => s.templateVariant === templateVariant);
  
  if (!strategy) {
    strategy = {
      productId,
      platform,
      templateVariant,
      impressions: 0,
      clicks: 0,
      conversions: 0,
      lastUsed: new Date(),
      performanceScore: 0,
    };
    strategies.push(strategy);
  }
  
  strategy.impressions += metrics.impressions || 0;
  strategy.clicks += metrics.clicks || 0;
  strategy.conversions += metrics.conversions || 0;
  strategy.lastUsed = new Date();
  
  // Calculate performance score (weighted conversion rate)
  if (strategy.clicks > 0) {
    strategy.performanceScore = (strategy.conversions / strategy.clicks) * 
      Math.log10(strategy.clicks + 1); // Weight by log of clicks
  }
}

// ============ AUTO CONTENT GENERATION ============
async function autoGenerateContent(): Promise<void> {
  try {
    // Get all products
    const products = await storage.getMarketplaceProducts();
    
    // Get existing blog posts to avoid duplicates
    const existingPosts = await storage.getBlogPosts();
    const productsWithPosts = new Set(existingPosts.map(p => p.productId));
    
    // Find products without blog posts
    const productsNeedingContent = products.filter(p => !productsWithPosts.has(p.id));
    
    if (productsNeedingContent.length === 0) {
      console.log("[CONTENT] All products have blog posts");
      return;
    }
    
    // Generate content for up to 3 products per cycle (to avoid overwhelming)
    const toGenerate = productsNeedingContent.slice(0, 3);
    let generated = 0;
    
    for (const product of toGenerate) {
      try {
        const blogPost = await generateBlogPost(product);
        await storage.createBlogPost(blogPost);
        generated++;
        console.log(`[CONTENT] Generated blog post for: ${product.name}`);
      } catch (error) {
        console.error(`[CONTENT] Failed to generate for ${product.name}:`, error);
      }
    }
    
    if (generated > 0) {
      await storage.createActivityLog({
        action: "content_generated",
        category: "automation",
        details: `Auto-generated ${generated} blog posts for SEO`,
        severity: "info",
      });
    }
    
    console.log(`[CONTENT] Generated ${generated} new blog posts`);
  } catch (error) {
    console.error("[CONTENT] Auto-generation failed:", error);
  }
}

interface ProductForBlog {
  id: string;
  name: string;
  description?: string | null;
  category?: string | null;
  hopLink?: string | null;
  commission?: string | null;
  gravity?: string | null;
}

async function generateBlogPost(product: ProductForBlog): Promise<{
  productId: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  metaTitle: string;
  metaDescription: string;
  keywords: string[];
  category: string;
  affiliateLink: string;
  status: string;
  publishedAt: Date;
}> {
  const productName = product.name || "Amazing Product";
  const category = product.category || "Health & Wellness";
  const description = product.description || `Discover the benefits of ${productName}`;
  const affiliateLink = product.hopLink || "#";
  
  // Generate unique slug
  const baseSlug = productName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
  const uniqueSlug = `${baseSlug}-review-${Date.now().toString(36)}`;
  
  // Generate SEO-optimized title variations
  const titleTemplates = [
    `${productName} Review: Honest Results & Analysis [${new Date().getFullYear()}]`,
    `${productName}: Complete Guide & Real User Experiences`,
    `Is ${productName} Worth It? In-Depth Review & Verdict`,
    `${productName} Review - Everything You Need to Know`,
    `The Truth About ${productName}: Comprehensive Review`,
  ];
  const title = titleTemplates[Math.floor(Math.random() * titleTemplates.length)];
  
  // Generate keywords based on product
  const keywords = [
    productName.toLowerCase(),
    `${productName.toLowerCase()} review`,
    `${productName.toLowerCase()} reviews`,
    `buy ${productName.toLowerCase()}`,
    `${productName.toLowerCase()} benefits`,
    `${category.toLowerCase()}`,
    `${category.toLowerCase()} products`,
    `best ${category.toLowerCase()}`,
  ];
  
  // Generate the full blog content
  const content = generateSEOContent(productName, category, description, affiliateLink);
  
  // Generate excerpt
  const excerpt = `Discover our honest review of ${productName}. We analyze the features, benefits, and real user experiences to help you make an informed decision.`;
  
  // Meta tags
  const metaTitle = `${productName} Review ${new Date().getFullYear()} - Is It Worth It?`;
  const metaDescription = `Read our comprehensive ${productName} review. Discover the pros, cons, features, and real results. Find out if it's right for you.`;
  
  return {
    productId: product.id,
    title,
    slug: uniqueSlug,
    content,
    excerpt,
    metaTitle,
    metaDescription,
    keywords,
    category,
    affiliateLink,
    status: "published",
    publishedAt: new Date(),
  };
}

function generateSEOContent(productName: string, category: string, description: string, affiliateLink: string): string {
  const year = new Date().getFullYear();
  
  return `
## ${productName} Review: The Complete Guide for ${year}

Are you considering ${productName}? You're not alone. Thousands of people are searching for honest reviews before making their purchase decision. In this comprehensive review, we'll dive deep into everything you need to know.

### What is ${productName}?

${description}

${productName} has been gaining popularity in the ${category.toLowerCase()} space, and for good reason. Let's explore what makes this product stand out from the competition.

### Key Features and Benefits

When evaluating ${productName}, several features immediately stand out:

**Quality and Effectiveness**
The product delivers on its promises with noticeable results. Users have reported positive experiences, particularly when following the recommended guidelines.

**Ease of Use**
One of the standout aspects is how straightforward it is to incorporate into your routine. No complicated processes or steep learning curves.

**Value for Money**
Considering what you get, the pricing represents solid value. Many comparable products in the ${category.toLowerCase()} market cost significantly more.

### Who Should Consider ${productName}?

This product is ideal for:
- People looking for quality ${category.toLowerCase()} solutions
- Those who want a proven, reliable option
- Anyone seeking results without complexity
- Users who value their time and want something that works

### Potential Drawbacks

In the interest of fairness, here are some considerations:
- Results may vary based on individual circumstances
- Requires commitment to see optimal results
- May not be suitable for everyone - check if it fits your specific needs

### Real User Experiences

We've analyzed numerous user reviews and feedback. The consensus? Most users report satisfaction with their purchase. Common themes in positive reviews include:

- Noticeable improvements within the expected timeframe
- Good customer support when needed
- Product matches the description

### How to Get the Best Results

To maximize your experience with ${productName}:

1. **Follow the instructions** - The guidelines exist for a reason
2. **Be consistent** - Regular use yields better outcomes
3. **Give it time** - Allow adequate time to see results
4. **Track your progress** - Note any changes or improvements

### Pricing and Where to Buy

${productName} is available through the official website. Purchasing directly ensures you get the genuine product with any guarantees or support offered.

[**Click Here to Get ${productName} at the Best Price**](${affiliateLink})

### Final Verdict

After thorough analysis, ${productName} earns our recommendation. It delivers what it promises, offers good value, and has a track record of satisfied customers.

If you're in the market for a quality ${category.toLowerCase()} solution, this is definitely worth considering.

**Rating: 4.5/5 Stars**

[**Get ${productName} Now - Official Website**](${affiliateLink})

---

*Disclaimer: This review contains affiliate links. We may earn a commission if you purchase through our links, at no extra cost to you. We only recommend products we believe provide value.*
`.trim();
}

async function rotateProducts(): Promise<void> {
  try {
    const products = await storage.getMarketplaceProducts();
    const promotingProducts = products.filter(p => p.isPromoting);
    
    if (promotingProducts.length === 0) return;
    
    // Sort by last promoted time and performance
    const sortedProducts = promotingProducts.sort((a, b) => {
      const aLastPromo = a.lastUpdated ? new Date(a.lastUpdated).getTime() : 0;
      const bLastPromo = b.lastUpdated ? new Date(b.lastUpdated).getTime() : 0;
      return aLastPromo - bLastPromo; // Oldest first
    });
    
    // Update rotation queue
    productRotationQueue.length = 0;
    sortedProducts.forEach(p => productRotationQueue.push(p.id.toString()));
    
    console.log(`[SELF-UPDATE] Product rotation updated: ${productRotationQueue.length} products in queue`);
  } catch (error) {
    console.error("[SELF-UPDATE] Product rotation failed:", error);
  }
}

function getNextProductToPromote(): string | null {
  if (productRotationQueue.length === 0) return null;
  
  // Round-robin with performance weighting
  const productId = productRotationQueue.shift()!;
  productRotationQueue.push(productId); // Move to back of queue
  
  return productId;
}

async function autoOptimizeStrategies(): Promise<void> {
  if (!optimizationConfig.autoOptimizeEnabled) return;
  
  const now = new Date();
  const timeSinceLastOptimization = now.getTime() - lastOptimizationRun.getTime();
  
  if (timeSinceLastOptimization < optimizationConfig.refreshIntervalMinutes * 60000) {
    return; // Not time yet
  }
  
  console.log("[SELF-UPDATE] Running auto-optimization...");
  lastOptimizationRun = now;
  
  try {
    // Analyze content strategies
    let optimizedCount = 0;
    const entries = Array.from(contentStrategies.entries());
    for (const [key, strategies] of entries) {
      if (strategies.length >= optimizationConfig.minDataPointsForOptimization) {
        const avgScore = strategies.reduce((sum: number, s: ContentStrategy) => sum + s.performanceScore, 0) / strategies.length;
        
        // Remove underperforming variants
        const threshold = avgScore * 0.5; // Below 50% of average
        const removed = strategies.filter((s: ContentStrategy) => s.performanceScore < threshold && strategies.length > 1);
        
        if (removed.length > 0) {
          contentStrategies.set(key, strategies.filter((s: ContentStrategy) => s.performanceScore >= threshold || strategies.length <= 1));
          optimizedCount++;
        }
      }
    }
    
    await storage.createActivityLog({
      action: "auto_optimization",
      category: "automation",
      details: `Optimized ${optimizedCount} content strategies based on performance data`,
      severity: "info",
    });
    
    console.log(`[SELF-UPDATE] Optimization complete: ${optimizedCount} strategies updated`);
  } catch (error) {
    console.error("[SELF-UPDATE] Auto-optimization failed:", error);
  }
}

async function refreshContentLibrary(): Promise<void> {
  const now = new Date();
  const timeSinceLastRefresh = now.getTime() - lastContentRefresh.getTime();
  
  if (timeSinceLastRefresh < optimizationConfig.refreshIntervalMinutes * 60000) {
    return;
  }
  
  console.log("[SELF-UPDATE] Refreshing content library...");
  lastContentRefresh = now;
  
  try {
    // Rotate products
    await rotateProducts();
    
    // Check for new products to discover
    const networks = await storage.getAffiliateNetworks();
    const activeNetworks = networks.filter(n => n.status === "active");
    
    for (const network of activeNetworks) {
      const existingProducts = await storage.getMarketplaceProducts();
      const networkProducts = existingProducts.filter(p => p.networkId === network.id.toString());
      
      // If we have fewer than 20 products, discover more
      if (networkProducts.length < 20) {
        await discoverAndPromoteProducts(network.id.toString(), 5);
      }
    }
    
    // Auto-generate blog posts for products without content
    console.log("[SELF-UPDATE] Generating blog content...");
    await autoGenerateContent();
    
    await storage.createActivityLog({
      action: "content_refresh",
      category: "automation",
      details: "Content library refreshed with new products, rotations, and blog posts",
      severity: "info",
    });
  } catch (error) {
    console.error("[SELF-UPDATE] Content refresh failed:", error);
  }
}

// ============ HEALTH CHECK FUNCTIONS ============
async function checkDatabaseHealth(): Promise<boolean> {
  try {
    // Simple database query to verify connection
    await storage.getAffiliateNetworks();
    recordSuccess("database");
    return true;
  } catch (error) {
    recordFailure("database", String(error));
    return false;
  }
}

async function checkAyrshareHealth(): Promise<boolean> {
  if (!canCallService("ayrshare")) {
    console.log("[SELF-HEALING] Ayrshare circuit breaker is open, skipping health check");
    return false;
  }
  
  try {
    const client = getAyrshareClient();
    if (!client) {
      recordFailure("ayrshare", "No API key configured");
      return false;
    }
    
    // Quick health check using user endpoint
    const result = await client.getUser();
    if (result && !result.error) {
      recordSuccess("ayrshare");
      resolveHealthIssue("ayrshare", true);
      return true;
    } else {
      recordFailure("ayrshare", result?.error || "Unknown error");
      return false;
    }
  } catch (error) {
    recordFailure("ayrshare", String(error));
    return false;
  }
}

async function checkClickBankHealth(): Promise<boolean> {
  if (!canCallService("clickbank")) {
    console.log("[SELF-HEALING] ClickBank circuit breaker is open, skipping health check");
    return false;
  }
  
  try {
    const networks = await storage.getAffiliateNetworks();
    const clickbank = networks.find(n => n.name.toLowerCase().includes("clickbank"));
    
    if (!clickbank) {
      // No ClickBank configured, not an error
      systemHealth.components.clickbank.status = "healthy";
      return true;
    }
    
    // We'll consider it healthy if we can read the network
    recordSuccess("clickbank");
    return true;
  } catch (error) {
    recordFailure("clickbank", String(error));
    return false;
  }
}

async function runHealthChecks(): Promise<SystemHealth> {
  console.log("[SELF-HEALING] Running health checks...");
  
  await Promise.all([
    checkDatabaseHealth(),
    checkAyrshareHealth(),
    checkClickBankHealth(),
  ]);
  
  // Check automation engine
  if (isRunning) {
    systemHealth.components.automation.status = "healthy";
    systemHealth.components.automation.lastSuccessful = new Date();
  } else {
    systemHealth.components.automation.status = "down";
    addHealthIssue({
      component: "automation",
      severity: "warning",
      message: "Automation engine is not running",
      detectedAt: new Date(),
      autoResolved: false,
    });
  }
  
  updateOverallHealth();
  return systemHealth;
}

async function attemptAutoRecovery(): Promise<boolean> {
  if (systemHealth.status === "healthy") return true;
  
  console.log("[SELF-HEALING] Attempting auto-recovery...");
  systemHealth.autoRecoveryAttempts++;
  systemHealth.lastRecoveryAt = new Date();
  
  let recovered = false;
  
  // Try to recover each failing component
  for (const [name, component] of Object.entries(systemHealth.components)) {
    if (component.status === "down" || component.status === "degraded") {
      console.log(`[SELF-HEALING] Attempting recovery for ${name}...`);
      
      switch (name) {
        case "automation":
          if (!isRunning) {
            console.log("[SELF-HEALING] Restarting automation engine...");
            startAutomationEngine();
            await new Promise(resolve => setTimeout(resolve, 2000));
            if (isRunning) {
              resolveHealthIssue("automation", true);
              recovered = true;
            }
          }
          break;
          
        case "ayrshare":
          // Reset circuit breaker and retry
          const ayrCb = getCircuitBreaker("ayrshare");
          if (ayrCb.isOpen && ayrCb.nextRetry && new Date() >= ayrCb.nextRetry) {
            ayrCb.isOpen = false;
            ayrCb.failures = Math.floor(ayrCb.failures / 2); // Reduce failure count
            const success = await checkAyrshareHealth();
            if (success) {
              resolveHealthIssue("ayrshare", true);
              recovered = true;
            }
          }
          break;
          
        case "clickbank":
          const cbCb = getCircuitBreaker("clickbank");
          if (cbCb.isOpen && cbCb.nextRetry && new Date() >= cbCb.nextRetry) {
            cbCb.isOpen = false;
            cbCb.failures = Math.floor(cbCb.failures / 2);
            const success = await checkClickBankHealth();
            if (success) {
              resolveHealthIssue("clickbank", true);
              recovered = true;
            }
          }
          break;
      }
    }
  }
  
  if (recovered) {
    await storage.createNotification({
      type: "success",
      title: "System Auto-Recovered",
      message: "The system detected issues and automatically recovered. All systems operational.",
    });
    
    await storage.createActivityLog({
      action: "auto_recovery",
      category: "system",
      details: `Auto-recovery successful after ${systemHealth.autoRecoveryAttempts} attempts`,
      severity: "info",
    });
  }
  
  return recovered;
}

// ============ INTERVAL MANAGEMENT ============
let automationInterval: ReturnType<typeof setInterval> | null = null;
let queueProcessorInterval: ReturnType<typeof setInterval> | null = null;
let hourlyResetInterval: ReturnType<typeof setInterval> | null = null;
let dailyResetInterval: ReturnType<typeof setInterval> | null = null;
let healthCheckInterval: ReturnType<typeof setInterval> | null = null;
let selfUpdateInterval: ReturnType<typeof setInterval> | null = null;
let isRunning = false;
let consecutiveFailures = 0;
const MAX_CONSECUTIVE_FAILURES = 5;

export function startAutomationEngine() {
  if (isRunning) {
    console.log("[AUTOMATION] Engine already running");
    return;
  }

  isRunning = true;
  consecutiveFailures = 0;
  console.log("[AUTOMATION] Starting automation engine with self-healing and self-update");

  // Main automation cycle
  automationInterval = setInterval(async () => {
    await runAutomationCycle();
  }, 60000);

  // Queue processor
  queueProcessorInterval = setInterval(async () => {
    await processPostQueue();
  }, 30000);

  // Hourly reset
  hourlyResetInterval = setInterval(async () => {
    await storage.resetHourlyLimits();
    console.log("[AUTOMATION] Hourly rate limits reset");
  }, 3600000);

  // Daily reset and reports
  dailyResetInterval = setInterval(async () => {
    await storage.resetDailyLimits();
    await generateDailyReport();
    console.log("[AUTOMATION] Daily rate limits reset");
  }, 86400000);

  // Health checks every 5 minutes
  healthCheckInterval = setInterval(async () => {
    await runHealthChecks();
    if (systemHealth.status !== "healthy") {
      await attemptAutoRecovery();
    }
  }, 300000);

  // Self-update cycle every 30 minutes
  selfUpdateInterval = setInterval(async () => {
    await refreshContentLibrary();
    await autoOptimizeStrategies();
  }, 1800000);

  // Initial runs
  runAutomationCycle();
  processPostQueue();
  runHealthChecks();
  rotateProducts();
  
  // Run self-update routines on startup (delayed to allow other systems to initialize)
  setTimeout(async () => {
    await refreshContentLibrary();
    await autoOptimizeStrategies();
    console.log("[AUTOMATION] Initial self-update cycle completed");
  }, 10000);
  
  console.log("[AUTOMATION] All systems initialized - Self-healing and self-update active");
}

export function stopAutomationEngine() {
  const intervals = [
    automationInterval,
    queueProcessorInterval,
    hourlyResetInterval,
    dailyResetInterval,
    healthCheckInterval,
    selfUpdateInterval,
  ];
  
  intervals.forEach(interval => {
    if (interval) clearInterval(interval as NodeJS.Timeout);
  });
  
  automationInterval = null;
  queueProcessorInterval = null;
  hourlyResetInterval = null;
  dailyResetInterval = null;
  healthCheckInterval = null;
  selfUpdateInterval = null;
  isRunning = false;
  
  console.log("[AUTOMATION] Engine stopped");
}

async function processPostQueue() {
  if (!canCallService("ayrshare") && !canCallService("database")) {
    console.log("[AUTOMATION] Services unavailable, skipping queue processing");
    return;
  }
  
  try {
    const pendingPosts = await storage.getPendingPosts(5);
    
    for (const post of pendingPosts) {
      if (!post.socialAccountId) continue;
      
      const rateLimit = await storage.getRateLimit(post.socialAccountId);
      
      if (rateLimit?.isPaused) {
        if (rateLimit.pauseUntil && new Date(rateLimit.pauseUntil) > new Date()) {
          console.log(`[QUEUE] Account ${post.socialAccountId} is paused until ${rateLimit.pauseUntil}`);
          continue;
        }
      }
      
      if (rateLimit && rateLimit.postsToday !== null && rateLimit.dailyLimit !== null) {
        if (rateLimit.postsToday >= rateLimit.dailyLimit) {
          console.log(`[QUEUE] Daily limit reached for account ${post.socialAccountId}`);
          continue;
        }
      }
      
      if (rateLimit && rateLimit.postsThisHour !== null && rateLimit.hourlyLimit !== null) {
        if (rateLimit.postsThisHour >= rateLimit.hourlyLimit) {
          console.log(`[QUEUE] Hourly limit reached for account ${post.socialAccountId}`);
          continue;
        }
      }
      
      await storage.updatePostQueue(post.id, { status: "processing" });
      
      const socialAccount = await storage.getSocialAccountDecrypted(post.socialAccountId);
      if (!socialAccount) {
        await storage.updatePostQueue(post.id, { 
          status: "failed", 
          lastError: "Social account not found",
          attempts: (post.attempts || 0) + 1,
        });
        continue;
      }
      
      const result = await postToSocialMedia(socialAccount, {
        postContent: post.content,
        hashtags: post.hashtags,
      });
      
      if (result.success) {
        await storage.updatePostQueue(post.id, {
          status: "completed",
          postUrl: result.postUrl,
          processedAt: new Date(),
        });
        await storage.incrementPostCount(post.socialAccountId);
        consecutiveFailures = 0;
        recordSuccess("automation");
        
        await storage.createActivityLog({
          action: "post_published",
          category: "automation",
          details: `Posted to ${socialAccount.platform}: ${result.postUrl || 'success'}`,
          severity: "info",
        });
      } else {
        const attempts = (post.attempts || 0) + 1;
        const maxAttempts = post.maxAttempts || defaultConfig.retryAttempts;
        
        if (attempts >= maxAttempts) {
          await storage.updatePostQueue(post.id, {
            status: "failed",
            lastError: result.error,
            attempts,
          });
          consecutiveFailures++;
          
          await storage.createNotification({
            type: "failure",
            title: "Post Failed",
            message: `Failed to post after ${attempts} attempts: ${result.error}`,
          });
          
          if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
            await pauseAccountDueToFailures(post.socialAccountId);
          }
        } else {
          const retryTime = new Date();
          retryTime.setMinutes(retryTime.getMinutes() + defaultConfig.retryDelayMinutes);
          
          await storage.updatePostQueue(post.id, {
            status: "pending",
            lastError: result.error,
            attempts,
            scheduledFor: retryTime,
          });
        }
      }
    }
  } catch (error) {
    console.error("[QUEUE] Processing error:", error);
    recordFailure("automation", String(error));
  }
}

async function pauseAccountDueToFailures(accountId: string) {
  const pauseUntil = new Date();
  pauseUntil.setHours(pauseUntil.getHours() + 1);
  
  await storage.upsertRateLimit({
    platform: "unknown",
    accountId,
    isPaused: true,
    pauseReason: `Paused due to ${MAX_CONSECUTIVE_FAILURES} consecutive failures`,
    pauseUntil,
  });
  
  await storage.createNotification({
    type: "warning",
    title: "Account Paused",
    message: `Account temporarily paused due to repeated failures. Will resume at ${pauseUntil.toLocaleTimeString()}`,
  });
  
  await storage.createActivityLog({
    action: "account_auto_paused",
    category: "automation",
    details: `Account ${accountId} paused due to ${MAX_CONSECUTIVE_FAILURES} consecutive failures`,
    severity: "warning",
  });
  
  consecutiveFailures = 0;
}

async function generateDailyReport() {
  try {
    const salesToday = await storage.getSalesToday();
    const campaigns = await storage.getCampaigns();
    const completedToday = campaigns.filter(c => 
      c.status === "completed" && 
      c.createdAt && 
      new Date(c.createdAt).toDateString() === new Date().toDateString()
    );
    
    await storage.createNotification({
      type: "report",
      title: "Daily Performance Report",
      message: `Today: ${salesToday.count} sales, $${salesToday.total} earned, ${completedToday.length} campaigns completed`,
    });
    
    await storage.createAnalyticsSnapshot({
      date: new Date(),
      totalEarnings: salesToday.total,
      totalConversions: salesToday.count,
      totalClicks: 0,
      totalImpressions: 0,
    });
    
    // Reset optimization metrics for new day
    lastOptimizationRun = new Date(0);
  } catch (error) {
    console.error("[AUTOMATION] Failed to generate daily report:", error);
  }
}

async function runAutomationCycle() {
  try {
    const scheduledCampaigns = await storage.getScheduledCampaigns();
    const now = new Date();

    for (const campaign of scheduledCampaigns) {
      if (campaign.scheduledTime && new Date(campaign.scheduledTime) <= now) {
        await executeCampaign(campaign);
      }
    }
    
    recordSuccess("automation");
  } catch (error) {
    console.error("[AUTOMATION] Cycle error:", error);
    recordFailure("automation", String(error));
  }
}

async function executeCampaign(campaign: any) {
  try {
    console.log(`[AUTOMATION] Executing campaign: ${campaign.name}`);

    await storage.updateCampaign(campaign.id, {
      status: "active",
    });

    await storage.createActivityLog({
      action: "campaign_executed",
      category: "automation",
      details: `Campaign "${campaign.name}" ready for posting`,
      severity: "info",
    });

    if (campaign.socialAccountId) {
      const socialAccount = await storage.getSocialAccountDecrypted(campaign.socialAccountId);
      
      if (socialAccount && socialAccount.accessToken) {
        const postResult = await postToSocialMedia(socialAccount, campaign);
        
        if (postResult.success) {
          await storage.createActivityLog({
            action: "social_post_created",
            category: "automation",
            details: `Posted to ${socialAccount.platform}: ${postResult.postUrl || 'success'}`,
            severity: "info",
          });
        }
      } else {
        console.log(`[AUTOMATION] No valid social account for campaign ${campaign.id}, marking as pending`);
        await storage.createActivityLog({
          action: "campaign_pending_social",
          category: "automation",
          details: `Campaign "${campaign.name}" waiting for social account setup`,
          severity: "warning",
        });
      }
    }

    setTimeout(async () => {
      await storage.updateCampaign(campaign.id, {
        status: "completed",
      });
    }, 3600000);

    return true;
  } catch (error) {
    console.error(`[AUTOMATION] Failed to execute campaign ${campaign.id}:`, error);
    await storage.updateCampaign(campaign.id, {
      status: "failed",
    });
    return false;
  }
}

interface PostResult {
  success: boolean;
  postUrl?: string;
  error?: string;
}

async function postToSocialMedia(account: any, campaign: any): Promise<PostResult> {
  const platform = account.platform.toLowerCase();
  const content = campaign.postContent || '';
  const hashtags = campaign.hashtags || [];
  
  const fullContent = `${content}\n\n${hashtags.map((h: string) => `#${h}`).join(' ')}`;
  
  console.log(`[AUTOMATION] Posting to ${platform}:`, fullContent.substring(0, 100) + '...');
  
  // Check circuit breaker
  if (!canCallService("ayrshare")) {
    return { success: false, error: "Ayrshare service temporarily unavailable (circuit breaker open)" };
  }
  
  // Try Ayrshare unified API first
  const ayrshare = getAyrshareClient();
  if (ayrshare) {
    try {
      const result = await postToAyrshare(fullContent, [platform], {
        autoHashtag: true,
        maxHashtags: 3,
      });
      
      if (result && (result.status === 'success' || result.status === 'scheduled')) {
        console.log(`[AUTOMATION] Posted via Ayrshare to ${platform}`);
        recordSuccess("ayrshare");
        return { 
          success: true, 
          postUrl: result.postIds?.[platform] || result.id 
        };
      } else if (result && result.errors) {
        recordFailure("ayrshare", JSON.stringify(result.errors));
        return { success: false, error: `Ayrshare error: ${JSON.stringify(result.errors)}` };
      }
    } catch (ayrError: any) {
      console.log(`[AUTOMATION] Ayrshare posting failed, trying direct API:`, ayrError.message);
      recordFailure("ayrshare", ayrError.message);
    }
  }
  
  // Fallback to direct API calls
  try {
    switch (platform) {
      case 'twitter':
        return await postToTwitter(account.accessToken, fullContent);
      case 'facebook':
        return await postToFacebook(account.accessToken, fullContent);
      case 'instagram':
        return await postToInstagram(account.accessToken, fullContent);
      case 'tiktok':
        return await postToTikTok(account.accessToken, fullContent);
      default:
        return { success: false, error: `Unsupported platform: ${platform}` };
    }
  } catch (error) {
    console.error(`[AUTOMATION] Social post failed:`, error);
    return { success: false, error: String(error) };
  }
}

async function postToTwitter(accessToken: string, content: string): Promise<PostResult> {
  try {
    const response = await fetch('https://api.twitter.com/2/tweets', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text: content }),
    });

    if (response.ok) {
      const data = await response.json();
      return { success: true, postUrl: `https://twitter.com/i/status/${data.data?.id}` };
    } else {
      const error = await response.text();
      return { success: false, error: `Twitter API error: ${error}` };
    }
  } catch (error) {
    return { success: false, error: `Twitter connection failed: ${error}` };
  }
}

async function postToFacebook(accessToken: string, content: string): Promise<PostResult> {
  try {
    const response = await fetch(`https://graph.facebook.com/v18.0/me/feed`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 
        message: content,
        access_token: accessToken,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      return { success: true, postUrl: `https://facebook.com/${data.id}` };
    } else {
      const error = await response.text();
      return { success: false, error: `Facebook API error: ${error}` };
    }
  } catch (error) {
    return { success: false, error: `Facebook connection failed: ${error}` };
  }
}

async function postToInstagram(accessToken: string, content: string): Promise<PostResult> {
  console.log('[AUTOMATION] Instagram posting requires a valid media URL and business account');
  return { 
    success: false, 
    error: 'Instagram posting requires a valid media URL and business account setup' 
  };
}

async function postToTikTok(accessToken: string, content: string): Promise<PostResult> {
  console.log('[AUTOMATION] TikTok posting requires video content and creator tools API access');
  return { 
    success: false, 
    error: 'TikTok posting requires video content and creator tools API access' 
  };
}

export function generateOptimizedContent(
  product: any,
  platform: string
): { content: string; hashtags: string[] } {
  // Use self-update system to get optimal template
  const templateVariant = getOptimalTemplate(product.id?.toString() || product.externalId, platform);
  const templates = contentTemplates[platform] || contentTemplates.twitter;
  const template = templates[templateVariant] || templates[0];
  
  const content = template(product);
  
  const defaultHashtags: Record<string, string[]> = {
    twitter: ['affiliate', product.category?.replace(/\s+/g, '') || 'recommended', 'ad'],
    instagram: ['affiliate', 'sponsored', product.category?.replace(/\s+/g, '') || 'health', 'ad'],
    facebook: ['affiliate', product.category?.replace(/\s+/g, '') || 'health'],
    tiktok: ['fyp', 'viral', 'ad', product.category?.replace(/\s+/g, '')?.toLowerCase() || 'health'],
    linkedin: ['business', 'recommendation', product.category?.replace(/\s+/g, '') || 'productivity'],
  };
  
  return {
    content,
    hashtags: defaultHashtags[platform] || defaultHashtags.twitter,
  };
}

export async function getAutomationStatus() {
  const networks = await storage.getAffiliateNetworks();
  const socialAccounts = await storage.getSocialAccounts();
  const campaigns = await storage.getCampaigns();
  const marketplaceProducts = await storage.getMarketplaceProducts();

  const activeNetworks = networks.filter(n => n.status === "active");
  const connectedSocials = socialAccounts.filter(a => a.isActive);
  const activeCampaigns = campaigns.filter(c => c.status === "active" || c.status === "scheduled");
  const promotingProducts = marketplaceProducts.filter(p => p.isPromoting);

  return {
    isEngineRunning: isRunning,
    isFullyAutomated: activeNetworks.length > 0 && connectedSocials.length > 0,
    networks: {
      total: networks.length,
      active: activeNetworks.length,
    },
    socialAccounts: {
      total: socialAccounts.length,
      connected: connectedSocials.length,
    },
    campaigns: {
      total: campaigns.length,
      active: activeCampaigns.length,
      scheduled: campaigns.filter(c => c.status === "scheduled").length,
      completed: campaigns.filter(c => c.status === "completed").length,
    },
    products: {
      discovered: marketplaceProducts.length,
      promoting: promotingProducts.length,
      inRotation: productRotationQueue.length,
    },
    config: defaultConfig,
    optimization: optimizationConfig,
    health: systemHealth,
    selfHealing: {
      autoRecoveryAttempts: systemHealth.autoRecoveryAttempts,
      lastRecoveryAt: systemHealth.lastRecoveryAt,
      activeIssues: systemHealth.issues.filter(i => !i.resolvedAt).length,
      resolvedIssues: systemHealth.issues.filter(i => i.resolvedAt && i.autoResolved).length,
    },
    selfUpdate: {
      lastContentRefresh,
      lastOptimizationRun,
      contentStrategiesCount: contentStrategies.size,
    },
  };
}

export async function getSystemHealth(): Promise<SystemHealth> {
  return runHealthChecks();
}

export async function triggerManualRecovery(): Promise<{ success: boolean; message: string }> {
  console.log("[SELF-HEALING] Manual recovery triggered");
  
  const recovered = await attemptAutoRecovery();
  
  if (recovered) {
    return { success: true, message: "System recovery successful" };
  } else {
    return { success: false, message: "Recovery attempted but some issues persist" };
  }
}

export async function discoverAndPromoteProducts(networkId: string, limit: number = 5) {
  if (!canCallService("clickbank")) {
    return { success: false, count: 0, error: "ClickBank service temporarily unavailable" };
  }
  
  try {
    const { ClickBankAPI } = await import("./clickbank");
    const network = await storage.getAffiliateNetworkDecrypted(networkId);
    
    if (!network || !network.apiKey || !network.accountId) {
      throw new Error("Network not configured properly");
    }

    const clickbank = new ClickBankAPI({
      apiKey: network.apiKey,
      accountId: network.accountId,
    });

    const products = await clickbank.getTopProducts(undefined, limit);
    
    const savedProducts = [];
    for (const product of products) {
      const saved = await storage.createMarketplaceProduct({
        networkId,
        externalId: product.vendorId,
        name: product.name,
        description: product.description,
        vendorId: product.vendorId,
        category: product.category,
        gravity: product.gravity.toString(),
        commission: product.commission.toString(),
        initialPrice: product.initialPrice.toString(),
        avgEarningsPerSale: product.avgEarningsPerSale.toString(),
        hopLink: product.hopLink,
        imageUrl: product.imageUrl,
        isPromoting: true,
      });
      savedProducts.push(saved);
    }

    recordSuccess("clickbank");
    
    await storage.createActivityLog({
      action: "products_auto_discovered",
      category: "automation",
      details: `Auto-discovered ${savedProducts.length} products for promotion`,
      severity: "info",
    });

    // Update rotation queue
    await rotateProducts();

    return { success: true, count: savedProducts.length };
  } catch (error) {
    console.error("[AUTOMATION] Product discovery failed:", error);
    recordFailure("clickbank", String(error));
    return { success: false, count: 0, error: String(error) };
  }
}

// Export health and optimization functions
export {
  runHealthChecks,
  attemptAutoRecovery,
  refreshContentLibrary,
  autoOptimizeStrategies,
  recordContentPerformance,
};
