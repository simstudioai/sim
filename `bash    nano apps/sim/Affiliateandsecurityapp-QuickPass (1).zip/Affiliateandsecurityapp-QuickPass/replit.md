# Privately - Android Security Dashboard

## Overview

Privately is a full-stack web application designed as an advanced privacy management and security dashboard for Android devices. The application features a cyberpunk-themed UI with capabilities for monitoring identities, tracking network connections, auditing app permissions, and managing secure file storage. Additionally, it includes an affiliate marketing management system with AI-powered optimization for tracking earnings across multiple affiliate networks like ClickBank, ShareASale, and CJ Affiliate.

The application is built as a modern single-page application (SPA) with a REST API backend, featuring real-time security monitoring, encrypted vault storage, and comprehensive activity logging.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server, configured for hot module replacement (HMR)
- **Wouter** for lightweight client-side routing instead of React Router
- **TanStack Query v5** for server state management, data fetching, and caching with infinite stale time by default

**UI Component System**
- **shadcn/ui** component library using the "new-york" style variant
- **Radix UI** primitives for accessible, unstyled UI components
- **Tailwind CSS v4** with custom cyberpunk/dark theme using CSS variables
- **Framer Motion** for animations and transitions
- **Recharts** for data visualization and charts
- Custom theme featuring neon cyan primary color (hsl(180 100% 50%)), dark backgrounds, and glowing effects

**Design System**
- Custom fonts: Space Grotesk (display), Inter (sans-serif), JetBrains Mono (monospace)
- Glass-morphism UI patterns with backdrop blur effects
- Consistent cyberpunk aesthetic with hexagonal grid background texture
- Mobile-responsive design with custom breakpoints and mobile-specific navigation

**State Management Pattern**
- Server state managed through TanStack Query with custom query client configuration
- No global client state management library (no Redux/Zustand)
- Component-level state using React hooks
- Custom hooks for common patterns (useIsMobile, useToast)

### Backend Architecture

**Server Framework**
- **Express.js** with TypeScript for the REST API
- **Node.js** HTTP server wrapping Express
- Custom middleware for request logging with timestamps and duration tracking
- JSON body parsing with raw body preservation for webhook verification

**Development vs Production**
- Development mode uses Vite middleware for HMR and instant updates
- Production mode serves pre-built static assets from dist/public
- Environment-based configuration (NODE_ENV)
- Replit-specific plugins for development (cartographer, dev-banner, runtime error overlay)

**API Design**
- RESTful endpoints following resource-oriented patterns
- Routes organized by domain (networks, products, earnings, clicks, payouts)
- Consistent error handling with appropriate HTTP status codes
- CRUD operations for all major entities

**Build Process**
- Custom build script using esbuild for server bundling
- Allowlist approach for dependencies to bundle (reduces cold start syscalls)
- Vite build for client application
- Separate client and server build outputs

### Data Storage

**Database Technology**
- **PostgreSQL** via Neon serverless database
- **Drizzle ORM** for type-safe database queries and schema management
- WebSocket-based connection pooling using @neondatabase/serverless
- Schema-first approach with TypeScript types generated from Drizzle schema

**Schema Design**
The application uses a relational schema with the following core entities:

1. **Users**: Authentication and user management with username/password
2. **Affiliate Networks**: Connected marketing networks with API credentials
3. **Affiliate Products**: Individual products/offers from networks
4. **Affiliate Earnings**: Transaction records with commission tracking
5. **Affiliate Clicks**: Click tracking and conversion data
6. **Affiliate Payouts**: Payment history and payout records

**Data Validation**
- Zod schemas for runtime validation
- drizzle-zod for automatic schema generation from database tables
- Type-safe insert/select operations throughout the application

**Database Migrations**
- Drizzle Kit for schema migrations
- Migrations stored in /migrations directory
- Push-based workflow for development (db:push script)

### External Dependencies

**Affiliate Network Integrations**
- **ClickBank API**: REST API v1.3 integration with HTTP Basic Auth
- Planned support for ShareASale, CJ Affiliate, Impact, Rakuten, Awin
- Custom API wrapper classes for each network
- Automatic data synchronization and transaction polling
- Analytics aggregation across multiple networks

**UI Component Libraries**
- Extensive Radix UI component collection (30+ primitives)
- Lucide React for consistent iconography
- embla-carousel for touch-friendly carousels
- cmdk for command palette interfaces

**Development Tools**
- Replit-specific Vite plugins for enhanced development experience
- Custom meta images plugin for OpenGraph image injection
- TypeScript with strict mode and path aliases
- ESM module system throughout

**Asset Management**
- Static assets served from attached_assets directory
- Generated images for branding (logos, backgrounds, coins)
- Custom Vite alias configuration for asset imports
- Public directory for favicon and other static files

**Authentication & Security**
- Password hashing (infrastructure present, specific library not visible in provided files)
- Session-based authentication foundation with connect-pg-simple
- Environment variable management for sensitive credentials
- Secure API key storage for affiliate networks

**Build & Deployment**
- Replit deployment detection for URL generation
- Custom build script combining client and server builds
- Production optimization with dependency bundling
- Static file serving with SPA fallback routing