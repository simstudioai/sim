import { AlertTriangle, ShieldCheck, Lock, Wifi } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

const activities = [
  { id: 1, type: "block", title: "Suspicious Connection Blocked", desc: "Attempted connection to 192.168.1.x (Port 8080)", time: "2m ago", icon: AlertTriangle, color: "text-destructive" },
  { id: 2, type: "scan", title: "System Scan Completed", desc: "No new threats found in 124 apps", time: "15m ago", icon: ShieldCheck, color: "text-primary" },
  { id: 3, type: "audit", title: "Permission Auto-Revoked", desc: "Removed 'Camera' access from Calculator", time: "1h ago", icon: Lock, color: "text-orange-400" },
  { id: 4, type: "network", title: "VPN Connected", desc: "Secure tunnel established (Tokyo Server)", time: "2h ago", icon: Wifi, color: "text-primary" },
  { id: 5, type: "block", title: "Tracker Blocked", desc: "Blocked analytics.google.com request", time: "3h ago", icon: AlertTriangle, color: "text-destructive" },
];

export function ActivityFeed() {
  return (
    <ScrollArea className="h-[300px] w-full pr-4">
      <div className="space-y-4">
        {activities.map((item) => (
          <div key={item.id} className="flex gap-4 p-3 rounded-lg bg-white/5 border border-white/5 hover:bg-white/10 transition-colors group">
            <div className={`mt-1 p-2 rounded-full bg-black/40 ${item.color}`}>
              <item.icon size={16} />
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <h4 className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">{item.title}</h4>
                <span className="text-[10px] text-muted-foreground font-mono">{item.time}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </ScrollArea>
  );
}
