import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";
import { motion } from "framer-motion";

const data = [
  { name: "Secure", value: 85 },
  { name: "Vulnerable", value: 15 },
];

const COLORS = ["hsl(180, 100%, 50%)", "hsl(222, 47%, 20%)"];

export function SecurityScore() {
  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center">
      <div className="relative w-48 h-48">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={80}
              startAngle={180}
              endAngle={-180}
              paddingAngle={5}
              dataKey="value"
              stroke="none"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        
        {/* Center Text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <motion.div 
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="text-4xl font-display font-bold text-white text-glow"
          >
            85%
          </motion.div>
          <span className="text-xs text-muted-foreground font-mono uppercase tracking-widest mt-1">System Safe</span>
        </div>

        {/* Animated Ring */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none animate-[spin_10s_linear_infinite] opacity-30">
          <circle cx="50%" cy="50%" r="48%" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="4 4" className="text-primary" />
        </svg>
      </div>
    </div>
  );
}
