import { motion } from "framer-motion";

export function ThreatMap() {
  // Mock "connections"
  const connections = Array.from({ length: 12 }).map((_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    status: Math.random() > 0.8 ? "danger" : "safe",
  }));

  return (
    <div className="relative w-full h-64 bg-black/20 rounded-lg overflow-hidden border border-white/5">
      {/* Grid Background */}
      <div className="absolute inset-0 opacity-20" 
        style={{ 
          backgroundImage: 'linear-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.1) 1px, transparent 1px)',
          backgroundSize: '20px 20px'
        }} 
      />
      
      {/* World Map Silhouette (Simplified) */}
      <div className="absolute inset-0 opacity-10 bg-[url('https://upload.wikimedia.org/wikipedia/commons/8/80/World_map_-_low_resolution.svg')] bg-no-repeat bg-center bg-contain grayscale invert" />

      {/* Connections */}
      {connections.map((conn) => (
        <motion.div
          key={conn.id}
          className={`absolute w-2 h-2 rounded-full ${conn.status === 'danger' ? 'bg-destructive shadow-[0_0_8px_var(--color-destructive)]' : 'bg-primary shadow-[0_0_8px_var(--color-primary)]'}`}
          style={{ left: `${conn.x}%`, top: `${conn.y}%` }}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2 + Math.random(), repeat: Infinity }}
        />
      ))}

      {/* Radar Scan Line */}
      <div className="absolute inset-0 border-r border-primary/30 bg-gradient-to-l from-primary/10 to-transparent w-1/2 h-full animate-[spin_4s_linear_infinite_origin_right]" style={{ transformOrigin: '100% 50%' }} />
      
      <div className="absolute bottom-2 left-2 text-[10px] font-mono text-primary">
        LIVE NETWORK MONITORING
      </div>
    </div>
  );
}
