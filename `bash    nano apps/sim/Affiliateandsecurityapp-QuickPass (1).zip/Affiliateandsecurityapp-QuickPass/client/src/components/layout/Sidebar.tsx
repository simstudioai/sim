import { Link, useLocation } from "wouter";
import { Shield, Globe, Users, Eye, Lock, Activity, Menu, TrendingUp, Settings, Bot, BarChart3, FileText, Share2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import logo from "@assets/generated_images/cyberpunk_shield_logo_for_security_app.png";
import { useIsMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";

export function Sidebar() {
  const [location] = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const isMobile = useIsMobile();
  const [open, setOpen] = useState(false);

  const navItems = [
    { href: "/", label: "Dashboard", icon: Shield },
    { href: "/identities", label: "Identities", icon: Users },
    { href: "/network", label: "Network Monitor", icon: Globe },
    { href: "/auditor", label: "Privacy Auditor", icon: Eye },
    { href: "/vault", label: "Secure Vault", icon: Lock },
    { href: "/affiliate", label: "Affiliate AI", icon: TrendingUp },
    { href: "/automation", label: "Autopilot", icon: Bot },
    { href: "/blog", label: "Blog Content", icon: FileText },
    { href: "/social", label: "Social Media", icon: Share2 },
    { href: "/analytics", label: "Analytics", icon: BarChart3 },
    { href: "/accounts", label: "Account Setup", icon: Settings },
    { href: "/activity", label: "Activity Log", icon: Activity },
  ];

  const NavContent = () => (
    <>
      <div className="p-4 flex items-center justify-between border-b border-sidebar-border">
        <div className={cn("flex items-center gap-3 overflow-hidden", collapsed && !isMobile && "justify-center w-full")}>
          <img src={logo} alt="Privately" className="w-8 h-8 object-contain" />
          {(!collapsed || isMobile) && <span className="font-display font-bold text-xl tracking-tight text-primary">Privately</span>}
        </div>
      </div>

      <nav className="flex-1 py-6 px-2 space-y-1">
        {navItems.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href} onClick={() => isMobile && setOpen(false)}>
              <div className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors cursor-pointer group relative overflow-hidden",
                isActive 
                  ? "bg-sidebar-primary/10 text-sidebar-primary" 
                  : "text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
              )}>
                {isActive && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary shadow-[0_0_10px_var(--color-primary)]" />
                )}
                <Icon className={cn("w-5 h-5", isActive && "text-primary drop-shadow-[0_0_5px_rgba(0,255,255,0.5)]")} />
                {(!collapsed || isMobile) && <span className="font-medium text-sm">{item.label}</span>}
              </div>
            </Link>
          );
        })}
      </nav>
    </>
  );

  if (isMobile) {
    return (
      <div className="fixed top-0 left-0 right-0 z-50 p-4 flex items-center justify-between bg-background/80 backdrop-blur-md border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <img src={logo} alt="Privately" className="w-6 h-6 object-contain" />
          <span className="font-display font-bold text-lg tracking-tight text-primary">Privately</span>
        </div>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[280px] p-0 bg-sidebar border-r border-sidebar-border">
             <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
            <NavContent />
          </SheetContent>
        </Sheet>
      </div>
    );
  }

  return (
    <aside className={cn(
      "h-screen bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 z-50",
      collapsed ? "w-16" : "w-64"
    )}>
      <NavContent />
      <div className="p-4 border-t border-sidebar-border">
        <button 
          onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center justify-center p-2 rounded-md hover:bg-sidebar-accent/50 text-sidebar-foreground/60 transition-colors"
        >
          {collapsed ? <Menu size={20} /> : <div className="flex items-center gap-2 text-sm"><Menu size={16} /> <span>Collapse Menu</span></div>}
        </button>
      </div>
    </aside>
  );
}
