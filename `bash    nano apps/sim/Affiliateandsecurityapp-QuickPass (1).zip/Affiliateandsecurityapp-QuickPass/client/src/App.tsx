import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Identities from "@/pages/Identities";
import Network from "@/pages/Network";
import Auditor from "@/pages/Auditor";
import Vault from "@/pages/Vault";
import Activity from "@/pages/Activity";
import Affiliate from "@/pages/Affiliate";
import AccountSetup from "@/pages/AccountSetup";
import Automation from "@/pages/Automation";
import Analytics from "@/pages/Analytics";
import Blog from "@/pages/Blog";
import Reviews from "@/pages/Reviews";
import SalesPage from "@/pages/SalesPage";
import ThankYou from "@/pages/ThankYou";
import Support from "@/pages/Support";
import TestConsole from "@/pages/TestConsole";
import SocialMedia from "@/pages/SocialMedia";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/identities" component={Identities} />
      <Route path="/network" component={Network} />
      <Route path="/auditor" component={Auditor} />
      <Route path="/vault" component={Vault} />
      <Route path="/activity" component={Activity} />
      <Route path="/affiliate" component={Affiliate} />
      <Route path="/accounts" component={AccountSetup} />
      <Route path="/automation" component={Automation} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/blog" component={Blog} />
      <Route path="/reviews" component={Reviews} />
      <Route path="/reviews/:slug" component={Reviews} />
      <Route path="/buy" component={SalesPage} />
      <Route path="/thank-you" component={ThankYou} />
      <Route path="/thank-you/:token" component={ThankYou} />
      <Route path="/download/:token" component={ThankYou} />
      <Route path="/support" component={Support} />
      <Route path="/social" component={SocialMedia} />
      <Route path="/test" component={TestConsole} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
