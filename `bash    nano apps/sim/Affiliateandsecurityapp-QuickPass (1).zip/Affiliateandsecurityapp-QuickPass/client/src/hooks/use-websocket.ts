import { useEffect, useRef, useState, useCallback } from "react";
import { useToast } from "./use-toast";

interface WebSocketMessage {
  type: string;
  data?: any;
  message?: string;
}

export function useWebSocket() {
  const { toast } = useToast();
  const wsRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const connect = useCallback(() => {
    if (typeof window === "undefined" || !window.WebSocket) return;
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      setIsConnected(true);
      console.log("[WS] Connected to server");
    };

    ws.onmessage = (event) => {
      try {
        const message: WebSocketMessage = JSON.parse(event.data);
        setLastMessage(message);

        if (message.type === "sync_complete" && message.data) {
          const { networkName, transactionsImported } = message.data;
          if (transactionsImported > 0) {
            toast({
              title: "New Earnings Synced!",
              description: `${transactionsImported} new transactions from ${networkName}`,
              className: "border-primary text-primary",
            });
          }
        }

        if (message.type === "security_alert" && message.data) {
          const { title, message: alertMessage, severity } = message.data;
          toast({
            title,
            description: alertMessage,
            variant: severity === "critical" ? "destructive" : "default",
          });
        }
      } catch (error) {
        console.error("[WS] Failed to parse message:", error);
      }
    };

    ws.onclose = () => {
      setIsConnected(false);
      console.log("[WS] Disconnected from server");
      
      reconnectTimeoutRef.current = setTimeout(() => {
        console.log("[WS] Attempting to reconnect...");
        connect();
      }, 5000);
    };

    ws.onerror = (error) => {
      console.error("[WS] Error:", error);
    };

    wsRef.current = ws;
  }, [toast]);

  useEffect(() => {
    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  return { isConnected, lastMessage };
}
