import { Sidebar } from "@/components/layout/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  TrendingUp, 
  DollarSign, 
  MousePointer, 
  ShoppingCart,
  Bell,
  BellOff,
  Clock,
  AlertTriangle,
  CheckCircle,
  Copy,
  Zap,
  BarChart3,
  Target,
  Sparkles
} from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import { useIsMobile } from "@/hooks/use-mobile";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export default function Analytics() {
  const isMobile = useIsMobile();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: analytics } = useQuery<{ sales?: { count: number; total: string }; snapshot?: any }>({
    queryKey: ["/api/analytics/today"],
  });

  const { data: snapshots = [] } = useQuery<any[]>({
    queryKey: ["/api/analytics/snapshots"],
  });

  const { data: sales = [] } = useQuery<any[]>({
    queryKey: ["/api/sales"],
  });

  const { data: notifications = [] } = useQuery<any[]>({
    queryKey: ["/api/notifications"],
  });

  const { data: unreadNotifications = [] } = useQuery<any[]>({
    queryKey: ["/api/notifications/unread"],
  });

  const { data: notificationSettings } = useQuery<{
    emailEnabled?: boolean;
    pushEnabled?: boolean;
    notifyOnSale?: boolean;
    notifyOnFailure?: boolean;
    notifyDailyReport?: boolean;
    notifyWeeklyReport?: boolean;
  }>({
    queryKey: ["/api/notification-settings"],
  });

  const { data: templates = [] } = useQuery<any[]>({
    queryKey: ["/api/templates"],
  });

  const { data: postQueue = [] } = useQuery<any[]>({
    queryKey: ["/api/post-queue"],
  });

  const { data: rateLimits = [] } = useQuery<any[]>({
    queryKey: ["/api/rate-limits"],
  });

  const markAllReadMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/notifications/read-all", { method: "POST" });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread"] });
      toast({ title: "All notifications marked as read" });
    },
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (settings: any) => {
      const res = await fetch("/api/notification-settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notification-settings"] });
      toast({ title: "Settings updated" });
    },
  });

  const chartData = (snapshots || []).slice(0, 7).reverse().map((s: any) => ({
    date: new Date(s.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    earnings: parseFloat(s.totalEarnings || 0),
    conversions: s.totalConversions || 0,
  }));

  const todaySales = analytics?.sales || { count: 0, total: "0" };
  const unreadCount = (unreadNotifications || []).length;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "sale": return <DollarSign className="w-4 h-4 text-green-500" />;
      case "failure": return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case "warning": return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case "report": return <BarChart3 className="w-4 h-4 text-blue-500" />;
      default: return <Bell className="w-4 h-4 text-primary" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      pending: "bg-yellow-500/20 text-yellow-500",
      processing: "bg-blue-500/20 text-blue-500",
      completed: "bg-green-500/20 text-green-500",
      failed: "bg-red-500/20 text-red-500",
    };
    return colors[status] || "bg-gray-500/20 text-gray-500";
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative ${isMobile ? 'pt-16' : ''}`}>
        <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6 md:space-y-8">
          
          <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-white flex items-center gap-2">
                <BarChart3 className="text-primary" />
                Analytics & Performance
              </h1>
              <p className="text-sm md:text-base text-muted-foreground">Track earnings, campaigns, and optimization insights</p>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                className="border-primary/50 text-primary hover:bg-primary/10 relative"
                data-testid="button-notifications"
              >
                <Bell size={16} />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary text-xs flex items-center justify-center rounded-full">
                    {unreadCount}
                  </span>
                )}
              </Button>
            </div>
          </header>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            <Card className="glass-panel border-white/5 bg-gradient-to-br from-green-500/10 to-transparent">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase font-mono">Today's Sales</p>
                    <h3 className="text-2xl font-display font-bold text-green-500">{todaySales.count}</h3>
                  </div>
                  <DollarSign className="w-8 h-8 text-green-500/50" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="glass-panel border-white/5 bg-gradient-to-br from-primary/10 to-transparent">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase font-mono">Today's Earnings</p>
                    <h3 className="text-2xl font-display font-bold text-primary">${todaySales.total}</h3>
                  </div>
                  <TrendingUp className="w-8 h-8 text-primary/50" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="glass-panel border-white/5 bg-gradient-to-br from-blue-500/10 to-transparent">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase font-mono">Queue</p>
                    <h3 className="text-2xl font-display font-bold text-blue-500">{(postQueue || []).length}</h3>
                  </div>
                  <Clock className="w-8 h-8 text-blue-500/50" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="glass-panel border-white/5 bg-gradient-to-br from-purple-500/10 to-transparent">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase font-mono">Templates</p>
                    <h3 className="text-2xl font-display font-bold text-purple-500">{(templates || []).length}</h3>
                  </div>
                  <Sparkles className="w-8 h-8 text-purple-500/50" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList className="bg-card/50 border border-white/10">
              <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
              <TabsTrigger value="notifications" data-testid="tab-notifications">
                Notifications {unreadCount > 0 && `(${unreadCount})`}
              </TabsTrigger>
              <TabsTrigger value="queue" data-testid="tab-queue">Post Queue</TabsTrigger>
              <TabsTrigger value="templates" data-testid="tab-templates">Templates</TabsTrigger>
              <TabsTrigger value="settings" data-testid="tab-settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <Card className="glass-panel border-white/5">
                  <CardHeader>
                    <CardTitle className="text-lg font-medium flex items-center gap-2">
                      <TrendingUp className="text-primary" size={20} />
                      Earnings Trend
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={chartData}>
                        <defs>
                          <linearGradient id="earningsGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="hsl(180, 100%, 50%)" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="hsl(180, 100%, 50%)" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                        <XAxis dataKey="date" stroke="#666" fontSize={12} />
                        <YAxis stroke="#666" fontSize={12} />
                        <Tooltip 
                          contentStyle={{ background: '#1a1a1a', border: '1px solid #333', borderRadius: '8px' }}
                          labelStyle={{ color: '#fff' }}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="earnings" 
                          stroke="hsl(180, 100%, 50%)" 
                          fill="url(#earningsGradient)"
                          strokeWidth={2}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="glass-panel border-white/5">
                  <CardHeader>
                    <CardTitle className="text-lg font-medium flex items-center gap-2">
                      <ShoppingCart className="text-green-500" size={20} />
                      Recent Sales
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 max-h-[280px] overflow-y-auto">
                      {(sales || []).slice(0, 10).map((sale: any) => (
                        <div key={sale.id} className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/5">
                          <div className="flex items-center gap-3">
                            <div className="p-2 rounded-full bg-green-500/20">
                              <DollarSign className="w-4 h-4 text-green-500" />
                            </div>
                            <div>
                              <p className="text-sm font-medium">${sale.commission}</p>
                              <p className="text-xs text-muted-foreground">
                                {sale.saleDate ? formatDistanceToNow(new Date(sale.saleDate), { addSuffix: true }) : 'Recently'}
                              </p>
                            </div>
                          </div>
                          <Badge className={sale.status === 'completed' ? 'bg-green-500/20 text-green-500' : 'bg-yellow-500/20 text-yellow-500'}>
                            {sale.status}
                          </Badge>
                        </div>
                      ))}
                      {(sales || []).length === 0 && (
                        <div className="text-center py-8 text-muted-foreground">
                          No sales yet. Start promoting products to earn commissions!
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="glass-panel border-white/5">
                <CardHeader>
                  <CardTitle className="text-lg font-medium flex items-center gap-2">
                    <Zap className="text-yellow-500" size={20} />
                    Rate Limits & Account Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {(rateLimits || []).map((limit: any) => (
                      <div key={limit.id} className="p-4 rounded-lg bg-white/5 border border-white/5">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium capitalize">{limit.platform}</span>
                          {limit.isPaused ? (
                            <Badge className="bg-red-500/20 text-red-500">Paused</Badge>
                          ) : (
                            <Badge className="bg-green-500/20 text-green-500">Active</Badge>
                          )}
                        </div>
                        <div className="space-y-1 text-sm text-muted-foreground">
                          <div className="flex justify-between">
                            <span>Today:</span>
                            <span>{limit.postsToday || 0} / {limit.dailyLimit || 10}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>This Hour:</span>
                            <span>{limit.postsThisHour || 0} / {limit.hourlyLimit || 2}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                    {(rateLimits || []).length === 0 && (
                      <div className="col-span-3 text-center py-4 text-muted-foreground">
                        No rate limits configured. Connect social accounts to see limits.
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notifications" className="space-y-4">
              <Card className="glass-panel border-white/5">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-lg font-medium flex items-center gap-2">
                    <Bell className="text-primary" size={20} />
                    Notifications
                  </CardTitle>
                  {unreadCount > 0 && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => markAllReadMutation.mutate()}
                      data-testid="button-mark-all-read"
                    >
                      Mark All Read
                    </Button>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-[500px] overflow-y-auto">
                    {(notifications || []).map((notif: any) => (
                      <div 
                        key={notif.id} 
                        className={`flex items-start gap-3 p-3 rounded-lg border ${
                          notif.isRead ? 'bg-white/5 border-white/5' : 'bg-primary/5 border-primary/20'
                        }`}
                      >
                        {getNotificationIcon(notif.type)}
                        <div className="flex-1">
                          <p className="text-sm font-medium">{notif.title}</p>
                          <p className="text-xs text-muted-foreground">{notif.message}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {notif.sentAt ? formatDistanceToNow(new Date(notif.sentAt), { addSuffix: true }) : ''}
                          </p>
                        </div>
                      </div>
                    ))}
                    {(notifications || []).length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        No notifications yet.
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="queue" className="space-y-4">
              <Card className="glass-panel border-white/5">
                <CardHeader>
                  <CardTitle className="text-lg font-medium flex items-center gap-2">
                    <Clock className="text-blue-500" size={20} />
                    Post Queue
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-[500px] overflow-y-auto">
                    {(postQueue || []).map((post: any) => (
                      <div key={post.id} className="flex items-start gap-3 p-4 rounded-lg bg-white/5 border border-white/5">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={getStatusBadge(post.status)}>
                              {post.status}
                            </Badge>
                            {post.attempts > 0 && (
                              <span className="text-xs text-muted-foreground">
                                Attempt {post.attempts}/{post.maxAttempts || 3}
                              </span>
                            )}
                          </div>
                          <p className="text-sm">{post.content?.substring(0, 100)}...</p>
                          <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                            <span>Scheduled: {post.scheduledFor ? new Date(post.scheduledFor).toLocaleString() : 'Now'}</span>
                            {post.lastError && (
                              <span className="text-red-400">Error: {post.lastError}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                    {(postQueue || []).length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        No posts in queue. Create campaigns to schedule posts.
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="templates" className="space-y-4">
              <Card className="glass-panel border-white/5">
                <CardHeader>
                  <CardTitle className="text-lg font-medium flex items-center gap-2">
                    <Sparkles className="text-purple-500" size={20} />
                    Post Templates
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {(templates || []).map((template: any) => (
                      <div key={template.id} className="p-4 rounded-lg bg-white/5 border border-white/5">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">{template.name}</span>
                          <Badge variant="outline">{template.platform}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{template.content?.substring(0, 100)}...</p>
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>Used: {template.usageCount || 0} times</span>
                          <span>Conv: {template.conversionRate || 0}%</span>
                        </div>
                      </div>
                    ))}
                    {(templates || []).length === 0 && (
                      <div className="col-span-2 text-center py-8 text-muted-foreground">
                        No templates yet. Create templates to reuse proven post formats.
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings" className="space-y-4">
              <Card className="glass-panel border-white/5">
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Notification Preferences</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                    <div>
                      <p className="font-medium">Sale Notifications</p>
                      <p className="text-sm text-muted-foreground">Get notified when you make a sale</p>
                    </div>
                    <Switch 
                      checked={notificationSettings?.notifyOnSale ?? true}
                      onCheckedChange={(checked) => updateSettingsMutation.mutate({ ...notificationSettings, notifyOnSale: checked })}
                      data-testid="switch-sale-notifications"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                    <div>
                      <p className="font-medium">Failure Alerts</p>
                      <p className="text-sm text-muted-foreground">Get notified when posts fail</p>
                    </div>
                    <Switch 
                      checked={notificationSettings?.notifyOnFailure ?? true}
                      onCheckedChange={(checked) => updateSettingsMutation.mutate({ ...notificationSettings, notifyOnFailure: checked })}
                      data-testid="switch-failure-notifications"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                    <div>
                      <p className="font-medium">Daily Reports</p>
                      <p className="text-sm text-muted-foreground">Receive daily performance summaries</p>
                    </div>
                    <Switch 
                      checked={notificationSettings?.notifyDailyReport ?? true}
                      onCheckedChange={(checked) => updateSettingsMutation.mutate({ ...notificationSettings, notifyDailyReport: checked })}
                      data-testid="switch-daily-reports"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                    <div>
                      <p className="font-medium">Weekly Reports</p>
                      <p className="text-sm text-muted-foreground">Receive weekly performance summaries</p>
                    </div>
                    <Switch 
                      checked={notificationSettings?.notifyWeeklyReport ?? true}
                      onCheckedChange={(checked) => updateSettingsMutation.mutate({ ...notificationSettings, notifyWeeklyReport: checked })}
                      data-testid="switch-weekly-reports"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

        </div>
      </main>
    </div>
  );
}
