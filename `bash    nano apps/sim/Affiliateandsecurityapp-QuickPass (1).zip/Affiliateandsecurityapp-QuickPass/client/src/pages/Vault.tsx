import { Sidebar } from "@/components/layout/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Lock, FileText, Image, Key, Plus, ShieldCheck, Trash2, Eye, EyeOff, CreditCard, User, RefreshCw } from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import { useIsMobile } from "@/hooks/use-mobile";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const getIcon = (type: string) => {
  switch (type) {
    case "password": return Key;
    case "card": return CreditCard;
    case "identity": return User;
    case "image": return Image;
    default: return FileText;
  }
};

export default function Vault() {
  const isMobile = useIsMobile();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLocked, setIsLocked] = useState(true);
  const [showContent, setShowContent] = useState<Record<string, boolean>>({});
  
  const [newItem, setNewItem] = useState({
    name: "",
    type: "text",
    encryptedContent: "",
    category: "",
  });

  // Fetch vault items
  const { data: items = [], isLoading } = useQuery({
    queryKey: ["/api/vault"],
    queryFn: async () => {
      const res = await fetch("/api/vault");
      if (!res.ok) throw new Error("Failed to fetch vault items");
      return res.json();
    },
  });

  // Create item mutation
  const createItem = useMutation({
    mutationFn: async (data: typeof newItem) => {
      const res = await fetch("/api/vault", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create vault item");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vault"] });
      toast({
        title: "Item Secured",
        description: "Your data has been encrypted and stored in the vault.",
        className: "border-primary text-primary",
      });
      setIsDialogOpen(false);
      setNewItem({ name: "", type: "text", encryptedContent: "", category: "" });
    },
  });

  // Delete item mutation
  const deleteItem = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/vault/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete vault item");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vault"] });
      toast({ title: "Item Removed", description: "Vault item has been securely deleted." });
    },
  });

  const handleUnlock = () => {
    setIsLocked(false);
    toast({
      title: "Vault Unlocked",
      description: "Biometric authentication successful. Session expires in 5 minutes.",
      className: "border-primary text-primary",
    });
  };

  const toggleShowContent = (id: string) => {
    setShowContent(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative p-4 md:p-8 max-w-6xl mx-auto space-y-6 md:space-y-8 ${isMobile ? 'pt-20' : ''}`}>
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-display font-bold text-white">Secure Vault</h1>
            <p className="text-sm md:text-base text-muted-foreground">AES-256 Encrypted Storage. Biometric Access Required.</p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground gap-2" disabled={isLocked}>
                <Plus size={16} /> Add to Vault
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-white/10 text-foreground sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <ShieldCheck className="text-primary" /> Add Secure Item
                </DialogTitle>
                <DialogDescription>
                  Your data will be encrypted with AES-256 before storage.
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Item Name</Label>
                  <Input
                    id="name"
                    value={newItem.name}
                    onChange={(e) => setNewItem(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Bank Password"
                    className="bg-black/40 border-white/10"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type">Type</Label>
                  <Select value={newItem.type} onValueChange={(v) => setNewItem(prev => ({ ...prev, type: v }))}>
                    <SelectTrigger className="bg-black/40 border-white/10">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-white/10">
                      <SelectItem value="text">Secure Note</SelectItem>
                      <SelectItem value="password">Password</SelectItem>
                      <SelectItem value="card">Credit Card</SelectItem>
                      <SelectItem value="identity">Identity Document</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Category (Optional)</Label>
                  <Input
                    id="category"
                    value={newItem.category || ""}
                    onChange={(e) => setNewItem(prev => ({ ...prev, category: e.target.value }))}
                    placeholder="e.g., Banking, Personal"
                    className="bg-black/40 border-white/10"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="content">Content</Label>
                  <Textarea
                    id="content"
                    value={newItem.encryptedContent}
                    onChange={(e) => setNewItem(prev => ({ ...prev, encryptedContent: e.target.value }))}
                    placeholder="Enter your secure data..."
                    className="bg-black/40 border-white/10 min-h-[100px]"
                  />
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)} className="border-white/10">
                  Cancel
                </Button>
                <Button 
                  onClick={() => createItem.mutate(newItem)} 
                  disabled={!newItem.name || !newItem.encryptedContent || createItem.isPending}
                  className="bg-primary text-primary-foreground"
                >
                  {createItem.isPending ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Lock className="mr-2 h-4 w-4" />}
                  Encrypt & Store
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </header>

        {/* Biometric Lock Card */}
        <Card className={`glass-panel ${isLocked ? 'border-orange-500/30 bg-orange-900/5' : 'border-primary/30 bg-primary/5'}`}>
          <CardContent className="p-4 md:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-full ${isLocked ? 'bg-orange-500/20 text-orange-500' : 'bg-primary/20 text-primary'} animate-pulse`}>
                <Lock size={24} />
              </div>
              <div>
                <h3 className={`font-bold ${isLocked ? 'text-orange-500' : 'text-primary'}`}>
                  {isLocked ? 'Vault Locked' : 'Vault Unlocked'}
                </h3>
                <p className="text-xs text-muted-foreground">
                  {isLocked ? 'Authenticate to access secure items' : 'Session expires in 4:59'}
                </p>
              </div>
            </div>
            <Button 
              onClick={isLocked ? handleUnlock : () => setIsLocked(true)}
              variant="outline" 
              className={`${isLocked ? 'border-orange-500/50 text-orange-500 hover:bg-orange-500/10' : 'border-primary/50 text-primary hover:bg-primary/10'}`}
            >
              {isLocked ? 'Unlock Vault' : 'Lock Now'}
            </Button>
          </CardContent>
        </Card>

        {/* Vault Items Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <RefreshCw className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : items.length === 0 ? (
          <Card className="glass-panel border-white/5 border-dashed">
            <CardContent className="p-8 md:p-12 text-center">
              <Lock className="mx-auto h-12 w-12 text-muted-foreground/50" />
              <h3 className="mt-4 text-lg font-medium">Your Vault is Empty</h3>
              <p className="text-muted-foreground mt-2">Add passwords, notes, and sensitive documents to keep them secure.</p>
              {!isLocked && (
                <Button 
                  onClick={() => setIsDialogOpen(true)}
                  className="mt-4 bg-primary text-primary-foreground"
                >
                  <Plus className="mr-2 h-4 w-4" /> Add Your First Item
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {items.map((item: any) => {
              const Icon = getIcon(item.type);
              const isVisible = showContent[item.id];
              
              return (
                <Card key={item.id} className="glass-panel border-white/5 hover:bg-white/5 group transition-all hover:border-primary/30 relative">
                  <CardContent className="p-4 md:p-6 flex flex-col gap-4">
                    <div className="flex items-start justify-between">
                      <div className="p-3 rounded-full bg-black/40 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                        <Icon size={24} />
                      </div>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => toggleShowContent(item.id)}
                          disabled={isLocked}
                        >
                          {isVisible ? <EyeOff size={14} /> : <Eye size={14} />}
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          onClick={() => deleteItem.mutate(item.id)}
                          disabled={isLocked}
                        >
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="font-medium truncate">{item.name}</h3>
                      <p className="text-xs text-muted-foreground capitalize mt-1">{item.type}</p>
                      {item.category && (
                        <p className="text-xs text-primary/70 mt-1">{item.category}</p>
                      )}
                    </div>

                    {!isLocked && isVisible && item.encryptedContent && (
                      <div className="mt-2 p-2 rounded bg-black/40 border border-white/5">
                        <p className="text-xs font-mono text-muted-foreground break-all">
                          {item.encryptedContent}
                        </p>
                      </div>
                    )}

                    <div className="absolute bottom-3 right-3">
                      <ShieldCheck size={14} className="text-primary/50" />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
            
            {/* Add New Button */}
            {!isLocked && (
              <button 
                onClick={() => setIsDialogOpen(true)}
                className="h-full min-h-[180px] border-2 border-dashed border-white/10 rounded-xl flex flex-col items-center justify-center gap-4 text-muted-foreground hover:text-primary hover:border-primary/50 hover:bg-primary/5 transition-all"
              >
                <Plus size={24} />
                <span className="text-sm">Add to Vault</span>
              </button>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
