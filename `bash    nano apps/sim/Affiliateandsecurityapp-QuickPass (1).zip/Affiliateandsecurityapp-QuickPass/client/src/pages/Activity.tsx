import { Sidebar } from "@/components/layout/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, Globe, Lock, AlertTriangle, CheckCircle2, Info, 
  RefreshCw, Wifi, Eye, DollarSign, User, Settings 
} from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import { useIsMobile } from "@/hooks/use-mobile";
import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";

const getIcon = (category: string) => {
  switch (category) {
    case "security": return Shield;
    case "network": return Wifi;
    case "privacy": return Eye;
    case "affiliate": return DollarSign;
    case "identity": return User;
    default: return Settings;
  }
};

const getSeverityBadge = (severity: string) => {
  switch (severity) {
    case "critical":
      return <Badge className="bg-destructive/20 text-destructive"><AlertTriangle size={10} className="mr-1" /> Critical</Badge>;
    case "warning":
      return <Badge className="bg-orange-500/20 text-orange-500"><AlertTriangle size={10} className="mr-1" /> Warning</Badge>;
    case "success":
      return <Badge className="bg-emerald-500/20 text-emerald-500"><CheckCircle2 size={10} className="mr-1" /> Success</Badge>;
    default:
      return <Badge className="bg-primary/20 text-primary"><Info size={10} className="mr-1" /> Info</Badge>;
  }
};

export default function Activity() {
  const isMobile = useIsMobile();

  // Fetch activity logs from backend
  const { data: logs = [], isLoading } = useQuery({
    queryKey: ["/api/activity"],
    queryFn: async () => {
      const res = await fetch("/api/activity?limit=100");
      if (!res.ok) throw new Error("Failed to fetch activity logs");
      return res.json();
    },
  });

  // Fallback demo data when no real logs exist
  const demoLogs = [
    { id: "1", action: "System Initialized", category: "security", details: "Security dashboard started successfully", severity: "success", createdAt: new Date().toISOString() },
    { id: "2", action: "Network Scan Complete", category: "network", details: "Scanned 47 active connections - no threats detected", severity: "info", createdAt: new Date(Date.now() - 3600000).toISOString() },
    { id: "3", action: "Privacy Audit Passed", category: "privacy", details: "All 156 apps reviewed - 12 need attention", severity: "warning", createdAt: new Date(Date.now() - 7200000).toISOString() },
  ];

  const displayLogs = logs.length > 0 ? logs : demoLogs;

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative p-4 md:p-8 max-w-4xl mx-auto space-y-6 md:space-y-8 ${isMobile ? 'pt-20' : ''}`}>
        <header>
          <h1 className="text-2xl md:text-3xl font-display font-bold text-white">Activity Log</h1>
          <p className="text-sm md:text-base text-muted-foreground">Comprehensive audit trail of all security events.</p>
        </header>

        {/* Stats Summary */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          <Card className="glass-panel border-white/5">
            <CardContent className="p-3 md:p-4 text-center">
              <p className="text-xl md:text-2xl font-bold text-white">{displayLogs.length}</p>
              <p className="text-xs text-muted-foreground">Total Events</p>
            </CardContent>
          </Card>
          <Card className="glass-panel border-emerald-500/20">
            <CardContent className="p-3 md:p-4 text-center">
              <p className="text-xl md:text-2xl font-bold text-emerald-500">
                {displayLogs.filter((l: any) => l.severity === "success" || l.severity === "info").length}
              </p>
              <p className="text-xs text-muted-foreground">Normal</p>
            </CardContent>
          </Card>
          <Card className="glass-panel border-orange-500/20">
            <CardContent className="p-3 md:p-4 text-center">
              <p className="text-xl md:text-2xl font-bold text-orange-500">
                {displayLogs.filter((l: any) => l.severity === "warning").length}
              </p>
              <p className="text-xs text-muted-foreground">Warnings</p>
            </CardContent>
          </Card>
          <Card className="glass-panel border-destructive/20">
            <CardContent className="p-3 md:p-4 text-center">
              <p className="text-xl md:text-2xl font-bold text-destructive">
                {displayLogs.filter((l: any) => l.severity === "critical").length}
              </p>
              <p className="text-xs text-muted-foreground">Critical</p>
            </CardContent>
          </Card>
        </div>

        {/* Activity List */}
        <Card className="glass-panel border-white/5">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>System Events</span>
              {isLoading && <RefreshCw className="h-4 w-4 animate-spin text-primary" />}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {displayLogs.map((log: any) => {
                const Icon = getIcon(log.category);
                const timeAgo = log.createdAt 
                  ? formatDistanceToNow(new Date(log.createdAt), { addSuffix: true })
                  : "just now";

                return (
                  <div 
                    key={log.id} 
                    className="flex items-start gap-3 md:gap-4 p-3 md:p-4 rounded-lg bg-white/5 border border-white/5 hover:border-primary/30 transition-colors"
                  >
                    <div className={`p-2 rounded-full ${
                      log.severity === "critical" ? "bg-destructive/20 text-destructive" :
                      log.severity === "warning" ? "bg-orange-500/20 text-orange-500" :
                      log.severity === "success" ? "bg-emerald-500/20 text-emerald-500" :
                      "bg-primary/20 text-primary"
                    }`}>
                      <Icon size={16} />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 sm:gap-2">
                        <h4 className="font-medium text-sm truncate">{log.action}</h4>
                        <div className="flex items-center gap-2">
                          {getSeverityBadge(log.severity)}
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{log.details}</p>
                      <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                        <span className="capitalize">{log.category}</span>
                        <span>•</span>
                        <span>{timeAgo}</span>
                      </div>
                    </div>
                  </div>
                );
              })}

              {displayLogs.length === 0 && !isLoading && (
                <div className="text-center py-8 text-muted-foreground">
                  <Shield className="mx-auto h-12 w-12 opacity-50" />
                  <p className="mt-4">No activity logs yet</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
