import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MessageSquare, Send, CheckCircle, HelpCircle, Download, CreditCard, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TicketResponse {
  success: boolean;
  ticketId: string;
  aiResponse: string;
  message: string;
}

export default function Support() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [ticketId, setTicketId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    email: "",
    name: "",
    subject: "",
    message: "",
    category: "general",
  });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch("/api/support/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const data: TicketResponse = await response.json();
        setSubmitted(true);
        setAiResponse(data.aiResponse);
        setTicketId(data.ticketId);
        toast({
          title: "Ticket Submitted",
          description: "Our AI assistant has responded to your request.",
        });
      } else {
        throw new Error("Failed to submit ticket");
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit your ticket. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }

  const faqs = [
    {
      icon: Download,
      question: "How do I download my purchase?",
      answer: "After purchase, you'll receive an email with your download link. You can also access it from the Thank You page.",
    },
    {
      icon: CreditCard,
      question: "How do I get a refund?",
      answer: "We offer a 60-day money-back guarantee through ClickBank. Contact ClickBank support or use their order lookup to request a refund.",
    },
    {
      icon: Settings,
      question: "How do I set up the app?",
      answer: "After downloading, open the app and go to Account Setup to connect your affiliate networks. The automation engine handles everything else!",
    },
  ];

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/80 py-12 px-4">
        <div className="container mx-auto max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500/20 mb-6">
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
            
            <h1 className="text-2xl font-bold mb-4 text-foreground">
              Ticket Submitted Successfully!
            </h1>
            <p className="text-muted-foreground mb-2">
              Ticket ID: <span className="font-mono text-primary">{ticketId}</span>
            </p>
          </motion.div>

          {aiResponse && (
            <Card className="mb-6 bg-card/50 border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <MessageSquare className="w-5 h-5 text-primary" />
                  AI Assistant Response
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose prose-invert max-w-none">
                  <pre className="whitespace-pre-wrap text-sm text-muted-foreground bg-background/50 p-4 rounded-lg">
                    {aiResponse}
                  </pre>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="text-center">
            <p className="text-muted-foreground mb-4">
              Need more help? Reply to the confirmation email or submit another ticket.
            </p>
            <Button
              onClick={() => {
                setSubmitted(false);
                setAiResponse(null);
                setTicketId(null);
                setFormData({
                  email: "",
                  name: "",
                  subject: "",
                  message: "",
                  category: "general",
                });
              }}
              variant="outline"
              data-testid="button-new-ticket"
            >
              Submit Another Ticket
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80 py-12 px-4">
      <div className="container mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 mb-6">
            <HelpCircle className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">24/7 AI-Powered Support</span>
          </div>
          
          <h1 className="text-3xl font-bold mb-4 text-foreground">
            How Can We Help?
          </h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Our AI assistant responds instantly to common questions. For complex issues, 
            our human support team will follow up within 24 hours.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <Card className="bg-card/50 border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-primary" />
                  Submit a Support Ticket
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Your name"
                        data-testid="input-name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="your@email.com"
                        data-testid="input-email"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger data-testid="select-category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General Question</SelectItem>
                        <SelectItem value="download">Download Issue</SelectItem>
                        <SelectItem value="technical">Technical Support</SelectItem>
                        <SelectItem value="billing">Billing/Refund</SelectItem>
                        <SelectItem value="feature">Feature Request</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject *</Label>
                    <Input
                      id="subject"
                      required
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      placeholder="Brief description of your issue"
                      data-testid="input-subject"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      required
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Please describe your issue in detail..."
                      className="min-h-[120px]"
                      data-testid="textarea-message"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={loading}
                    className="w-full"
                    data-testid="button-submit-ticket"
                  >
                    {loading ? (
                      "Submitting..."
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Submit Ticket
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-foreground">
              Frequently Asked Questions
            </h3>
            
            {faqs.map((faq, index) => (
              <Card key={index} className="bg-card/30 border-border/50">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <faq.icon className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium text-foreground mb-1">{faq.question}</h4>
                      <p className="text-sm text-muted-foreground">{faq.answer}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-4 text-center">
                <p className="text-sm text-muted-foreground mb-2">
                  Need immediate assistance?
                </p>
                <p className="font-medium text-foreground">
                  support@privately.app
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
