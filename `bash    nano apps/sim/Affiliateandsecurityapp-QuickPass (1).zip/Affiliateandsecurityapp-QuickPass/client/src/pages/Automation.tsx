import { Sidebar } from "@/components/layout/Sidebar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Zap, Bot, TrendingUp, ShoppingCart, Copy, ExternalLink, Play, Pause, 
  RefreshCw, Plus, Twitter, Instagram, Facebook, Share2, Target, DollarSign,
  CheckCircle2, AlertCircle, Link2, Calendar, Sparkles, Rocket, Activity,
  Heart, Shield, Wrench, RotateCcw, Cpu, Database, Server, Wifi
} from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import coinImage from "@assets/generated_images/futuristic_golden_digital_coin_with_circuit_patterns.png";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";

interface MarketplaceProduct {
  id: string;
  name: string;
  description?: string;
  vendorId?: string;
  category?: string;
  gravity?: string;
  commission?: string;
  initialPrice?: string;
  avgEarningsPerSale?: string;
  hopLink?: string;
  isPromoting: boolean;
}

interface SocialAccount {
  id: string;
  platform: string;
  accountName?: string;
  isActive: boolean;
}

interface Campaign {
  id: string;
  name: string;
  productId?: string;
  postContent?: string;
  hashtags?: string[];
  status: string;
  impressions: number;
  clicks: number;
  conversions: number;
}

interface ComponentHealth {
  status: "healthy" | "degraded" | "down";
  lastSuccessful: string | null;
  consecutiveFailures: number;
  errorMessage?: string;
}

interface HealthIssue {
  component: string;
  severity: "warning" | "error" | "critical";
  message: string;
  detectedAt: string;
  resolvedAt?: string;
  autoResolved: boolean;
}

interface SystemHealth {
  status: "healthy" | "degraded" | "critical";
  lastCheck: string;
  components: {
    database: ComponentHealth;
    ayrshare: ComponentHealth;
    clickbank: ComponentHealth;
    automation: ComponentHealth;
  };
  issues: HealthIssue[];
  autoRecoveryAttempts: number;
  lastRecoveryAt: string | null;
}

interface AutomationStatus {
  isEngineRunning: boolean;
  isFullyAutomated: boolean;
  networks: { total: number; active: number };
  socialAccounts: { total: number; connected: number };
  campaigns: { total: number; active: number; scheduled: number; completed: number };
  products: { discovered: number; promoting: number; inRotation?: number };
  health?: SystemHealth;
  selfHealing?: {
    autoRecoveryAttempts: number;
    lastRecoveryAt: string | null;
    activeIssues: number;
    resolvedIssues: number;
  };
  selfUpdate?: {
    lastContentRefresh: string;
    lastOptimizationRun: string;
    contentStrategiesCount: number;
  };
}

export default function Automation() {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const queryClient = useQueryClient();
  const [isDiscovering, setIsDiscovering] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<MarketplaceProduct | null>(null);
  const [showCampaignDialog, setShowCampaignDialog] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState<string>("twitter");
  const [generatedContent, setGeneratedContent] = useState<{ content: string; hashtags: string[] } | null>(null);

  const { data: automationStatus } = useQuery<AutomationStatus>({
    queryKey: ["/api/automation/status"],
    queryFn: async () => {
      const res = await fetch("/api/automation/status");
      if (!res.ok) throw new Error("Failed to fetch automation status");
      return res.json();
    },
  });

  const { data: marketplaceProducts = [] } = useQuery<MarketplaceProduct[]>({
    queryKey: ["/api/marketplace"],
    queryFn: async () => {
      const res = await fetch("/api/marketplace");
      if (!res.ok) throw new Error("Failed to fetch marketplace products");
      return res.json();
    },
  });

  const { data: socialAccounts = [] } = useQuery<SocialAccount[]>({
    queryKey: ["/api/social-accounts"],
    queryFn: async () => {
      const res = await fetch("/api/social-accounts");
      if (!res.ok) throw new Error("Failed to fetch social accounts");
      return res.json();
    },
  });

  const { data: campaigns = [] } = useQuery<Campaign[]>({
    queryKey: ["/api/campaigns"],
    queryFn: async () => {
      const res = await fetch("/api/campaigns");
      if (!res.ok) throw new Error("Failed to fetch campaigns");
      return res.json();
    },
  });

  const { data: networks = [] } = useQuery({
    queryKey: ["/api/networks"],
    queryFn: async () => {
      const res = await fetch("/api/networks");
      if (!res.ok) throw new Error("Failed to fetch networks");
      return res.json();
    },
  });

  const discoverProductsMutation = useMutation({
    mutationFn: async (networkId: string) => {
      const res = await fetch("/api/marketplace/discover", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ networkId, limit: 15 }),
      });
      if (!res.ok) throw new Error("Failed to discover products");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/marketplace"] });
      queryClient.invalidateQueries({ queryKey: ["/api/automation/status"] });
      toast({
        title: "Products Discovered!",
        description: `Found ${data.discovered} products with your affiliate links.`,
        className: "border-emerald-500/50 bg-emerald-500/10",
      });
      setIsDiscovering(false);
    },
    onError: () => {
      toast({
        title: "Discovery Failed",
        description: "Could not fetch products. Please check your network connection.",
        variant: "destructive",
      });
      setIsDiscovering(false);
    },
  });

  const toggleAutomationMutation = useMutation({
    mutationFn: async (start: boolean) => {
      const res = await fetch(`/api/automation/${start ? 'start' : 'stop'}`, {
        method: "POST",
      });
      if (!res.ok) throw new Error("Failed to toggle automation");
      return res.json();
    },
    onSuccess: (_, start) => {
      queryClient.invalidateQueries({ queryKey: ["/api/automation/status"] });
      toast({
        title: start ? "Automation Started!" : "Automation Stopped",
        description: start 
          ? "The autopilot engine is now running your campaigns."
          : "Automation engine has been paused.",
        className: start ? "border-emerald-500/50 bg-emerald-500/10" : "",
      });
    },
  });

  const generateContentMutation = useMutation({
    mutationFn: async ({ productId, platform }: { productId: string; platform: string }) => {
      const res = await fetch("/api/campaigns/generate-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, platform }),
      });
      if (!res.ok) throw new Error("Failed to generate content");
      return res.json();
    },
    onSuccess: (data) => {
      setGeneratedContent({ content: data.content, hashtags: data.hashtags });
      toast({
        title: "Content Generated!",
        description: "AI has created optimized post content for your campaign.",
      });
    },
  });

  const createCampaignMutation = useMutation({
    mutationFn: async (campaign: any) => {
      const res = await fetch("/api/campaigns", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(campaign),
      });
      if (!res.ok) throw new Error("Failed to create campaign");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/automation/status"] });
      setShowCampaignDialog(false);
      setSelectedProduct(null);
      setGeneratedContent(null);
      toast({
        title: "Campaign Created!",
        description: "Your automated campaign is now scheduled.",
        className: "border-primary/50",
      });
    },
  });

  const healthCheckMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/health/check", { method: "POST" });
      if (!res.ok) throw new Error("Failed to run health check");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/automation/status"] });
      toast({
        title: "Health Check Complete",
        description: "System health has been verified.",
        className: "border-emerald-500/50 bg-emerald-500/10",
      });
    },
  });

  const recoveryMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/health/recover", { method: "POST" });
      if (!res.ok) throw new Error("Failed to trigger recovery");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/automation/status"] });
      toast({
        title: data.success ? "Recovery Successful" : "Recovery Attempted",
        description: data.message,
        className: data.success ? "border-emerald-500/50 bg-emerald-500/10" : "",
      });
    },
  });

  const handleDiscover = () => {
    const clickbankNetwork = networks.find((n: any) => n.name.toLowerCase().includes("clickbank"));
    if (clickbankNetwork) {
      setIsDiscovering(true);
      discoverProductsMutation.mutate(clickbankNetwork.id);
    } else {
      toast({
        title: "No Network Connected",
        description: "Please connect your ClickBank account first.",
        variant: "destructive",
      });
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Affiliate link copied to clipboard.",
    });
  };

  const startCampaign = (product: MarketplaceProduct) => {
    setSelectedProduct(product);
    setShowCampaignDialog(true);
    setGeneratedContent(null);
  };

  const handleGenerateContent = () => {
    if (selectedProduct) {
      generateContentMutation.mutate({ productId: selectedProduct.id, platform: selectedPlatform });
    }
  };

  const handleCreateCampaign = () => {
    if (!selectedProduct || !generatedContent) return;
    
    createCampaignMutation.mutate({
      name: `${selectedProduct.name} - ${selectedPlatform}`,
      productId: selectedProduct.id,
      postContent: generatedContent.content,
      hashtags: generatedContent.hashtags,
      status: "scheduled",
      scheduledTime: new Date(Date.now() + 3600000).toISOString(),
    });
  };

  const hasNetworks = networks.length > 0;

  const platformIcons: Record<string, any> = {
    twitter: Twitter,
    instagram: Instagram,
    facebook: Facebook,
    tiktok: Share2,
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative p-4 md:p-8 max-w-7xl mx-auto space-y-6 md:space-y-8 ${isMobile ? 'pt-20' : ''}`}>
        
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center shadow-[0_0_15px_var(--color-primary)]">
              <Bot size={28} className="text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-white">Autopilot Marketing</h1>
              <p className="text-sm md:text-base text-muted-foreground">
                AI-powered affiliate automation • Set it and forget it
              </p>
            </div>
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            <Button 
              onClick={() => toggleAutomationMutation.mutate(!automationStatus?.isEngineRunning)}
              disabled={toggleAutomationMutation.isPending || !hasNetworks}
              className={`flex-1 md:flex-none ${
                automationStatus?.isEngineRunning 
                  ? 'bg-red-500/20 text-red-500 hover:bg-red-500/30 border border-red-500/50' 
                  : 'bg-emerald-500/20 text-emerald-500 hover:bg-emerald-500/30 border border-emerald-500/50'
              }`}
              data-testid="button-toggle-automation"
            >
              {automationStatus?.isEngineRunning ? <Pause className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}
              {automationStatus?.isEngineRunning ? "Stop Autopilot" : "Start Autopilot"}
            </Button>
            <Button 
              onClick={handleDiscover} 
              disabled={isDiscovering || !hasNetworks}
              className="flex-1 md:flex-none bg-gradient-to-r from-purple-500 to-cyan-500 text-white hover:opacity-90"
              data-testid="button-discover-products"
            >
              {isDiscovering ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
              {isDiscovering ? "Discovering..." : "Discover Products"}
            </Button>
          </div>
        </header>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <Card className="glass-panel border-purple-500/20 bg-purple-900/5">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Products</p>
                  <h3 className="text-xl font-bold text-purple-400">{automationStatus?.products.discovered || 0}</h3>
                </div>
                <ShoppingCart size={20} className="text-purple-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="glass-panel border-cyan-500/20 bg-cyan-900/5">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Campaigns</p>
                  <h3 className="text-xl font-bold text-cyan-400">{automationStatus?.campaigns.active || 0}</h3>
                </div>
                <Rocket size={20} className="text-cyan-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="glass-panel border-emerald-500/20 bg-emerald-900/5">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Active</p>
                  <h3 className="text-xl font-bold text-emerald-400">{automationStatus?.products.promoting || 0}</h3>
                </div>
                <Activity size={20} className="text-emerald-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="glass-panel border-orange-500/20 bg-orange-900/5">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Networks</p>
                  <h3 className="text-xl font-bold text-orange-400">{automationStatus?.networks.active || 0}</h3>
                </div>
                <Target size={20} className="text-orange-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {!hasNetworks ? (
          <Card className="glass-panel border-white/5 border-dashed">
            <CardContent className="p-12 text-center">
              <Bot className="mx-auto h-16 w-16 text-primary/50" />
              <h2 className="mt-6 text-2xl font-display font-bold">Connect Your Affiliate Account</h2>
              <p className="text-muted-foreground mt-2 max-w-md mx-auto">
                First, connect your ClickBank account. Then the system will automatically discover products and generate your affiliate links.
              </p>
              <Link href="/accounts">
                <Button className="mt-6 bg-primary text-primary-foreground shadow-[0_0_15px_var(--color-primary)]" data-testid="button-connect-first">
                  <Plus className="mr-2 h-4 w-4" /> Connect ClickBank Account
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="products" className="space-y-6">
            <TabsList className="bg-white/5 border border-white/10 flex flex-wrap">
              <TabsTrigger value="products" className="data-[state=active]:bg-primary/20">
                <ShoppingCart className="mr-2 h-4 w-4" /> Products ({marketplaceProducts.length})
              </TabsTrigger>
              <TabsTrigger value="campaigns" className="data-[state=active]:bg-primary/20">
                <Rocket className="mr-2 h-4 w-4" /> Campaigns ({campaigns.length})
              </TabsTrigger>
              <TabsTrigger value="social" className="data-[state=active]:bg-primary/20">
                <Share2 className="mr-2 h-4 w-4" /> Social ({socialAccounts.length})
              </TabsTrigger>
              <TabsTrigger value="health" className="data-[state=active]:bg-primary/20">
                <Heart className="mr-2 h-4 w-4" /> Health
              </TabsTrigger>
            </TabsList>

            <TabsContent value="products" className="space-y-4">
              {marketplaceProducts.length === 0 ? (
                <Card className="glass-panel border-white/5 border-dashed">
                  <CardContent className="p-8 text-center">
                    <ShoppingCart className="mx-auto h-12 w-12 text-muted-foreground" />
                    <h3 className="mt-4 font-bold">No Products Discovered Yet</h3>
                    <p className="text-sm text-muted-foreground mt-2">
                      Click "Discover Products" to fetch top-performing products from the ClickBank marketplace with your affiliate links already attached.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {marketplaceProducts.map((product) => (
                    <Card key={product.id} className="glass-panel border-white/5 hover:border-primary/30 transition-colors" data-testid={`card-product-${product.id}`}>
                      <CardContent className="p-4 space-y-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-bold text-white">{product.name}</h4>
                            <p className="text-xs text-muted-foreground mt-1">{product.category}</p>
                          </div>
                          <Badge className="bg-emerald-500/20 text-emerald-500 text-xs">
                            {product.commission}%
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div className="bg-white/5 rounded p-2">
                            <p className="text-muted-foreground">Gravity</p>
                            <p className="font-mono font-bold text-primary">{product.gravity}</p>
                          </div>
                          <div className="bg-white/5 rounded p-2">
                            <p className="text-muted-foreground">Avg Earning</p>
                            <p className="font-mono font-bold text-emerald-400">${product.avgEarningsPerSale}</p>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label className="text-xs text-muted-foreground">Your Affiliate Link</Label>
                          <div className="flex gap-2">
                            <Input 
                              value={product.hopLink || ""} 
                              readOnly 
                              className="font-mono text-xs bg-black/20 border-white/10"
                              data-testid={`input-hoplink-${product.id}`}
                            />
                            <Button 
                              size="icon" 
                              variant="outline" 
                              onClick={() => copyToClipboard(product.hopLink || "")}
                              className="shrink-0"
                              data-testid={`button-copy-${product.id}`}
                            >
                              <Copy size={14} />
                            </Button>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            className="flex-1 bg-primary/20 text-primary hover:bg-primary/30"
                            onClick={() => startCampaign(product)}
                            data-testid={`button-campaign-${product.id}`}
                          >
                            <Rocket size={14} className="mr-1" /> Create Campaign
                          </Button>
                          <Button 
                            size="icon" 
                            variant="outline"
                            onClick={() => window.open(product.hopLink, "_blank")}
                            data-testid={`button-preview-${product.id}`}
                          >
                            <ExternalLink size={14} />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="campaigns" className="space-y-4">
              {campaigns.length === 0 ? (
                <Card className="glass-panel border-white/5 border-dashed">
                  <CardContent className="p-8 text-center">
                    <Rocket className="mx-auto h-12 w-12 text-muted-foreground" />
                    <h3 className="mt-4 font-bold">No Campaigns Yet</h3>
                    <p className="text-sm text-muted-foreground mt-2">
                      Create your first campaign by selecting a product and letting AI generate the perfect social media post.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {campaigns.map((campaign) => (
                    <Card key={campaign.id} className="glass-panel border-white/5" data-testid={`card-campaign-${campaign.id}`}>
                      <CardContent className="p-4">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center">
                              <Rocket size={18} className="text-white" />
                            </div>
                            <div>
                              <h4 className="font-bold">{campaign.name}</h4>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge className={`text-xs ${
                                  campaign.status === 'active' ? 'bg-emerald-500/20 text-emerald-500' :
                                  campaign.status === 'scheduled' ? 'bg-blue-500/20 text-blue-500' :
                                  'bg-gray-500/20 text-gray-500'
                                }`}>
                                  {campaign.status}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-6 text-sm">
                            <div className="text-center">
                              <p className="text-muted-foreground text-xs">Impressions</p>
                              <p className="font-bold">{campaign.impressions}</p>
                            </div>
                            <div className="text-center">
                              <p className="text-muted-foreground text-xs">Clicks</p>
                              <p className="font-bold text-primary">{campaign.clicks}</p>
                            </div>
                            <div className="text-center">
                              <p className="text-muted-foreground text-xs">Sales</p>
                              <p className="font-bold text-emerald-500">{campaign.conversions}</p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="social" className="space-y-4">
              <Card className="glass-panel border-white/5">
                <CardHeader>
                  <CardTitle className="text-lg">Connect Social Media</CardTitle>
                  <CardDescription>Link your social accounts to enable automated posting</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {["twitter", "instagram", "facebook", "tiktok"].map((platform) => {
                      const Icon = platformIcons[platform];
                      const isConnected = socialAccounts.some(a => a.platform === platform && a.isActive);
                      
                      return (
                        <Card 
                          key={platform} 
                          className={`cursor-pointer transition-all ${
                            isConnected 
                              ? 'border-emerald-500/50 bg-emerald-500/5' 
                              : 'border-white/10 hover:border-primary/30'
                          }`}
                          data-testid={`card-social-${platform}`}
                        >
                          <CardContent className="p-4 text-center">
                            <div className={`w-12 h-12 rounded-full mx-auto flex items-center justify-center ${
                              isConnected ? 'bg-emerald-500/20' : 'bg-white/5'
                            }`}>
                              <Icon size={24} className={isConnected ? 'text-emerald-500' : 'text-muted-foreground'} />
                            </div>
                            <p className="mt-2 font-medium capitalize">{platform}</p>
                            <Badge className={`mt-2 text-[10px] ${
                              isConnected 
                                ? 'bg-emerald-500/20 text-emerald-500' 
                                : 'bg-gray-500/20 text-gray-400'
                            }`}>
                              {isConnected ? 'Connected' : 'Not Connected'}
                            </Badge>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                  <p className="text-xs text-muted-foreground mt-4 text-center">
                    Social media integration coming soon! For now, copy your affiliate links and post manually.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="health" className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-lg font-bold">System Health & Self-Healing</h3>
                  <p className="text-sm text-muted-foreground">Monitor system status and automatic recovery</p>
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => healthCheckMutation.mutate()}
                    disabled={healthCheckMutation.isPending}
                    data-testid="button-health-check"
                  >
                    {healthCheckMutation.isPending ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Heart className="mr-2 h-4 w-4" />}
                    Run Health Check
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => recoveryMutation.mutate()}
                    disabled={recoveryMutation.isPending || automationStatus?.health?.status === "healthy"}
                    className="border-orange-500/50 text-orange-500 hover:bg-orange-500/10"
                    data-testid="button-recovery"
                  >
                    {recoveryMutation.isPending ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Wrench className="mr-2 h-4 w-4" />}
                    Trigger Recovery
                  </Button>
                </div>
              </div>

              <Card className="glass-panel border-white/5">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Shield className="h-5 w-5" />
                      Overall System Status
                    </CardTitle>
                    <Badge className={`text-sm ${
                      automationStatus?.health?.status === 'healthy' 
                        ? 'bg-emerald-500/20 text-emerald-500' 
                        : automationStatus?.health?.status === 'degraded'
                        ? 'bg-yellow-500/20 text-yellow-500'
                        : 'bg-red-500/20 text-red-500'
                    }`}>
                      {automationStatus?.health?.status?.toUpperCase() || 'UNKNOWN'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { name: 'Database', key: 'database', icon: Database },
                      { name: 'Ayrshare', key: 'ayrshare', icon: Wifi },
                      { name: 'ClickBank', key: 'clickbank', icon: DollarSign },
                      { name: 'Automation', key: 'automation', icon: Cpu },
                    ].map(({ name, key, icon: Icon }) => {
                      const component = automationStatus?.health?.components?.[key as keyof typeof automationStatus.health.components];
                      const statusColor = component?.status === 'healthy' 
                        ? 'text-emerald-500 bg-emerald-500/10' 
                        : component?.status === 'degraded'
                        ? 'text-yellow-500 bg-yellow-500/10'
                        : 'text-red-500 bg-red-500/10';
                      
                      return (
                        <div key={key} className={`p-4 rounded-lg border border-white/5 ${statusColor.split(' ')[1]}`}>
                          <div className="flex items-center gap-2">
                            <Icon className={`h-5 w-5 ${statusColor.split(' ')[0]}`} />
                            <span className="font-medium">{name}</span>
                          </div>
                          <div className="mt-2 flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${
                              component?.status === 'healthy' ? 'bg-emerald-500' :
                              component?.status === 'degraded' ? 'bg-yellow-500' : 'bg-red-500'
                            }`} />
                            <span className="text-xs capitalize">{component?.status || 'unknown'}</span>
                          </div>
                          {component?.consecutiveFailures ? (
                            <p className="text-xs text-muted-foreground mt-1">
                              {component.consecutiveFailures} failure(s)
                            </p>
                          ) : null}
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="glass-panel border-white/5">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <RotateCcw className="h-4 w-4 text-cyan-500" />
                      Self-Healing Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div className="bg-white/5 rounded-lg p-4">
                        <p className="text-2xl font-bold text-cyan-400">
                          {automationStatus?.selfHealing?.autoRecoveryAttempts || 0}
                        </p>
                        <p className="text-xs text-muted-foreground">Recovery Attempts</p>
                      </div>
                      <div className="bg-white/5 rounded-lg p-4">
                        <p className="text-2xl font-bold text-emerald-400">
                          {automationStatus?.selfHealing?.resolvedIssues || 0}
                        </p>
                        <p className="text-xs text-muted-foreground">Auto-Resolved</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Active Issues</span>
                      <Badge className={automationStatus?.selfHealing?.activeIssues 
                        ? 'bg-red-500/20 text-red-500' 
                        : 'bg-emerald-500/20 text-emerald-500'
                      }>
                        {automationStatus?.selfHealing?.activeIssues || 0}
                      </Badge>
                    </div>
                    {automationStatus?.selfHealing?.lastRecoveryAt && (
                      <p className="text-xs text-muted-foreground">
                        Last Recovery: {new Date(automationStatus.selfHealing.lastRecoveryAt).toLocaleString()}
                      </p>
                    )}
                  </CardContent>
                </Card>

                <Card className="glass-panel border-white/5">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-purple-500" />
                      Self-Update Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div className="bg-white/5 rounded-lg p-4">
                        <p className="text-2xl font-bold text-purple-400">
                          {automationStatus?.selfUpdate?.contentStrategiesCount || 0}
                        </p>
                        <p className="text-xs text-muted-foreground">Content Strategies</p>
                      </div>
                      <div className="bg-white/5 rounded-lg p-4">
                        <p className="text-2xl font-bold text-orange-400">
                          {automationStatus?.products?.inRotation || 0}
                        </p>
                        <p className="text-xs text-muted-foreground">Products in Rotation</p>
                      </div>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Last Content Refresh</span>
                        <span className="text-xs">
                          {automationStatus?.selfUpdate?.lastContentRefresh 
                            ? new Date(automationStatus.selfUpdate.lastContentRefresh).toLocaleTimeString()
                            : 'Never'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Last Optimization</span>
                        <span className="text-xs">
                          {automationStatus?.selfUpdate?.lastOptimizationRun 
                            ? new Date(automationStatus.selfUpdate.lastOptimizationRun).toLocaleTimeString()
                            : 'Never'}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {automationStatus?.health?.issues && automationStatus.health.issues.length > 0 && (
                <Card className="glass-panel border-white/5">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <AlertCircle className="h-4 w-4 text-yellow-500" />
                      Recent Issues
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {automationStatus.health.issues.slice(-10).reverse().map((issue, i) => (
                        <div 
                          key={i} 
                          className={`p-3 rounded-lg border ${
                            issue.resolvedAt 
                              ? 'border-white/5 bg-white/2' 
                              : issue.severity === 'critical'
                              ? 'border-red-500/30 bg-red-500/5'
                              : 'border-yellow-500/30 bg-yellow-500/5'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Badge className={`text-xs ${
                                issue.severity === 'critical' ? 'bg-red-500/20 text-red-500' :
                                issue.severity === 'error' ? 'bg-orange-500/20 text-orange-500' :
                                'bg-yellow-500/20 text-yellow-500'
                              }`}>
                                {issue.severity}
                              </Badge>
                              <span className="font-medium text-sm">{issue.component}</span>
                            </div>
                            {issue.resolvedAt && (
                              <Badge className="bg-emerald-500/20 text-emerald-500 text-xs">
                                {issue.autoResolved ? 'Auto-Resolved' : 'Resolved'}
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{issue.message}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {new Date(issue.detectedAt).toLocaleString()}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        )}

        <Dialog open={showCampaignDialog} onOpenChange={setShowCampaignDialog}>
          <DialogContent className="bg-card border-white/10 max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Sparkles className="text-primary" size={20} />
                Create AI Campaign
              </DialogTitle>
              <DialogDescription>
                Let AI generate optimized content for {selectedProduct?.name}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <Label>Select Platform</Label>
                <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
                  <SelectTrigger className="bg-black/20 border-white/10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="twitter">Twitter / X</SelectItem>
                    <SelectItem value="instagram">Instagram</SelectItem>
                    <SelectItem value="facebook">Facebook</SelectItem>
                    <SelectItem value="tiktok">TikTok</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button 
                onClick={handleGenerateContent} 
                disabled={generateContentMutation.isPending}
                className="w-full bg-gradient-to-r from-purple-500 to-cyan-500"
                data-testid="button-generate-content"
              >
                {generateContentMutation.isPending ? (
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Sparkles className="mr-2 h-4 w-4" />
                )}
                Generate AI Content
              </Button>

              {generatedContent && (
                <>
                  <div>
                    <Label>Generated Post</Label>
                    <Textarea 
                      value={generatedContent.content}
                      onChange={(e) => setGeneratedContent({ ...generatedContent, content: e.target.value })}
                      className="bg-black/20 border-white/10 min-h-[120px]"
                      data-testid="textarea-post-content"
                    />
                  </div>
                  
                  <div>
                    <Label>Hashtags</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {generatedContent.hashtags.map((tag, i) => (
                        <Badge key={i} variant="secondary" className="bg-primary/10 text-primary">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Button 
                    onClick={handleCreateCampaign}
                    disabled={createCampaignMutation.isPending}
                    className="w-full bg-emerald-500 hover:bg-emerald-600"
                    data-testid="button-create-campaign"
                  >
                    {createCampaignMutation.isPending ? (
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Rocket className="mr-2 h-4 w-4" />
                    )}
                    Schedule Campaign
                  </Button>
                </>
              )}
            </div>
          </DialogContent>
        </Dialog>

      </main>
    </div>
  );
}
