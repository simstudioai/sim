import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Link, useRoute } from "wouter";
import { ChevronLeft, Star, Shield, Check, ExternalLink } from "lucide-react";

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string | null;
  metaTitle: string | null;
  metaDescription: string | null;
  category: string | null;
  affiliateLink: string | null;
  viewCount: number | null;
  publishedAt: string | null;
}

function ReviewsList() {
  const { data: posts = [], isLoading } = useQuery<BlogPost[]>({
    queryKey: ["/api/public/blog"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white">Loading reviews...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="max-w-4xl mx-auto px-4 py-12">
        <header className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4" data-testid="text-reviews-title">
            Trusted Product Reviews
          </h1>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto">
            Honest, in-depth reviews to help you make informed purchasing decisions
          </p>
        </header>

        {posts.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-slate-400 text-lg">No reviews available yet. Check back soon!</p>
          </div>
        ) : (
          <div className="space-y-6">
            {posts.map((post) => (
              <Link href={`/reviews/${post.slug}`} key={post.id}>
                <Card 
                  className="bg-slate-800/50 border-slate-700 hover:border-cyan-500/50 transition-all cursor-pointer group"
                  data-testid={`card-review-${post.id}`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <h2 className="text-xl font-semibold text-white group-hover:text-cyan-400 transition-colors mb-2">
                          {post.title}
                        </h2>
                        <p className="text-slate-400 line-clamp-2 mb-3">{post.excerpt}</p>
                        <div className="flex items-center gap-4 text-sm">
                          {post.category && (
                            <span className="text-cyan-400">{post.category}</span>
                          )}
                          <span className="flex items-center gap-1 text-yellow-400">
                            <Star className="w-4 h-4 fill-current" />
                            <Star className="w-4 h-4 fill-current" />
                            <Star className="w-4 h-4 fill-current" />
                            <Star className="w-4 h-4 fill-current" />
                            <Star className="w-4 h-4" />
                          </span>
                        </div>
                      </div>
                      <div className="hidden md:flex items-center text-cyan-400">
                        Read More →
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}

        <footer className="text-center mt-16 pt-8 border-t border-slate-700">
          <p className="text-slate-500 text-sm">
            Reviews are for informational purposes. We may earn commissions from purchases.
          </p>
        </footer>
      </div>
    </div>
  );
}

function ReviewDetail({ slug }: { slug: string }) {
  const { data: post, isLoading, error } = useQuery<BlogPost>({
    queryKey: [`/api/public/blog/${slug}`],
  });

  const handleAffiliateClick = async () => {
    if (post?.id) {
      try {
        const response = await fetch(`/api/public/blog/${post.id}/click`, {
          method: 'POST',
        });
        const data = await response.json();
        if (data.redirect) {
          window.open(data.redirect, '_blank');
        }
      } catch (e) {
        if (post.affiliateLink) {
          window.open(post.affiliateLink, '_blank');
        }
      }
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white">Loading review...</div>
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Review Not Found</h1>
          <Link href="/reviews">
            <Button variant="outline" className="text-cyan-400 border-cyan-400 hover:bg-cyan-400/10">
              <ChevronLeft className="w-4 h-4 mr-2" /> Back to Reviews
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const formatContent = (content: string) => {
    return content
      .replace(/^# (.+)$/gm, '<h1 class="text-3xl font-bold text-white mt-8 mb-4">$1</h1>')
      .replace(/^## (.+)$/gm, '<h2 class="text-2xl font-semibold text-white mt-6 mb-3">$1</h2>')
      .replace(/^### (.+)$/gm, '<h3 class="text-xl font-semibold text-white mt-4 mb-2">$1</h3>')
      .replace(/\*\*(.+?)\*\*/g, '<strong class="text-cyan-400">$1</strong>')
      .replace(/^\- (.+)$/gm, '<li class="ml-4 text-slate-300">• $1</li>')
      .replace(/^(\d+)\. (.+)$/gm, '<li class="ml-4 text-slate-300">$1. $2</li>')
      .replace(/✅/g, '<span class="text-green-400">✅</span>')
      .replace(/❌/g, '<span class="text-red-400">❌</span>')
      .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" class="text-cyan-400 hover:underline" target="_blank" rel="noopener">$1</a>')
      .replace(/\n\n/g, '</p><p class="text-slate-300 leading-relaxed mb-4">')
      .replace(/\|(.+)\|/g, '')
      .replace(/^$/gm, '');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="max-w-3xl mx-auto px-4 py-8">
        <Link href="/reviews">
          <Button variant="ghost" className="text-slate-400 hover:text-white mb-6" data-testid="button-back-reviews">
            <ChevronLeft className="w-4 h-4 mr-2" /> Back to Reviews
          </Button>
        </Link>

        <article data-testid={`article-review-${post.id}`}>
          <header className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">{post.title}</h1>
            <div className="flex items-center gap-4 text-sm text-slate-400">
              {post.category && <span className="text-cyan-400">{post.category}</span>}
              <span className="flex items-center gap-1 text-yellow-400">
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4" />
                4.5/5
              </span>
            </div>
          </header>

          {post.affiliateLink && (
            <Card className="bg-gradient-to-r from-cyan-900/30 to-slate-800 border-cyan-500/30 mb-8">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <Shield className="w-8 h-8 text-cyan-400" />
                    <div>
                      <p className="text-white font-semibold">60-Day Money-Back Guarantee</p>
                      <p className="text-sm text-slate-400">Risk-free purchase with full refund protection</p>
                    </div>
                  </div>
                  <Button 
                    onClick={handleAffiliateClick}
                    className="bg-cyan-500 hover:bg-cyan-600 text-white font-semibold px-6 py-2 shadow-lg shadow-cyan-500/25"
                    data-testid="button-get-access"
                  >
                    Get Instant Access <ExternalLink className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <div 
            className="prose prose-invert prose-cyan max-w-none"
            dangerouslySetInnerHTML={{ __html: `<p class="text-slate-300 leading-relaxed mb-4">${formatContent(post.content)}</p>` }}
          />

          {post.affiliateLink && (
            <Card className="bg-slate-800/80 border-slate-700 mt-12">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold text-white mb-4">Ready to Get Started?</h3>
                <div className="flex flex-col items-center gap-4 mb-6">
                  <div className="flex items-center gap-2 text-green-400">
                    <Check className="w-5 h-5" /> Instant Digital Access
                  </div>
                  <div className="flex items-center gap-2 text-green-400">
                    <Check className="w-5 h-5" /> 60-Day Money-Back Guarantee
                  </div>
                  <div className="flex items-center gap-2 text-green-400">
                    <Check className="w-5 h-5" /> Secure Checkout via ClickBank
                  </div>
                </div>
                <Button 
                  onClick={handleAffiliateClick}
                  size="lg"
                  className="bg-cyan-500 hover:bg-cyan-600 text-white font-bold text-lg px-8 py-3 shadow-lg shadow-cyan-500/25"
                  data-testid="button-cta-bottom"
                >
                  Click Here to Get Access Now
                </Button>
                <p className="text-xs text-slate-500 mt-4">
                  *Affiliate Disclosure: We may earn a commission if you purchase through our links.
                </p>
              </CardContent>
            </Card>
          )}
        </article>

        <footer className="text-center mt-16 pt-8 border-t border-slate-700">
          <p className="text-slate-500 text-sm">
            Reviews are for informational purposes. Individual results may vary.
          </p>
        </footer>
      </div>
    </div>
  );
}

export default function Reviews() {
  const [match, params] = useRoute("/reviews/:slug");
  
  if (match && params?.slug) {
    return <ReviewDetail slug={params.slug} />;
  }
  
  return <ReviewsList />;
}
