import { Sidebar } from "@/components/layout/Sidebar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, DollarSign, Briefcase, Target, Zap, CheckCircle2, AlertCircle, RefreshCw, Plus, CreditCard, Settings, Wifi, WifiOff } from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import coinImage from "@assets/generated_images/futuristic_golden_digital_coin_with_circuit_patterns.png";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { useWebSocket } from "@/hooks/use-websocket";
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";

export default function Affiliate() {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const { isConnected, lastMessage } = useWebSocket();
  const queryClient = useQueryClient();
  const [isAutoOptimizing, setIsAutoOptimizing] = useState(false);

  useEffect(() => {
    if (lastMessage?.type === "earnings_update" || lastMessage?.type === "sync_complete") {
      queryClient.invalidateQueries({ queryKey: ["/api/earnings/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/networks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    }
  }, [lastMessage, queryClient]);

  // Fetch dashboard stats
  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    queryFn: async () => {
      const res = await fetch("/api/dashboard/stats");
      if (!res.ok) throw new Error("Failed to fetch stats");
      return res.json();
    },
  });

  // Fetch connected networks
  const { data: networks = [] } = useQuery({
    queryKey: ["/api/networks"],
    queryFn: async () => {
      const res = await fetch("/api/networks");
      if (!res.ok) throw new Error("Failed to fetch networks");
      return res.json();
    },
  });

  // Fetch earnings summary
  const { data: earnings } = useQuery({
    queryKey: ["/api/earnings/summary"],
    queryFn: async () => {
      const res = await fetch("/api/earnings/summary");
      if (!res.ok) throw new Error("Failed to fetch earnings");
      return res.json();
    },
  });

  const handleOptimize = () => {
    setIsAutoOptimizing(true);
    toast({
      title: "AI Optimization Initiated",
      description: "Analyzing traffic patterns and adjusting affiliate links for maximum conversion...",
    });
    setTimeout(() => {
      setIsAutoOptimizing(false);
      toast({
        title: "Optimization Complete",
        description: "Projected revenue increase: +15% for next week.",
        className: "border-primary text-primary",
      });
    }, 3000);
  };

  // Generate mock chart data based on real earnings
  const totalRevenue = parseFloat(earnings?.total || "0");
  const earningsData = [
    { day: "Mon", amount: totalRevenue * 0.12 },
    { day: "Tue", amount: totalRevenue * 0.18 },
    { day: "Wed", amount: totalRevenue * 0.14 },
    { day: "Thu", amount: totalRevenue * 0.22 },
    { day: "Fri", amount: totalRevenue * 0.16 },
    { day: "Sat", amount: totalRevenue * 0.08 },
    { day: "Sun", amount: totalRevenue * 0.10 },
  ];

  const hasNetworks = networks.length > 0;

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative p-4 md:p-8 max-w-7xl mx-auto space-y-6 md:space-y-8 ${isMobile ? 'pt-20' : ''}`}>
        
        {/* Header */}
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
            <img src={coinImage} alt="Affiliate AI" className="w-12 h-12 md:w-16 md:h-16 rounded-full border border-primary/50 shadow-[0_0_15px_var(--color-primary)]" />
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-white">Affiliate AI Manager</h1>
              <p className="text-sm md:text-base text-muted-foreground flex items-center gap-2">
              Automated Income Generation • Multi-Network Sync
              <span className={`flex items-center gap-1 text-xs ${isConnected ? 'text-emerald-500' : 'text-orange-500'}`}>
                {isConnected ? <Wifi size={12} /> : <WifiOff size={12} />}
                {isConnected ? 'Live' : 'Offline'}
              </span>
            </p>
            </div>
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            <Button onClick={handleOptimize} disabled={isAutoOptimizing || !hasNetworks} className="flex-1 md:flex-none bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20 border border-emerald-500/50">
              {isAutoOptimizing ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Zap className="mr-2 h-4 w-4" />}
              {isAutoOptimizing ? "Optimizing..." : "Auto-Optimize Links"}
            </Button>
            <Link href="/accounts">
              <Button className="flex-1 md:flex-none bg-primary text-primary-foreground shadow-[0_0_15px_var(--color-primary)]">
                <Settings className="mr-2 h-4 w-4" /> Manage Accounts
              </Button>
            </Link>
          </div>
        </header>

        {!hasNetworks ? (
          // Empty State - No Networks Connected
          <Card className="glass-panel border-white/5 border-dashed">
            <CardContent className="p-12 text-center">
              <DollarSign className="mx-auto h-16 w-16 text-primary/50" />
              <h2 className="mt-6 text-2xl font-display font-bold">Connect Your Affiliate Accounts</h2>
              <p className="text-muted-foreground mt-2 max-w-md mx-auto">
                Link your ClickBank, ShareASale, CJ Affiliate, or other network accounts to start tracking real earnings.
              </p>
              <Link href="/accounts">
                <Button className="mt-6 bg-primary text-primary-foreground shadow-[0_0_15px_var(--color-primary)]">
                  <Plus className="mr-2 h-4 w-4" /> Connect Your First Account
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Stats Overview */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="glass-panel border-emerald-500/20 bg-emerald-900/5">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Total Revenue</p>
                      <h3 className="text-2xl font-display font-bold text-emerald-400">
                        ${parseFloat(earnings?.total || "0").toFixed(2)}
                      </h3>
                      <p className="text-xs text-emerald-500 flex items-center mt-1"><TrendingUp size={12} className="mr-1" /> Live tracking</p>
                    </div>
                    <div className="p-3 rounded-full bg-emerald-500/10 text-emerald-500">
                      <DollarSign size={20} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-panel border-white/5">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Active Networks</p>
                      <h3 className="text-2xl font-display font-bold text-white">{networks.filter((n: any) => n.status === "active").length}</h3>
                      <p className="text-xs text-muted-foreground mt-1">{networks.length} total connected</p>
                    </div>
                    <div className="p-3 rounded-full bg-primary/10 text-primary">
                      <Briefcase size={20} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-panel border-white/5">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Total Clicks</p>
                      <h3 className="text-2xl font-display font-bold text-white">{stats?.totalClicks || 0}</h3>
                      <p className="text-xs text-primary flex items-center mt-1"><Target size={12} className="mr-1" /> {stats?.todayClicks || 0} today</p>
                    </div>
                    <div className="p-3 rounded-full bg-orange-500/10 text-orange-500">
                      <Target size={20} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-panel border-white/5">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Pending Payout</p>
                      <h3 className="text-2xl font-display font-bold text-white">
                        ${parseFloat(earnings?.pending || "0").toFixed(2)}
                      </h3>
                      <p className="text-xs text-muted-foreground mt-1">Processing</p>
                    </div>
                    <div className="p-3 rounded-full bg-blue-500/10 text-blue-500">
                      <CreditCard size={20} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content Area */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Chart Section */}
              <Card className="lg:col-span-2 glass-panel border-white/5">
                <CardHeader>
                  <CardTitle>Revenue Performance</CardTitle>
                  <CardDescription>Real-time earnings tracking across all connected accounts</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={earningsData}>
                      <defs>
                        <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="var(--color-primary)" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="var(--color-primary)" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="day" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis stroke="#666" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value.toFixed(0)}`} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: 'rgba(13, 18, 30, 0.9)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                        itemStyle={{ color: '#fff' }}
                        formatter={(value: number) => [`$${value.toFixed(2)}`, 'Revenue']}
                      />
                      <Area type="monotone" dataKey="amount" stroke="var(--color-primary)" strokeWidth={2} fillOpacity={1} fill="url(#colorRevenue)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* AI Status */}
              <Card className="glass-panel border-white/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><Zap size={16} className="text-yellow-400" /> AI Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 rounded-lg bg-white/5 border border-white/5 flex gap-3 items-start">
                    <div className="mt-1"><CheckCircle2 size={16} className="text-emerald-500" /></div>
                    <div>
                      <p className="text-sm font-medium">Networks Connected</p>
                      <p className="text-xs text-muted-foreground">{networks.length} affiliate accounts linked.</p>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-white/5 border border-white/5 flex gap-3 items-start">
                    <div className="mt-1"><RefreshCw size={16} className="text-blue-500 animate-pulse" /></div>
                    <div>
                      <p className="text-sm font-medium">Auto-Sync Active</p>
                      <p className="text-xs text-muted-foreground">Earnings updated in real-time.</p>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-white/5 border border-white/5 flex gap-3 items-start">
                    <div className="mt-1"><AlertCircle size={16} className="text-orange-500" /></div>
                    <div>
                      <p className="text-sm font-medium">Optimization Available</p>
                      <p className="text-xs text-muted-foreground">Click "Auto-Optimize" to maximize conversions.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

            </div>

            {/* Programs List */}
            <Card className="glass-panel border-white/5">
              <CardHeader>
                <CardTitle>Connected Networks</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {networks.map((network: any) => (
                    <div key={network.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 rounded-lg bg-white/5 border border-white/5 hover:border-primary/30 transition-colors gap-4">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-800 to-black flex items-center justify-center border border-white/10 font-bold text-xs text-primary">
                          {network.name.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <h4 className="font-bold">{network.name}</h4>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary" className={`text-[10px] ${
                              network.status === 'active' ? 'bg-emerald-500/20 text-emerald-500' : 
                              network.status === 'error' ? 'bg-destructive/20 text-destructive' : 
                              'bg-orange-500/20 text-orange-500'
                            }`}>
                              {network.status}
                            </Badge>
                            <Badge variant="outline" className="text-[10px] border-primary/30 text-primary bg-primary/5">
                              <Zap size={8} className="mr-1" /> AI Managed
                            </Badge>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between w-full sm:w-auto gap-8">
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Account ID</p>
                          <p className="font-mono text-sm">{network.accountId || "N/A"}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Last Sync</p>
                          <p className="font-mono text-sm text-primary">
                            {network.lastSync ? new Date(network.lastSync).toLocaleDateString() : "Never"}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </>
        )}

      </main>
    </div>
  );
}
