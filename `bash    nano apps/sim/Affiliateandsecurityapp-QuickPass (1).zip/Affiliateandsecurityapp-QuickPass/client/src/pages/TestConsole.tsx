import { useState } from "react";
import { motion } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  FlaskConical, 
  ShoppingCart, 
  FileText, 
  CheckCircle, 
  AlertTriangle, 
  Trash2, 
  RefreshCw,
  ExternalLink,
  Copy,
  Activity,
  Server
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TestStatus {
  testEnvironment: {
    active: boolean;
    testPurchases: number;
    totalPurchases: number;
    supportTickets: number;
    products: number;
  };
  automation: {
    isRunning: boolean;
    selfHealingActive: boolean;
    selfUpdateActive: boolean;
  };
  health: {
    status: string;
    details: Record<string, unknown>;
  };
  endpoints: Record<string, string>;
}

interface SimulatedPurchase {
  id: string;
  transactionId: string;
  email: string;
  accessToken: string;
  downloadUrl: string;
  verifyUrl: string;
}

export default function TestConsole() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [testEmail, setTestEmail] = useState("test@example.com");
  const [testName, setTestName] = useState("Test Customer");
  const [lastPurchase, setLastPurchase] = useState<SimulatedPurchase | null>(null);
  
  const { data: status, isLoading } = useQuery<TestStatus>({
    queryKey: ["/api/test/status"],
    refetchInterval: 10000,
  });
  
  const simulatePurchase = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/test/simulate-purchase", {
        email: testEmail,
        name: testName,
        productName: "Privately App (TEST)",
        amount: "47.00",
      });
      return response.json();
    },
    onSuccess: (data) => {
      setLastPurchase(data.purchase);
      toast({
        title: "Test Purchase Created",
        description: `Transaction ${data.purchase.transactionId} created successfully`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/test/status"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Create Purchase",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const generateContent = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/test/generate-content", {});
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Content Generation Triggered",
        description: `Generated ${data.recentPosts?.length || 0} posts`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Generate Content",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const clearTestData = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("DELETE", "/api/test/clear", {});
      return response.json();
    },
    onSuccess: (data) => {
      setLastPurchase(null);
      toast({
        title: "Test Data Cleared",
        description: `Deleted ${data.deleted} test purchases`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/test/status"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Clear Data",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80 py-8 px-4">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <FlaskConical className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold text-foreground">Test Console</h1>
            <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/30">
              Development
            </Badge>
          </div>
          <p className="text-muted-foreground">
            Test purchases, automation, and delivery systems without real transactions
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <Card className="bg-card/50 border-primary/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Server className="w-4 h-4" />
                Environment Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                {status?.testEnvironment.active ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-yellow-500" />
                )}
                <span className="text-lg font-semibold">
                  {status?.testEnvironment.active ? "Active" : "Loading..."}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-primary/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <ShoppingCart className="w-4 h-4" />
                Test Purchases
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">
                {status?.testEnvironment.testPurchases || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                of {status?.testEnvironment.totalPurchases || 0} total
              </p>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-primary/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Activity className="w-4 h-4" />
                Automation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                {status?.automation?.isRunning ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-yellow-500" />
                )}
                <span className="text-lg font-semibold">
                  {status?.automation?.isRunning ? "Running" : "Stopped"}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <Card className="bg-card/50 border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-primary" />
                Simulate Purchase
              </CardTitle>
              <CardDescription>
                Create a test purchase to verify the delivery system
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="test-email">Customer Email</Label>
                <Input
                  id="test-email"
                  type="email"
                  value={testEmail}
                  onChange={(e) => setTestEmail(e.target.value)}
                  placeholder="test@example.com"
                  data-testid="input-test-email"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="test-name">Customer Name</Label>
                <Input
                  id="test-name"
                  type="text"
                  value={testName}
                  onChange={(e) => setTestName(e.target.value)}
                  placeholder="Test Customer"
                  data-testid="input-test-name"
                />
              </div>
              
              <Button
                onClick={() => simulatePurchase.mutate()}
                disabled={simulatePurchase.isPending || !testEmail}
                className="w-full"
                data-testid="button-simulate-purchase"
              >
                {simulatePurchase.isPending ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Simulate Purchase ($47)
                  </>
                )}
              </Button>
              
              {lastPurchase && (
                <div className="mt-4 p-4 bg-green-500/10 border border-green-500/30 rounded-lg space-y-3">
                  <div className="flex items-center gap-2 text-green-500 font-medium">
                    <CheckCircle className="w-4 h-4" />
                    Purchase Created Successfully
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Transaction:</span>
                      <div className="flex items-center gap-1">
                        <code className="text-xs bg-muted px-2 py-1 rounded">
                          {lastPurchase.transactionId}
                        </code>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => copyToClipboard(lastPurchase.transactionId)}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Access Token:</span>
                      <div className="flex items-center gap-1">
                        <code className="text-xs bg-muted px-2 py-1 rounded truncate max-w-[150px]">
                          {lastPurchase.accessToken.substring(0, 20)}...
                        </code>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => copyToClipboard(lastPurchase.accessToken)}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => window.open(lastPurchase.downloadUrl, "_blank")}
                      data-testid="button-test-download"
                    >
                      <ExternalLink className="w-3 h-3 mr-1" />
                      Test Thank You Page
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => window.open(lastPurchase.verifyUrl, "_blank")}
                      data-testid="button-verify-purchase"
                    >
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Verify API
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                Content Generation
              </CardTitle>
              <CardDescription>
                Test the automated content generation system
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                This will trigger the content auto-generation system to create blog posts
                for products that don't have content yet.
              </p>
              
              <div className="p-4 bg-muted/50 rounded-lg">
                <div className="text-sm space-y-1">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Products Available:</span>
                    <span className="font-medium">{status?.testEnvironment.products || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Self-Healing:</span>
                    <Badge variant={status?.automation?.selfHealingActive ? "default" : "secondary"}>
                      {status?.automation?.selfHealingActive ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Self-Update:</span>
                    <Badge variant={status?.automation?.selfUpdateActive ? "default" : "secondary"}>
                      {status?.automation?.selfUpdateActive ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                </div>
              </div>
              
              <Button
                onClick={() => generateContent.mutate()}
                disabled={generateContent.isPending}
                className="w-full"
                variant="outline"
                data-testid="button-generate-content"
              >
                {generateContent.isPending ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4 mr-2" />
                    Generate Test Content
                  </>
                )}
              </Button>
              
              <Separator />
              
              <div className="space-y-2">
                <h4 className="text-sm font-medium">Quick Links</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="justify-start"
                    onClick={() => window.location.href = "/blog"}
                  >
                    <ExternalLink className="w-3 h-3 mr-2" />
                    View Blog
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="justify-start"
                    onClick={() => window.location.href = "/automation"}
                  >
                    <ExternalLink className="w-3 h-3 mr-2" />
                    Automation
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="justify-start"
                    onClick={() => window.location.href = "/support"}
                  >
                    <ExternalLink className="w-3 h-3 mr-2" />
                    Support Page
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="justify-start"
                    onClick={() => window.location.href = "/buy"}
                  >
                    <ExternalLink className="w-3 h-3 mr-2" />
                    Sales Page
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6 bg-card/50 border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-red-500" />
              Clear Test Data
            </CardTitle>
            <CardDescription>
              Remove all test purchases (only TEST_ prefixed transactions)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                This will only delete purchases with transaction IDs starting with "TEST_".
                Real purchases are never affected.
              </div>
              <Button
                variant="destructive"
                onClick={() => clearTestData.mutate()}
                disabled={clearTestData.isPending || (status?.testEnvironment.testPurchases || 0) === 0}
                data-testid="button-clear-test-data"
              >
                {clearTestData.isPending ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Clearing...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear {status?.testEnvironment.testPurchases || 0} Test Purchases
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 text-center text-sm text-muted-foreground">
          <p>Test environment is isolated from production data</p>
        </div>
      </div>
    </div>
  );
}
