import { Sidebar } from "@/components/layout/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Eye, MousePointer, TrendingUp, Zap, RefreshCw, Plus, ExternalLink, Trash2 } from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useIsMobile } from "@/hooks/use-mobile";
import { apiRequest } from "@/lib/queryClient";

interface BlogPost {
  id: string;
  productId: string | null;
  title: string;
  slug: string;
  content: string;
  excerpt: string | null;
  metaTitle: string | null;
  metaDescription: string | null;
  keywords: string[] | null;
  category: string | null;
  affiliateLink: string | null;
  viewCount: number | null;
  clickCount: number | null;
  conversionCount: number | null;
  status: string;
  publishedAt: string | null;
  createdAt: string;
}

interface ContentStats {
  totalPosts: number;
  publishedPosts: number;
  draftPosts: number;
  totalViews: number;
  totalClicks: number;
  pendingQueue: number;
}

export default function Blog() {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);

  const { data: posts = [], isLoading: postsLoading } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog/posts"],
  });

  const { data: stats } = useQuery<ContentStats>({
    queryKey: ["/api/content/stats"],
  });

  const generateMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/content/generate"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blog/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/content/stats"] });
      toast({
        title: "Content Generated",
        description: "New blog posts have been created for your products.",
      });
      setIsGenerating(false);
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate content",
        variant: "destructive",
      });
      setIsGenerating(false);
    },
  });

  const publishMutation = useMutation({
    mutationFn: (postId: string) => apiRequest("POST", `/api/blog/posts/${postId}/publish`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blog/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/content/stats"] });
      toast({
        title: "Post Published",
        description: "Blog post is now live and visible to visitors.",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (postId: string) => apiRequest("DELETE", `/api/blog/posts/${postId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blog/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/content/stats"] });
      toast({
        title: "Post Deleted",
        description: "Blog post has been removed.",
      });
    },
  });

  const handleGenerate = () => {
    setIsGenerating(true);
    generateMutation.mutate();
  };

  const handlePublish = (postId: string) => {
    publishMutation.mutate(postId);
  };

  const handleDelete = (postId: string) => {
    if (confirm("Are you sure you want to delete this post?")) {
      deleteMutation.mutate(postId);
    }
  };

  const getPublicUrl = () => {
    if (typeof window !== "undefined") {
      return `${window.location.origin}/reviews`;
    }
    return "/reviews";
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative ${isMobile ? 'pt-16' : ''}`}>
        <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6 md:space-y-8">
          
          <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-white" data-testid="text-page-title">Blog Content</h1>
              <p className="text-sm md:text-base text-muted-foreground">Auto-generated product reviews for SEO traffic</p>
            </div>
            <div className="flex gap-4 w-full md:w-auto">
              <Button 
                variant="outline" 
                onClick={handleGenerate}
                disabled={isGenerating}
                className="flex-1 md:flex-none border-primary/50 text-primary hover:bg-primary/10 font-mono text-xs uppercase"
                data-testid="button-generate-content"
              >
                {isGenerating ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                Generate Content
              </Button>
              <Button 
                onClick={() => window.open(getPublicUrl(), "_blank")}
                className="flex-1 md:flex-none bg-primary text-primary-foreground hover:bg-primary/90 font-mono text-xs uppercase"
                data-testid="button-view-blog"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                View Public Blog
              </Button>
            </div>
          </header>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <Card className="bg-card/80 backdrop-blur border-border/50">
              <CardContent className="p-4 text-center">
                <FileText className="w-6 h-6 mx-auto mb-2 text-primary" />
                <p className="text-2xl font-bold text-white" data-testid="text-total-posts">{stats?.totalPosts || 0}</p>
                <p className="text-xs text-muted-foreground">Total Posts</p>
              </CardContent>
            </Card>
            <Card className="bg-card/80 backdrop-blur border-border/50">
              <CardContent className="p-4 text-center">
                <Zap className="w-6 h-6 mx-auto mb-2 text-green-400" />
                <p className="text-2xl font-bold text-white" data-testid="text-published-posts">{stats?.publishedPosts || 0}</p>
                <p className="text-xs text-muted-foreground">Published</p>
              </CardContent>
            </Card>
            <Card className="bg-card/80 backdrop-blur border-border/50">
              <CardContent className="p-4 text-center">
                <Eye className="w-6 h-6 mx-auto mb-2 text-blue-400" />
                <p className="text-2xl font-bold text-white" data-testid="text-total-views">{stats?.totalViews || 0}</p>
                <p className="text-xs text-muted-foreground">Total Views</p>
              </CardContent>
            </Card>
            <Card className="bg-card/80 backdrop-blur border-border/50">
              <CardContent className="p-4 text-center">
                <MousePointer className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
                <p className="text-2xl font-bold text-white" data-testid="text-total-clicks">{stats?.totalClicks || 0}</p>
                <p className="text-xs text-muted-foreground">Affiliate Clicks</p>
              </CardContent>
            </Card>
            <Card className="bg-card/80 backdrop-blur border-border/50">
              <CardContent className="p-4 text-center">
                <TrendingUp className="w-6 h-6 mx-auto mb-2 text-purple-400" />
                <p className="text-2xl font-bold text-white" data-testid="text-pending-queue">{stats?.pendingQueue || 0}</p>
                <p className="text-xs text-muted-foreground">Pending Queue</p>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-card/80 backdrop-blur border-border/50">
            <CardHeader>
              <CardTitle className="text-lg font-display text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                Blog Posts
              </CardTitle>
            </CardHeader>
            <CardContent>
              {postsLoading ? (
                <div className="text-center py-8 text-muted-foreground">Loading posts...</div>
              ) : posts.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
                  <p className="text-muted-foreground mb-4">No blog posts yet</p>
                  <Button onClick={handleGenerate} disabled={isGenerating} data-testid="button-generate-first">
                    {isGenerating ? "Generating..." : "Generate Your First Posts"}
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {posts.map((post) => (
                    <div 
                      key={post.id} 
                      className="p-4 rounded-lg bg-background/50 border border-border/30 hover:border-primary/30 transition-colors"
                      data-testid={`card-post-${post.id}`}
                    >
                      <div className="flex flex-col md:flex-row justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-lg font-semibold text-white">{post.title}</h3>
                            <Badge 
                              variant={post.status === "published" ? "default" : "secondary"}
                              className={post.status === "published" ? "bg-green-500/20 text-green-400" : ""}
                            >
                              {post.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{post.excerpt}</p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Eye className="w-3 h-3" /> {post.viewCount || 0} views
                            </span>
                            <span className="flex items-center gap-1">
                              <MousePointer className="w-3 h-3" /> {post.clickCount || 0} clicks
                            </span>
                            {post.category && (
                              <span className="text-primary">{post.category}</span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {post.status === "draft" && (
                            <Button 
                              size="sm" 
                              onClick={() => handlePublish(post.id)}
                              className="bg-green-600 hover:bg-green-700"
                              data-testid={`button-publish-${post.id}`}
                            >
                              Publish
                            </Button>
                          )}
                          {post.status === "published" && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => window.open(`/reviews/${post.slug}`, "_blank")}
                              data-testid={`button-view-${post.id}`}
                            >
                              <ExternalLink className="w-4 h-4" />
                            </Button>
                          )}
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => handleDelete(post.id)}
                            className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                            data-testid={`button-delete-${post.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-primary/5 border-primary/30">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-white mb-2">How It Works</h3>
              <div className="grid md:grid-cols-3 gap-4 text-sm text-muted-foreground">
                <div>
                  <strong className="text-primary">1. Auto-Generate</strong>
                  <p>The system automatically creates SEO-optimized product reviews for your ClickBank products.</p>
                </div>
                <div>
                  <strong className="text-primary">2. Get Traffic</strong>
                  <p>Visitors find your reviews through Google searches. No social media accounts needed.</p>
                </div>
                <div>
                  <strong className="text-primary">3. Earn Commissions</strong>
                  <p>When visitors click your affiliate links and buy, you earn commissions automatically.</p>
                </div>
              </div>
            </CardContent>
          </Card>

        </div>
      </main>
    </div>
  );
}
