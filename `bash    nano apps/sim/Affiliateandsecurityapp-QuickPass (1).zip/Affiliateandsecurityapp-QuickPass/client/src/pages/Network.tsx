import { Sidebar } from "@/components/layout/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Globe, Shield, WifiOff, ArrowUpRight, ArrowDownLeft } from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import { useIsMobile } from "@/hooks/use-mobile";

const connections = [
  { app: "System", dest: "172.217.16.14", country: "US", protocol: "HTTPS", status: "Secure", traffic: "1.2 MB", type: "out" },
  { app: "Instagram", dest: "157.240.22.35", country: "IE", protocol: "HTTPS", status: "Tracked", traffic: "450 KB", type: "out" },
  { app: "Unknown", dest: "45.33.32.156", country: "RU", protocol: "TCP", status: "Blocked", traffic: "0 B", type: "in" },
  { app: "Telegram", dest: "149.154.167.99", country: "NL", protocol: "MTProto", status: "Encrypted", traffic: "8.5 MB", type: "bidirectional" },
  { app: "Maps", dest: "142.250.190.46", country: "US", protocol: "HTTPS", status: "Secure", traffic: "2.1 MB", type: "out" },
  { app: "Chrome", dest: "104.21.55.2", country: "CA", protocol: "QUIC", status: "Secure", traffic: "15.4 MB", type: "out" },
];

export default function Network() {
  const isMobile = useIsMobile();

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative p-4 md:p-8 max-w-7xl mx-auto space-y-6 md:space-y-8 ${isMobile ? 'pt-16' : ''}`}>
        <header>
          <h1 className="text-2xl md:text-3xl font-display font-bold text-white">Network Monitor</h1>
          <p className="text-sm md:text-base text-muted-foreground">Real-time traffic analysis and connection firewall.</p>
        </header>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6">
          <Card className="glass-panel border-white/5">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 rounded-full bg-primary/10 text-primary"><Globe size={24} /></div>
              <div>
                <div className="text-2xl font-bold">12</div>
                <div className="text-xs text-muted-foreground">Active Connections</div>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-panel border-white/5">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 rounded-full bg-destructive/10 text-destructive"><WifiOff size={24} /></div>
              <div>
                <div className="text-2xl font-bold">3</div>
                <div className="text-xs text-muted-foreground">Blocked Threats</div>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-panel border-white/5">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 rounded-full bg-green-500/10 text-green-500"><Shield size={24} /></div>
              <div>
                <div className="text-2xl font-bold">100%</div>
                <div className="text-xs text-muted-foreground">Traffic Encrypted</div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="glass-panel border-white/5">
          <CardHeader>
            <CardTitle>Live Traffic Log</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow className="border-white/5 hover:bg-white/5">
                  <TableHead>Application</TableHead>
                  <TableHead>Destination</TableHead>
                  <TableHead>Protocol</TableHead>
                  <TableHead>Traffic</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {connections.map((conn, i) => (
                  <TableRow key={i} className="border-white/5 hover:bg-white/5">
                    <TableCell className="font-medium flex items-center gap-2">
                      {conn.type === 'out' && <ArrowUpRight size={14} className="text-primary" />}
                      {conn.type === 'in' && <ArrowDownLeft size={14} className="text-destructive" />}
                      {conn.app}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span>{conn.dest}</span>
                        <span className="text-[10px] text-muted-foreground">{conn.country}</span>
                      </div>
                    </TableCell>
                    <TableCell><Badge variant="outline" className="border-white/10 bg-white/5">{conn.protocol}</Badge></TableCell>
                    <TableCell className="font-mono text-xs">{conn.traffic}</TableCell>
                    <TableCell>
                      <Badge 
                        className={
                          conn.status === 'Blocked' ? 'bg-destructive text-destructive-foreground' :
                          conn.status === 'Tracked' ? 'bg-orange-500/20 text-orange-500 hover:bg-orange-500/30' :
                          'bg-primary/20 text-primary hover:bg-primary/30'
                        }
                      >
                        {conn.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
