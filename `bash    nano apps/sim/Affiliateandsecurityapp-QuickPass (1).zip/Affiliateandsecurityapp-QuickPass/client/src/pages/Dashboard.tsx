import { Sidebar } from "@/components/layout/Sidebar";
import { SecurityScore } from "@/components/dashboard/SecurityScore";
import { ThreatMap } from "@/components/dashboard/ThreatMap";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, Wifi, Globe, Smartphone, Search, ScanEye, AlertTriangle, CheckCircle } from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { useIsMobile } from "@/hooks/use-mobile";

interface ScanResults {
  scanId: string;
  timestamp: string;
  riskScore: number;
  summary: string;
  recommendations: string[];
  results: {
    dataBreaches: { checked: boolean; found: number; sources: string[] };
    socialMedia: { checked: boolean; exposures: unknown[]; sources: string[] };
    darkWeb: { checked: boolean; mentions: number; sources: string[] };
    publicRecords: { checked: boolean; found: number; details: string[] };
    dataBrokers: { checked: boolean; listedOn: string[]; sources: string[] };
  };
}

export default function Dashboard() {
  const { toast } = useToast();
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [showScanner, setShowScanner] = useState(false);
  const [showInputDialog, setShowInputDialog] = useState(false);
  const [scanEmail, setScanEmail] = useState("");
  const [scanName, setScanName] = useState("");
  const [scanPhone, setScanPhone] = useState("");
  const [scanResults, setScanResults] = useState<ScanResults | null>(null);
  const [scanLogs, setScanLogs] = useState<string[]>([]);
  const isMobile = useIsMobile();

  const handleQuickScan = () => {
    setShowInputDialog(true);
  };
  
  const startScan = async () => {
    setShowInputDialog(false);
    setShowScanner(true);
    setScanProgress(0);
    setIsScanning(true);
    setScanResults(null);
    setScanLogs([]);
    
    toast({
      title: "Initiating Digital Footprint Scan",
      description: "Checking databases and public records...",
    });

    // Animate progress while calling API
    const progressInterval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 90) return prev;
        const newProgress = prev + Math.random() * 15;
        
        // Add log messages based on progress
        if (prev < 10 && newProgress >= 10) {
          setScanLogs(l => [...l, "[OK] Database connection established..."]);
        }
        if (prev < 25 && newProgress >= 25) {
          setScanLogs(l => [...l, "[SCAN] Checking HaveIBeenPwned database..."]);
        }
        if (prev < 40 && newProgress >= 40) {
          setScanLogs(l => [...l, "[SCAN] Searching public social profiles..."]);
        }
        if (prev < 55 && newProgress >= 55) {
          setScanLogs(l => [...l, "[SCAN] Querying dark web databases..."]);
        }
        if (prev < 70 && newProgress >= 70) {
          setScanLogs(l => [...l, "[SCAN] Checking data broker listings..."]);
        }
        if (prev < 85 && newProgress >= 85) {
          setScanLogs(l => [...l, "[OK] Compiling results..."]);
        }
        
        return Math.min(newProgress, 90);
      });
    }, 200);

    try {
      const response = await fetch("/api/security/footprint-scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: scanEmail || undefined,
          name: scanName || undefined,
          phone: scanPhone || undefined,
        }),
      });
      
      clearInterval(progressInterval);
      
      if (!response.ok) throw new Error("Scan failed");
      
      const results: ScanResults = await response.json();
      setScanResults(results);
      setScanProgress(100);
      setIsScanning(false);
      
      // Add final log
      const riskLevel = results.riskScore < 20 ? "LOW" : results.riskScore < 50 ? "MODERATE" : "HIGH";
      setScanLogs(l => [...l, `[COMPLETE] Risk Level: ${riskLevel} (${results.riskScore}/100)`]);
      
      toast({
        title: "Scan Complete",
        description: results.summary,
        variant: results.riskScore >= 50 ? "destructive" : "default",
        className: results.riskScore < 50 ? "border-primary text-primary" : "",
      });
    } catch (error) {
      clearInterval(progressInterval);
      setIsScanning(false);
      setScanProgress(100);
      setScanLogs(l => [...l, "[ERROR] Scan failed - please try again"]);
      toast({
        title: "Scan Error",
        description: "Could not complete the scan. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleLockdown = () => {
    toast({
      title: "LOCKDOWN ACTIVATED",
      description: "All non-essential connections severed. Biometric auth required for app access.",
      variant: "destructive",
    });
  };

  const handleVPN = () => {
    toast({
      title: "Secure VPN Connected",
      description: "Traffic routed through encrypted tunnel (Tokyo Node #429).",
      className: "border-primary text-primary",
    });
  };

  const handlePrivateBrowsing = () => {
    toast({
      title: "Incognito Launcher",
      description: "Opening secure browser session with temporary fingerprint...",
    });
    setTimeout(() => {
      window.open("about:blank", "_blank");
    }, 1000);
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative ${isMobile ? 'pt-16' : ''}`}>
        <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6 md:space-y-8">
          
          {/* Header */}
          <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-white">System Status</h1>
              <p className="text-sm md:text-base text-muted-foreground">Real-time protection active • Samsung S25 Ultra</p>
            </div>
            <div className="flex gap-4 w-full md:w-auto">
              <Button 
                variant="outline" 
                onClick={handleQuickScan}
                className="flex-1 md:flex-none border-primary/50 text-primary hover:bg-primary/10 font-mono text-xs uppercase"
              >
                Quick Scan
              </Button>
              <Button 
                onClick={handleLockdown}
                className="flex-1 md:flex-none bg-primary text-primary-foreground hover:bg-primary/90 font-mono text-xs uppercase shadow-[0_0_15px_var(--color-primary)]"
              >
                Activate Lockdown
              </Button>
            </div>
          </header>

          {/* Top Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            {[
              { label: "Apps Monitored", value: "142", icon: Smartphone, status: "Active" },
              { label: "Network Shield", value: "On", icon: Globe, status: "Protected" },
              { label: "Data Leaks", value: "0", icon: Shield, status: "Clean" },
              { label: "Active Conns", value: "12", icon: Wifi, status: "Encrypted" },
            ].map((stat, i) => (
              <Card key={i} className="glass-panel border-white/5 bg-card/50">
                <CardContent className="p-3 md:p-4 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] md:text-xs text-muted-foreground uppercase font-mono mb-1">{stat.label}</p>
                    <h3 className="text-xl md:text-2xl font-display font-bold">{stat.value}</h3>
                    <span className="text-[10px] text-primary flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                      {stat.status}
                    </span>
                  </div>
                  <div className="p-2 md:p-3 rounded-full bg-primary/10 text-primary">
                    <stat.icon size={16} className="md:w-5 md:h-5" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Main Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Security Score - Large Card */}
            <Card className="lg:col-span-1 glass-panel border-white/5">
              <CardHeader>
                <CardTitle className="text-lg font-medium">Security Index</CardTitle>
              </CardHeader>
              <CardContent className="h-[300px]">
                <SecurityScore />
                <div className="mt-4 grid grid-cols-2 gap-4 text-center">
                  <div className="p-2 rounded bg-white/5">
                    <div className="text-2xl font-bold text-primary">A+</div>
                    <div className="text-xs text-muted-foreground">Identity Score</div>
                  </div>
                  <div className="p-2 rounded bg-white/5">
                    <div className="text-2xl font-bold text-primary">98%</div>
                    <div className="text-xs text-muted-foreground">Network Health</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Threat Map - Wide Card */}
            <Card className="lg:col-span-2 glass-panel border-white/5">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-medium">Global Connection Tracker</CardTitle>
                <div className="flex gap-2">
                  <span className="flex items-center gap-1 text-xs text-muted-foreground"><div className="w-2 h-2 rounded-full bg-primary" /> Safe</span>
                  <span className="flex items-center gap-1 text-xs text-muted-foreground"><div className="w-2 h-2 rounded-full bg-destructive" /> Threat</span>
                </div>
              </CardHeader>
              <CardContent>
                <ThreatMap />
                <div className="mt-4 grid grid-cols-3 gap-4 text-xs font-mono text-muted-foreground">
                  <div>OUTBOUND: 4.2 MB/s</div>
                  <div>INBOUND: 1.1 MB/s</div>
                  <div className="text-right">LATENCY: 42ms</div>
                </div>
              </CardContent>
            </Card>

            {/* Activity Feed */}
            <Card className="lg:col-span-2 glass-panel border-white/5">
              <CardHeader>
                <CardTitle className="text-lg font-medium">Recent Events</CardTitle>
              </CardHeader>
              <CardContent>
                <ActivityFeed />
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="lg:col-span-1 glass-panel border-white/5 bg-gradient-to-b from-primary/5 to-transparent">
              <CardHeader>
                <CardTitle className="text-lg font-medium">Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button onClick={() => toast({ title: "Auditor Running", description: "Scanning app permissions in background." })} variant="secondary" className="w-full justify-start gap-2 bg-white/5 hover:bg-white/10 border border-white/10">
                  <Shield size={16} className="text-primary" /> Permission Audit
                </Button>
                <Button onClick={handlePrivateBrowsing} variant="secondary" className="w-full justify-start gap-2 bg-white/5 hover:bg-white/10 border border-white/10">
                  <Globe size={16} className="text-primary" /> Anonymous Browsing
                </Button>
                <Button onClick={handleVPN} variant="secondary" className="w-full justify-start gap-2 bg-white/5 hover:bg-white/10 border border-white/10">
                  <Wifi size={16} className="text-primary" /> VPN Settings
                </Button>
                <Button onClick={() => setShowScanner(true)} variant="secondary" className="w-full justify-start gap-2 bg-white/5 hover:bg-white/10 border border-white/10">
                  <ScanEye size={16} className="text-primary" /> Digital Footprint Scan
                </Button>
              </CardContent>
            </Card>

          </div>
        </div>

        {/* Input Dialog for Scan */}
        <Dialog open={showInputDialog} onOpenChange={setShowInputDialog}>
          <DialogContent className="bg-card border-white/10 text-foreground sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <ScanEye className="text-primary" /> Digital Footprint Scan
              </DialogTitle>
              <DialogDescription>
                Enter your information to check for data exposure across public databases, social media, and the dark web.
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-4 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="scan-email">Email Address</Label>
                <Input 
                  id="scan-email"
                  type="email" 
                  placeholder="your@email.com"
                  value={scanEmail}
                  onChange={(e) => setScanEmail(e.target.value)}
                  className="bg-white/5 border-white/10"
                  data-testid="input-scan-email"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="scan-name">Full Name (optional)</Label>
                <Input 
                  id="scan-name"
                  placeholder="John Doe"
                  value={scanName}
                  onChange={(e) => setScanName(e.target.value)}
                  className="bg-white/5 border-white/10"
                  data-testid="input-scan-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="scan-phone">Phone Number (optional)</Label>
                <Input 
                  id="scan-phone"
                  placeholder="+1 555-123-4567"
                  value={scanPhone}
                  onChange={(e) => setScanPhone(e.target.value)}
                  className="bg-white/5 border-white/10"
                  data-testid="input-scan-phone"
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowInputDialog(false)}>
                Cancel
              </Button>
              <Button 
                onClick={startScan}
                className="bg-primary text-primary-foreground"
                data-testid="button-start-scan"
              >
                <ScanEye className="w-4 h-4 mr-2" />
                Start Scan
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Scanner Progress/Results Modal */}
        <Dialog open={showScanner} onOpenChange={setShowScanner}>
          <DialogContent className="bg-card border-white/10 text-foreground sm:max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {isScanning ? (
                  <>
                    <ScanEye className="text-primary animate-pulse" /> 
                    Scanning Digital Footprint...
                  </>
                ) : scanResults ? (
                  <>
                    {scanResults.riskScore < 20 ? (
                      <CheckCircle className="text-green-500" />
                    ) : scanResults.riskScore < 50 ? (
                      <AlertTriangle className="text-yellow-500" />
                    ) : (
                      <AlertTriangle className="text-red-500" />
                    )}
                    Scan Complete
                  </>
                ) : (
                  <>
                    <ScanEye className="text-primary" /> Scan Results
                  </>
                )}
              </DialogTitle>
              <DialogDescription>
                {isScanning 
                  ? "Searching public databases, social media, and dark web..."
                  : scanResults?.summary || "Your digital footprint analysis"}
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-4 space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-mono text-muted-foreground">
                  <span>PROGRESS</span>
                  <span>{Math.round(scanProgress)}%</span>
                </div>
                <Progress value={scanProgress} className="h-2 bg-white/10" />
              </div>
              
              <div className="space-y-2">
                <p className="text-sm font-medium">Scan Log:</p>
                <div className="h-28 bg-black/40 rounded-md p-3 font-mono text-xs text-green-500/80 overflow-y-auto space-y-1">
                  {scanLogs.map((log, i) => (
                    <div key={i} className={log.includes("ERROR") ? "text-red-500" : log.includes("COMPLETE") ? "text-primary font-bold" : ""}>
                      {log}
                    </div>
                  ))}
                </div>
              </div>
              
              {scanResults && !isScanning && (
                <>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Risk Score</p>
                    <div className="flex items-center gap-3">
                      <div className={`text-3xl font-bold ${
                        scanResults.riskScore < 20 ? "text-green-500" : 
                        scanResults.riskScore < 50 ? "text-yellow-500" : "text-red-500"
                      }`}>
                        {scanResults.riskScore}/100
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {scanResults.riskScore < 20 ? "Low Risk" : 
                         scanResults.riskScore < 50 ? "Moderate Risk" : "High Risk"}
                      </span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Recommendations</p>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      {scanResults.recommendations.map((rec, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <Shield className="w-3 h-3 mt-0.5 text-primary" />
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                </>
              )}
            </div>
            
            {!isScanning && (
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowScanner(false)}>
                  Close
                </Button>
                <Button onClick={() => { setShowScanner(false); setShowInputDialog(true); }}>
                  New Scan
                </Button>
              </DialogFooter>
            )}
          </DialogContent>
        </Dialog>

      </main>
    </div>
  );
}
