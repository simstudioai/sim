import { Sidebar } from "@/components/layout/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, RefreshCw, Trash2, CheckCircle2, AlertCircle, Clock, Link2, Twitter, Facebook, Instagram, Youtube, Share2 } from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const networkOptions = [
  { id: "clickbank", name: "ClickBank", requiresApiKey: true, requiresAccountId: true },
  { id: "shareasale", name: "ShareASale", requiresApiKey: true, requiresAccountId: true },
  { id: "cj", name: "CJ Affiliate", requiresApiKey: true, requiresAccountId: true },
  { id: "impact", name: "Impact", requiresApiKey: true, requiresAccountId: true },
  { id: "rakuten", name: "Rakuten Advertising", requiresApiKey: true, requiresAccountId: true },
  { id: "awin", name: "Awin", requiresApiKey: true, requiresAccountId: true },
  { id: "annex360", name: "Annex360", requiresApiKey: true, requiresAccountId: false },
  { id: "other", name: "Other Network", requiresApiKey: true, requiresAccountId: true },
];

const socialPlatforms = [
  { id: "twitter", name: "Twitter / X", icon: Twitter, color: "#1DA1F2" },
  { id: "facebook", name: "Facebook", icon: Facebook, color: "#4267B2" },
  { id: "instagram", name: "Instagram", icon: Instagram, color: "#E4405F" },
  { id: "tiktok", name: "TikTok", icon: Share2, color: "#000000" },
  { id: "youtube", name: "YouTube", icon: Youtube, color: "#FF0000" },
  { id: "pinterest", name: "Pinterest", icon: Share2, color: "#BD081C" },
];

export default function AccountSetup() {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedNetwork, setSelectedNetwork] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [accountId, setAccountId] = useState("");
  const [customName, setCustomName] = useState("");

  const { data: networks = [], isLoading } = useQuery({
    queryKey: ["/api/networks"],
    queryFn: async () => {
      const res = await fetch("/api/networks");
      if (!res.ok) throw new Error("Failed to fetch networks");
      return res.json();
    },
  });

  const { data: socialAccounts = [], isLoading: loadingSocial } = useQuery<any[]>({
    queryKey: ["/api/social-accounts"],
    queryFn: async () => {
      const res = await fetch("/api/social-accounts");
      if (!res.ok) throw new Error("Failed to fetch social accounts");
      return res.json();
    },
  });

  const createNetwork = useMutation({
    mutationFn: async (data: { name: string; apiKey: string; accountId?: string; status: string }) => {
      const res = await fetch("/api/networks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create network");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/networks"] });
      toast({
        title: "Network Connected",
        description: "Your affiliate account has been linked successfully.",
        className: "border-primary text-primary",
      });
      setIsDialogOpen(false);
      resetForm();
    },
    onError: () => {
      toast({
        title: "Connection Failed",
        description: "Could not connect to the affiliate network. Please check your credentials.",
        variant: "destructive",
      });
    },
  });

  const deleteNetwork = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/networks/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete network");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/networks"] });
      toast({ title: "Network Removed", description: "Affiliate account has been disconnected." });
    },
  });

  const syncNetwork = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/networks/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "active", lastSync: new Date().toISOString() }),
      });
      if (!res.ok) throw new Error("Failed to sync network");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/networks"] });
      toast({ title: "Sync Complete", description: "Earnings data has been updated.", className: "border-primary text-primary" });
    },
  });

  const deleteSocialAccount = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/social-accounts/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete account");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/social-accounts"] });
      toast({ title: "Account Disconnected", description: "Social media account has been removed." });
    },
  });

  const initiateOAuth = async (platform: typeof socialPlatforms[0]) => {
    toast({ title: `Connecting to ${platform.name}`, description: "Setting up connection..." });
    
    const res = await fetch("/api/social-accounts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        platform: platform.id,
        accountName: `@demo_${platform.id}`,
        accessToken: `token_${Date.now()}`,
        isActive: true,
      }),
    });
    if (res.ok) {
      queryClient.invalidateQueries({ queryKey: ["/api/social-accounts"] });
      toast({ title: "Account Connected", description: `Your ${platform.name} account has been linked.`, className: "border-primary text-primary" });
    }
  };

  const resetForm = () => {
    setSelectedNetwork("");
    setApiKey("");
    setAccountId("");
    setCustomName("");
  };

  const handleSubmit = () => {
    const networkInfo = networkOptions.find(n => n.id === selectedNetwork);
    const name = selectedNetwork === "other" ? customName : networkInfo?.name || selectedNetwork;
    createNetwork.mutate({ name, apiKey, accountId: accountId || undefined, status: "pending" });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active": return <Badge className="bg-emerald-500/20 text-emerald-500"><CheckCircle2 size={12} className="mr-1" /> Active</Badge>;
      case "error": return <Badge className="bg-destructive/20 text-destructive"><AlertCircle size={12} className="mr-1" /> Error</Badge>;
      default: return <Badge className="bg-orange-500/20 text-orange-500"><Clock size={12} className="mr-1" /> Pending</Badge>;
    }
  };

  const getPlatformIcon = (platformId: string) => {
    const platform = socialPlatforms.find(p => p.id === platformId);
    return platform?.icon || Share2;
  };

  const isConnected = (platformId: string) => socialAccounts.some((a: any) => a.platform === platformId);

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative p-4 md:p-8 max-w-5xl mx-auto space-y-6 ${isMobile ? 'pt-20' : ''}`}>
        
        <header>
          <h1 className="text-2xl md:text-3xl font-display font-bold text-white">Account Connections</h1>
          <p className="text-sm md:text-base text-muted-foreground">Link affiliate networks and social media for automated marketing.</p>
        </header>

        <Tabs defaultValue="affiliate" className="space-y-6">
          <TabsList className="bg-card/50 border border-white/10">
            <TabsTrigger value="affiliate" data-testid="tab-affiliate">Affiliate Networks</TabsTrigger>
            <TabsTrigger value="social" data-testid="tab-social">Social Media</TabsTrigger>
          </TabsList>

          <TabsContent value="affiliate" className="space-y-4">
            <div className="flex justify-end">
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary text-primary-foreground shadow-[0_0_15px_var(--color-primary)]" data-testid="button-connect-network">
                    <Plus className="mr-2 h-4 w-4" /> Connect Network
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-card border-white/10 text-foreground sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Link2 className="text-primary" /> Connect Affiliate Network
                    </DialogTitle>
                    <DialogDescription>Enter your API credentials to link your affiliate account.</DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="network">Affiliate Network</Label>
                      <Select value={selectedNetwork} onValueChange={setSelectedNetwork}>
                        <SelectTrigger className="bg-black/40 border-white/10">
                          <SelectValue placeholder="Select a network" />
                        </SelectTrigger>
                        <SelectContent className="bg-card border-white/10">
                          {networkOptions.map((network) => (
                            <SelectItem key={network.id} value={network.id}>{network.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {selectedNetwork === "other" && (
                      <div className="space-y-2">
                        <Label htmlFor="customName">Network Name</Label>
                        <Input id="customName" value={customName} onChange={(e) => setCustomName(e.target.value)} placeholder="Enter network name" className="bg-black/40 border-white/10" />
                      </div>
                    )}

                    <div className="space-y-2">
                      <Label htmlFor="accountId">Account ID / Username</Label>
                      <Input id="accountId" value={accountId} onChange={(e) => setAccountId(e.target.value)} placeholder="Your account ID" className="bg-black/40 border-white/10" />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="apiKey">API Key / Secret</Label>
                      <Input id="apiKey" type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="Your API key" className="bg-black/40 border-white/10" />
                    </div>
                  </div>

                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsDialogOpen(false)} className="border-white/10">Cancel</Button>
                    <Button onClick={handleSubmit} disabled={!selectedNetwork || !apiKey || createNetwork.isPending} className="bg-primary text-primary-foreground">
                      {createNetwork.isPending && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
                      Connect
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>

            {isLoading ? (
              <Card className="glass-panel border-white/5">
                <CardContent className="p-8 text-center">
                  <RefreshCw className="mx-auto h-8 w-8 animate-spin text-primary" />
                  <p className="mt-4 text-muted-foreground">Loading connected accounts...</p>
                </CardContent>
              </Card>
            ) : networks.length === 0 ? (
              <Card className="glass-panel border-white/5 border-dashed">
                <CardContent className="p-8 text-center">
                  <Link2 className="mx-auto h-12 w-12 text-muted-foreground/50" />
                  <h3 className="mt-4 text-lg font-medium">No Networks Connected</h3>
                  <p className="text-muted-foreground mt-2">Connect your first affiliate network to start tracking earnings.</p>
                  <Button onClick={() => setIsDialogOpen(true)} className="mt-4 bg-primary text-primary-foreground">
                    <Plus className="mr-2 h-4 w-4" /> Connect Your First Network
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {networks.map((network: any) => (
                  <Card key={network.id} className="glass-panel border-white/5 hover:border-primary/30 transition-colors">
                    <CardContent className="p-4 md:p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                      <div className="flex items-center gap-4 w-full md:w-auto">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-gray-800 to-black flex items-center justify-center border border-white/10 font-bold text-sm text-primary">
                          {network.name.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <h3 className="font-bold text-lg">{network.name}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            {getStatusBadge(network.status)}
                            {network.accountId && <span className="text-xs text-muted-foreground">ID: {network.accountId}</span>}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 w-full md:w-auto justify-end">
                        <Button variant="outline" size="sm" onClick={() => syncNetwork.mutate(network.id)} disabled={syncNetwork.isPending} className="border-white/10">
                          <RefreshCw className={`h-4 w-4 mr-2 ${syncNetwork.isPending ? 'animate-spin' : ''}`} />
                          Sync
                        </Button>
                        <Button variant="destructive" size="sm" onClick={() => deleteNetwork.mutate(network.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            <Card className="glass-panel border-white/5 bg-primary/5">
              <CardHeader>
                <CardTitle className="text-lg">Where to Find Your API Credentials</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm text-muted-foreground">
                <div><strong className="text-foreground">ClickBank:</strong> Account Settings → API Keys → Create New Developer Key</div>
                <div><strong className="text-foreground">ShareASale:</strong> Tools → API Settings → Request API Token</div>
                <div><strong className="text-foreground">CJ Affiliate:</strong> Account → Web Services → Personal Access Token</div>
                <div><strong className="text-foreground">Impact:</strong> Settings → API & Integrations → Generate Key</div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="social" className="space-y-6">
            <Card className="glass-panel border-white/5">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Share2 className="text-primary" /> Connect Social Media Accounts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-6">
                  Connect your social media accounts to enable automated posting for your affiliate campaigns.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {socialPlatforms.map((platform) => {
                    const Icon = platform.icon;
                    const connected = isConnected(platform.id);
                    const connectedAccount = socialAccounts.find((a: any) => a.platform === platform.id);
                    
                    return (
                      <Card key={platform.id} className={`border transition-all ${connected ? 'border-primary/50 bg-primary/5' : 'border-white/10 hover:border-white/20'}`}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-3">
                              <div className="p-2 rounded-lg" style={{ backgroundColor: `${platform.color}20` }}>
                                <Icon size={20} style={{ color: platform.color }} />
                              </div>
                              <div>
                                <h4 className="font-medium">{platform.name}</h4>
                                {connected && connectedAccount && (
                                  <p className="text-xs text-muted-foreground">{connectedAccount.accountName}</p>
                                )}
                              </div>
                            </div>
                            {connected && (
                              <Badge className="bg-green-500/20 text-green-500">
                                <CheckCircle2 size={12} className="mr-1" /> Connected
                              </Badge>
                            )}
                          </div>
                          
                          {connected ? (
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="w-full border-red-500/30 text-red-500 hover:bg-red-500/10"
                              onClick={() => connectedAccount && deleteSocialAccount.mutate(connectedAccount.id)}
                              data-testid={`button-disconnect-${platform.id}`}
                            >
                              <Trash2 size={14} className="mr-2" /> Disconnect
                            </Button>
                          ) : (
                            <Button 
                              size="sm" 
                              className="w-full"
                              style={{ backgroundColor: platform.color }}
                              onClick={() => initiateOAuth(platform)}
                              data-testid={`button-connect-${platform.id}`}
                            >
                              Connect {platform.name}
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {socialAccounts.length > 0 && (
              <Card className="glass-panel border-white/5">
                <CardHeader>
                  <CardTitle className="text-lg">Connected Accounts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {socialAccounts.map((account: any) => {
                      const platform = socialPlatforms.find(p => p.id === account.platform);
                      const Icon = platform?.icon || Share2;
                      return (
                        <div key={account.id} className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/5">
                          <div className="flex items-center gap-3">
                            <Icon size={20} style={{ color: platform?.color }} />
                            <div>
                              <p className="font-medium">{platform?.name || account.platform}</p>
                              <p className="text-xs text-muted-foreground">{account.accountName}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {account.isActive ? (
                              <Badge className="bg-green-500/20 text-green-500">Active</Badge>
                            ) : (
                              <Badge className="bg-red-500/20 text-red-500">Inactive</Badge>
                            )}
                            <Button variant="ghost" size="sm" onClick={() => deleteSocialAccount.mutate(account.id)}>
                              <Trash2 size={16} className="text-red-500" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            <Card className="glass-panel border-white/5 bg-yellow-500/5 border-yellow-500/20">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-yellow-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-yellow-500">OAuth Setup Required</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      Full OAuth integration requires setting up developer apps on each platform. 
                      Currently showing demo connections. Contact support to complete the setup for live posting.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
