import { Sidebar } from "@/components/layout/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Share2, Copy, Check, RefreshCw, Twitter, Facebook, Instagram, Linkedin, 
  MessageSquare, Hash, Clock, TrendingUp, Zap, ExternalLink, Calendar, 
  Save, Trash2, BarChart3, BookmarkPlus
} from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useIsMobile } from "@/hooks/use-mobile";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface Product {
  id: string;
  name: string;
  category: string | null;
  commission: number;
  hopLink: string | null;
  affiliateLink: string | null;
  description: string | null;
}

const getProductLink = (product: Product): string | null => {
  return product.hopLink || product.affiliateLink;
};

interface SocialPost {
  id: string;
  platform: string;
  content: string;
  hashtags: string[];
  productName: string;
  hopLink: string;
  createdAt: string;
  copied: boolean;
}

interface ScheduledPost {
  id: string;
  platform: string;
  content: string;
  hashtags: string[];
  scheduledFor: string;
  status: string;
}

interface ContentTemplate {
  id: string;
  name: string;
  platform: string;
  content: string;
  hashtags: string[];
  usageCount: number;
}

interface SocialAnalytic {
  platform: string;
  postsGenerated: number;
  postsCopied: number;
  date: string;
}

const PLATFORMS = [
  { id: "twitter", name: "X (Twitter)", icon: Twitter, color: "text-blue-400", charLimit: 280 },
  { id: "facebook", name: "Facebook", icon: Facebook, color: "text-blue-600", charLimit: 63206 },
  { id: "instagram", name: "Instagram", icon: Instagram, color: "text-pink-500", charLimit: 2200 },
  { id: "linkedin", name: "LinkedIn", icon: Linkedin, color: "text-blue-500", charLimit: 3000 },
  { id: "tiktok", name: "TikTok", icon: MessageSquare, color: "text-white", charLimit: 2200 },
];

export default function SocialMedia() {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const queryClient = useQueryClient();
  const [selectedPlatform, setSelectedPlatform] = useState("twitter");
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [generatedPosts, setGeneratedPosts] = useState<SocialPost[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [customContent, setCustomContent] = useState("");
  const [activeTab, setActiveTab] = useState("generate");
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("");
  const [templateName, setTemplateName] = useState("");
  const [showTemplateDialog, setShowTemplateDialog] = useState(false);

  const { data: products = [], isLoading: productsLoading, refetch } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    staleTime: 0,
  });

  const { data: scheduledPosts = [] } = useQuery<ScheduledPost[]>({
    queryKey: ["/api/social/scheduled"],
  });

  const { data: templates = [] } = useQuery<ContentTemplate[]>({
    queryKey: ["/api/social/templates"],
  });

  const { data: analytics = [] } = useQuery<SocialAnalytic[]>({
    queryKey: ["/api/social/analytics"],
  });

  useEffect(() => {
    queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    refetch();
  }, []);

  const generateContentMutation = useMutation({
    mutationFn: async ({ productId, platform }: { productId: string; platform: string }) => {
      const response = await fetch(`/api/content/generate/${productId}?platform=${platform}`);
      if (!response.ok) throw new Error("Failed to generate content");
      return response.json();
    },
    onSuccess: (data: { content: string; hashtags: string[]; productName: string; hopLink: string }, variables) => {
      const newPost: SocialPost = {
        id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        platform: variables.platform,
        content: data.content,
        hashtags: data.hashtags || [],
        productName: data.productName,
        hopLink: data.hopLink,
        createdAt: new Date().toISOString(),
        copied: false,
      };
      setGeneratedPosts(prev => [newPost, ...prev].slice(0, 50));
      setCustomContent(data.content + (data.hashtags?.length ? '\n\n' + data.hashtags.map((h: string) => `#${h}`).join(' ') : ''));
      setIsGenerating(false);
      queryClient.invalidateQueries({ queryKey: ["/api/social/analytics"] });
      toast({
        title: "Content Generated",
        description: `Social media post ready for ${PLATFORMS.find(p => p.id === variables.platform)?.name}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate content",
        variant: "destructive",
      });
      setIsGenerating(false);
    },
  });

  const generateBulkMutation = useMutation({
    mutationFn: async () => {
      const posts: SocialPost[] = [];
      const activeProducts = products.filter(p => getProductLink(p)).slice(0, 5);
      
      for (const product of activeProducts) {
        for (const platform of PLATFORMS.slice(0, 3)) {
          try {
            const response = await fetch(`/api/content/generate/${product.id}?platform=${platform.id}`);
            if (!response.ok) continue;
            const data = await response.json();
            posts.push({
              id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
              platform: platform.id,
              content: data.content,
              hashtags: data.hashtags || [],
              productName: data.productName,
              hopLink: data.hopLink,
              createdAt: new Date().toISOString(),
              copied: false,
            });
          } catch (e) {
            console.error(`Failed to generate for ${product.name} on ${platform.id}`);
          }
        }
      }
      return posts;
    },
    onSuccess: (posts) => {
      setGeneratedPosts(prev => [...posts, ...prev].slice(0, 100));
      setIsGenerating(false);
      queryClient.invalidateQueries({ queryKey: ["/api/social/analytics"] });
      toast({
        title: "Bulk Generation Complete",
        description: `Generated ${posts.length} social media posts`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Bulk Generation Failed",
        description: error.message || "Failed to generate content",
        variant: "destructive",
      });
      setIsGenerating(false);
    },
  });

  const schedulePostMutation = useMutation({
    mutationFn: async (data: { productId: string; platform: string; content: string; hashtags: string[]; scheduledFor: string }) => {
      const response = await fetch("/api/social/scheduled", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to schedule post");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/social/scheduled"] });
      setScheduleDate("");
      setScheduleTime("");
      toast({
        title: "Post Scheduled",
        description: "Your post has been scheduled successfully",
      });
    },
  });

  const deleteScheduledMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/social/scheduled/${id}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Failed to delete");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/social/scheduled"] });
      toast({ title: "Scheduled post deleted" });
    },
  });

  const saveTemplateMutation = useMutation({
    mutationFn: async (data: { name: string; platform: string; content: string; hashtags: string[] }) => {
      const response = await fetch("/api/social/templates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to save template");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/social/templates"] });
      setShowTemplateDialog(false);
      setTemplateName("");
      toast({ title: "Template Saved", description: "Your content template has been saved" });
    },
  });

  const deleteTemplateMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/social/templates/${id}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Failed to delete");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/social/templates"] });
      toast({ title: "Template deleted" });
    },
  });

  const trackCopyMutation = useMutation({
    mutationFn: async (data: { platform: string; productId: string | null }) => {
      await fetch("/api/social/track-copy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/social/analytics"] });
    },
  });

  const handleGenerate = () => {
    if (!selectedProduct) {
      toast({
        title: "Select a Product",
        description: "Please select a product to generate content for",
        variant: "destructive",
      });
      return;
    }
    setIsGenerating(true);
    generateContentMutation.mutate({ productId: selectedProduct, platform: selectedPlatform });
  };

  const handleBulkGenerate = () => {
    setIsGenerating(true);
    generateBulkMutation.mutate();
  };

  const handleSchedule = () => {
    if (!customContent || !scheduleDate || !scheduleTime) {
      toast({ title: "Missing Info", description: "Please fill in content and schedule time", variant: "destructive" });
      return;
    }
    const scheduledFor = new Date(`${scheduleDate}T${scheduleTime}`).toISOString();
    const hashtags = customContent.match(/#\w+/g)?.map(h => h.slice(1)) || [];
    schedulePostMutation.mutate({
      productId: selectedProduct || "",
      platform: selectedPlatform,
      content: customContent.replace(/#\w+/g, '').trim(),
      hashtags,
      scheduledFor,
    });
  };

  const handleSaveTemplate = () => {
    if (!templateName || !customContent) {
      toast({ title: "Missing Info", description: "Please provide template name and content", variant: "destructive" });
      return;
    }
    const hashtags = customContent.match(/#\w+/g)?.map(h => h.slice(1)) || [];
    saveTemplateMutation.mutate({
      name: templateName,
      platform: selectedPlatform,
      content: customContent.replace(/#\w+/g, '').trim(),
      hashtags,
    });
  };

  const loadTemplate = (template: ContentTemplate) => {
    setCustomContent(template.content + (template.hashtags?.length ? '\n\n' + template.hashtags.map(h => `#${h}`).join(' ') : ''));
    setSelectedPlatform(template.platform);
    toast({ title: "Template Loaded", description: `Loaded "${template.name}"` });
  };

  const copyToClipboard = async (post: SocialPost) => {
    const fullContent = post.content + (post.hashtags.length ? '\n\n' + post.hashtags.map(h => `#${h}`).join(' ') : '');
    try {
      await navigator.clipboard.writeText(fullContent);
      setCopiedId(post.id);
      setGeneratedPosts(prev => prev.map(p => p.id === post.id ? { ...p, copied: true } : p));
      trackCopyMutation.mutate({ platform: post.platform, productId: null });
      toast({
        title: "Copied!",
        description: "Content copied to clipboard. Paste it in your social media app.",
      });
      setTimeout(() => setCopiedId(null), 2000);
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Please select and copy the text manually",
        variant: "destructive",
      });
    }
  };

  const copyCustomContent = async () => {
    try {
      await navigator.clipboard.writeText(customContent);
      trackCopyMutation.mutate({ platform: selectedPlatform, productId: selectedProduct });
      toast({
        title: "Copied!",
        description: "Content copied to clipboard.",
      });
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Please select and copy the text manually",
        variant: "destructive",
      });
    }
  };

  const getPlatformIcon = (platformId: string) => {
    const platform = PLATFORMS.find(p => p.id === platformId);
    if (!platform) return Share2;
    return platform.icon;
  };

  const getPlatformColor = (platformId: string) => {
    const platform = PLATFORMS.find(p => p.id === platformId);
    return platform?.color || "text-white";
  };

  const postsToday = generatedPosts.filter(p => {
    const postDate = new Date(p.createdAt).toDateString();
    return postDate === new Date().toDateString();
  }).length;

  const copiedToday = generatedPosts.filter(p => p.copied && 
    new Date(p.createdAt).toDateString() === new Date().toDateString()
  ).length;

  const totalGenerated = analytics.reduce((sum, a) => sum + (a.postsGenerated || 0), 0);
  const totalCopied = analytics.reduce((sum, a) => sum + (a.postsCopied || 0), 0);

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative ${isMobile ? 'pt-16' : ''}`}>
        <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6 md:space-y-8">
          
          <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-white" data-testid="text-page-title">Social Media</h1>
              <p className="text-sm md:text-base text-muted-foreground">Generate, schedule, and track content for your social platforms</p>
            </div>
            <Button 
              onClick={handleBulkGenerate}
              disabled={isGenerating || products.length === 0}
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-mono text-xs uppercase"
              data-testid="button-bulk-generate"
            >
              {isGenerating ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Zap className="w-4 h-4 mr-2" />}
              Bulk Generate All Platforms
            </Button>
          </header>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <Card className="bg-card/80 backdrop-blur border-border/50">
              <CardContent className="p-4 text-center">
                <Share2 className="w-6 h-6 mx-auto mb-2 text-primary" />
                <p className="text-2xl font-bold text-white" data-testid="text-posts-generated">{generatedPosts.length}</p>
                <p className="text-xs text-muted-foreground">Session Posts</p>
              </CardContent>
            </Card>
            <Card className="bg-card/80 backdrop-blur border-border/50">
              <CardContent className="p-4 text-center">
                <BarChart3 className="w-6 h-6 mx-auto mb-2 text-purple-400" />
                <p className="text-2xl font-bold text-white" data-testid="text-total-generated">{totalGenerated}</p>
                <p className="text-xs text-muted-foreground">Total Generated</p>
              </CardContent>
            </Card>
            <Card className="bg-card/80 backdrop-blur border-border/50">
              <CardContent className="p-4 text-center">
                <Copy className="w-6 h-6 mx-auto mb-2 text-green-400" />
                <p className="text-2xl font-bold text-white" data-testid="text-copied-count">{totalCopied}</p>
                <p className="text-xs text-muted-foreground">Total Copied</p>
              </CardContent>
            </Card>
            <Card className="bg-card/80 backdrop-blur border-border/50">
              <CardContent className="p-4 text-center">
                <Calendar className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
                <p className="text-2xl font-bold text-white" data-testid="text-scheduled-count">{scheduledPosts.length}</p>
                <p className="text-xs text-muted-foreground">Scheduled</p>
              </CardContent>
            </Card>
            <Card className="bg-card/80 backdrop-blur border-border/50">
              <CardContent className="p-4 text-center">
                <BookmarkPlus className="w-6 h-6 mx-auto mb-2 text-cyan-400" />
                <p className="text-2xl font-bold text-white" data-testid="text-templates-count">{templates.length}</p>
                <p className="text-xs text-muted-foreground">Templates</p>
              </CardContent>
            </Card>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-4 bg-background/50 mb-4">
              <TabsTrigger value="generate" className="data-[state=active]:bg-primary/20">
                <Zap className="w-4 h-4 mr-2" />Generate
              </TabsTrigger>
              <TabsTrigger value="scheduled" className="data-[state=active]:bg-primary/20">
                <Calendar className="w-4 h-4 mr-2" />Scheduled
              </TabsTrigger>
              <TabsTrigger value="templates" className="data-[state=active]:bg-primary/20">
                <BookmarkPlus className="w-4 h-4 mr-2" />Templates
              </TabsTrigger>
              <TabsTrigger value="analytics" className="data-[state=active]:bg-primary/20">
                <BarChart3 className="w-4 h-4 mr-2" />Analytics
              </TabsTrigger>
            </TabsList>

            <TabsContent value="generate">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-card/80 backdrop-blur border-border/50">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Zap className="w-5 h-5 text-primary" />
                      Generate Content
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm text-muted-foreground">Select Product</label>
                      <Select value={selectedProduct || ""} onValueChange={setSelectedProduct}>
                        <SelectTrigger className="bg-background/50 border-border/50" data-testid="select-product">
                          <SelectValue placeholder="Choose a product..." />
                        </SelectTrigger>
                        <SelectContent>
                          {products.filter(p => getProductLink(p)).map(product => (
                            <SelectItem key={product.id} value={product.id}>
                              {product.name} ({product.commission}% commission)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm text-muted-foreground">Platform</label>
                      <Tabs value={selectedPlatform} onValueChange={setSelectedPlatform}>
                        <TabsList className="grid grid-cols-5 bg-background/50">
                          {PLATFORMS.map(platform => {
                            const Icon = platform.icon;
                            return (
                              <TabsTrigger 
                                key={platform.id} 
                                value={platform.id}
                                className="data-[state=active]:bg-primary/20"
                                data-testid={`tab-${platform.id}`}
                              >
                                <Icon className={`w-4 h-4 ${platform.color}`} />
                              </TabsTrigger>
                            );
                          })}
                        </TabsList>
                      </Tabs>
                      <p className="text-xs text-muted-foreground">
                        {PLATFORMS.find(p => p.id === selectedPlatform)?.name} - Max {PLATFORMS.find(p => p.id === selectedPlatform)?.charLimit} characters
                      </p>
                    </div>

                    <Button 
                      onClick={handleGenerate}
                      disabled={isGenerating || !selectedProduct}
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                      data-testid="button-generate"
                    >
                      {isGenerating ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Zap className="w-4 h-4 mr-2" />}
                      Generate Post
                    </Button>

                    {customContent && (
                      <div className="space-y-2 pt-4 border-t border-border/50">
                        <div className="flex items-center justify-between">
                          <label className="text-sm text-muted-foreground">Generated Content (editable)</label>
                          <div className="flex gap-2">
                            <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
                              <DialogTrigger asChild>
                                <Button size="sm" variant="outline" className="border-cyan-500/50 text-cyan-500">
                                  <Save className="w-3 h-3 mr-1" />Save
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="bg-card border-border">
                                <DialogHeader>
                                  <DialogTitle className="text-white">Save as Template</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <Input 
                                    placeholder="Template name..." 
                                    value={templateName}
                                    onChange={(e) => setTemplateName(e.target.value)}
                                    className="bg-background/50"
                                  />
                                  <Button onClick={handleSaveTemplate} className="w-full bg-primary">
                                    Save Template
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={copyCustomContent}
                              className="border-primary/50 text-primary"
                              data-testid="button-copy-custom"
                            >
                              <Copy className="w-3 h-3 mr-1" />Copy
                            </Button>
                          </div>
                        </div>
                        <Textarea 
                          value={customContent}
                          onChange={(e) => setCustomContent(e.target.value)}
                          className="min-h-[150px] bg-background/50 border-border/50 font-mono text-sm"
                          data-testid="textarea-custom-content"
                        />
                        <p className="text-xs text-muted-foreground text-right">
                          {customContent.length} / {PLATFORMS.find(p => p.id === selectedPlatform)?.charLimit} characters
                        </p>

                        <div className="flex gap-2 pt-2">
                          <Input 
                            type="date" 
                            value={scheduleDate}
                            onChange={(e) => setScheduleDate(e.target.value)}
                            className="bg-background/50 border-border/50"
                          />
                          <Input 
                            type="time" 
                            value={scheduleTime}
                            onChange={(e) => setScheduleTime(e.target.value)}
                            className="bg-background/50 border-border/50"
                          />
                          <Button 
                            onClick={handleSchedule}
                            variant="outline"
                            className="border-yellow-500/50 text-yellow-500"
                          >
                            <Calendar className="w-4 h-4 mr-1" />Schedule
                          </Button>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="bg-card/80 backdrop-blur border-border/50">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Clock className="w-5 h-5 text-yellow-400" />
                      Post Queue
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {generatedPosts.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <Share2 className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>No posts generated yet</p>
                        <p className="text-sm">Select a product and click Generate</p>
                      </div>
                    ) : (
                      <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
                        {generatedPosts.map(post => {
                          const Icon = getPlatformIcon(post.platform);
                          return (
                            <div 
                              key={post.id}
                              className={`p-3 rounded-lg border ${post.copied ? 'border-green-500/50 bg-green-500/5' : 'border-border/50 bg-background/30'}`}
                              data-testid={`post-${post.id}`}
                            >
                              <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-2">
                                  <Icon className={`w-4 h-4 ${getPlatformColor(post.platform)}`} />
                                  <span className="text-sm font-medium text-white">{post.productName}</span>
                                  {post.copied && <Badge variant="outline" className="border-green-500 text-green-500 text-xs">Copied</Badge>}
                                </div>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => copyToClipboard(post)}
                                  className={copiedId === post.id ? "text-green-500" : "text-muted-foreground hover:text-white"}
                                  data-testid={`button-copy-${post.id}`}
                                >
                                  {copiedId === post.id ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                                </Button>
                              </div>
                              <p className="text-sm text-muted-foreground line-clamp-3">{post.content}</p>
                              {post.hashtags.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {post.hashtags.slice(0, 5).map((tag, i) => (
                                    <Badge key={i} variant="secondary" className="text-xs bg-primary/10 text-primary">
                                      #{tag}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                              <p className="text-xs text-muted-foreground mt-2">
                                {new Date(post.createdAt).toLocaleTimeString()}
                              </p>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="scheduled">
              <Card className="bg-card/80 backdrop-blur border-border/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-yellow-400" />
                    Scheduled Posts
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {scheduledPosts.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No scheduled posts</p>
                      <p className="text-sm">Generate content and use the Schedule button</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {scheduledPosts.map(post => {
                        const Icon = getPlatformIcon(post.platform);
                        return (
                          <div key={post.id} className="p-4 rounded-lg border border-border/50 bg-background/30">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <Icon className={`w-4 h-4 ${getPlatformColor(post.platform)}`} />
                                <Badge variant="outline" className="border-yellow-500 text-yellow-500">
                                  {new Date(post.scheduledFor).toLocaleString()}
                                </Badge>
                                <Badge variant="secondary">{post.status}</Badge>
                              </div>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => deleteScheduledMutation.mutate(post.id)}
                                className="text-red-500 hover:text-red-400"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                            <p className="text-sm text-muted-foreground">{post.content}</p>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="templates">
              <Card className="bg-card/80 backdrop-blur border-border/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <BookmarkPlus className="w-5 h-5 text-cyan-400" />
                    Saved Templates
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {templates.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <BookmarkPlus className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No templates saved</p>
                      <p className="text-sm">Generate content and click Save to create templates</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {templates.map(template => {
                        const Icon = getPlatformIcon(template.platform);
                        return (
                          <div key={template.id} className="p-4 rounded-lg border border-border/50 bg-background/30">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <Icon className={`w-4 h-4 ${getPlatformColor(template.platform)}`} />
                                <span className="font-medium text-white">{template.name}</span>
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => loadTemplate(template)}
                                  className="border-primary/50 text-primary"
                                >
                                  Use
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => deleteTemplateMutation.mutate(template.id)}
                                  className="text-red-500"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground line-clamp-2">{template.content}</p>
                            <p className="text-xs text-muted-foreground mt-2">Used {template.usageCount || 0} times</p>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics">
              <Card className="bg-card/80 backdrop-blur border-border/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-purple-400" />
                    Content Analytics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
                    {PLATFORMS.map(platform => {
                      const Icon = platform.icon;
                      const platformAnalytics = analytics.filter(a => a.platform === platform.id);
                      const generated = platformAnalytics.reduce((sum, a) => sum + (a.postsGenerated || 0), 0);
                      const copied = platformAnalytics.reduce((sum, a) => sum + (a.postsCopied || 0), 0);
                      return (
                        <Card key={platform.id} className="bg-background/30 border-border/50">
                          <CardContent className="p-4 text-center">
                            <Icon className={`w-8 h-8 mx-auto mb-2 ${platform.color}`} />
                            <p className="text-lg font-bold text-white">{generated}</p>
                            <p className="text-xs text-muted-foreground">Generated</p>
                            <p className="text-sm text-green-400 mt-1">{copied} copied</p>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                  {analytics.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <BarChart3 className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No analytics data yet</p>
                      <p className="text-sm">Generate and copy content to see stats</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {analytics.slice(0, 10).map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-3 rounded bg-background/30">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{item.platform}</Badge>
                            <span className="text-sm text-muted-foreground">
                              {new Date(item.date).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="flex gap-4 text-sm">
                            <span className="text-primary">{item.postsGenerated} generated</span>
                            <span className="text-green-400">{item.postsCopied} copied</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <Card className="bg-card/80 backdrop-blur border-border/50">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <ExternalLink className="w-5 h-5 text-cyan-400" />
                Quick Post Links
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                After copying your content, click a button below to open the platform and paste your post.
              </p>
              <div className="flex flex-wrap gap-3">
                <Button
                  variant="outline"
                  onClick={() => window.open("https://twitter.com/compose/tweet", "_blank")}
                  className="border-blue-400/50 text-blue-400 hover:bg-blue-400/10"
                  data-testid="button-open-twitter"
                >
                  <Twitter className="w-4 h-4 mr-2" />
                  Post to X
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.open("https://www.facebook.com/", "_blank")}
                  className="border-blue-600/50 text-blue-600 hover:bg-blue-600/10"
                  data-testid="button-open-facebook"
                >
                  <Facebook className="w-4 h-4 mr-2" />
                  Post to Facebook
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.open("https://www.instagram.com/", "_blank")}
                  className="border-pink-500/50 text-pink-500 hover:bg-pink-500/10"
                  data-testid="button-open-instagram"
                >
                  <Instagram className="w-4 h-4 mr-2" />
                  Open Instagram
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.open("https://www.linkedin.com/feed/", "_blank")}
                  className="border-blue-500/50 text-blue-500 hover:bg-blue-500/10"
                  data-testid="button-open-linkedin"
                >
                  <Linkedin className="w-4 h-4 mr-2" />
                  Post to LinkedIn
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.open("https://www.tiktok.com/upload", "_blank")}
                  className="border-white/50 text-white hover:bg-white/10"
                  data-testid="button-open-tiktok"
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Open TikTok
                </Button>
              </div>
            </CardContent>
          </Card>

        </div>
      </main>
    </div>
  );
}
