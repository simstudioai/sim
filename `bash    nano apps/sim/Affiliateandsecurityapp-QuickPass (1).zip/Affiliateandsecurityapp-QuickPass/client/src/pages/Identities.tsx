import { Sidebar } from "@/components/layout/Sidebar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { User, Briefcase, ShoppingCart, Plus, Trash2, Edit, Mail, Phone, CreditCard } from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import { useIsMobile } from "@/hooks/use-mobile";
import { useToast } from "@/hooks/use-toast";

const personas = [
  { 
    id: 1, 
    name: "Public / Social", 
    type: "Personal", 
    email: "j.doe.public@gmail.com", 
    phone: "+1 (555) 123-4567",
    color: "bg-blue-500",
    icon: User,
    active: true
  },
  { 
    id: 2, 
    name: "Professional", 
    type: "Work", 
    email: "john.doe@corp.inc", 
    phone: "+1 (555) 987-6543",
    color: "bg-slate-500",
    icon: Briefcase,
    active: false
  },
  { 
    id: 3, 
    name: "Shopping / Burner", 
    type: "Anonymous", 
    email: "temp.x92@proton.me", 
    phone: "+1 (555) 000-1111",
    color: "bg-orange-500",
    icon: ShoppingCart,
    active: false
  },
];

export default function Identities() {
  const isMobile = useIsMobile();
  const { toast } = useToast();

  const handleCreatePersona = () => {
    toast({
      title: "Creating New Persona",
      description: "This feature will allow you to create a new isolated digital identity.",
    });
  };

  const handleEditPersona = (name: string) => {
    toast({
      title: "Editing Persona",
      description: `Opening editor for ${name} identity.`,
    });
  };

  const handleDeletePersona = (name: string) => {
    toast({
      title: "Persona Deleted",
      description: `${name} identity has been removed.`,
      variant: "destructive",
    });
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative ${isMobile ? 'pt-16' : ''}`}>
        <div className="p-4 md:p-8 max-w-6xl mx-auto space-y-6 md:space-y-8">
          
          <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-white">Identity Compartmentalization</h1>
              <p className="text-sm md:text-base text-muted-foreground">Manage isolated digital personas to prevent data aggregation.</p>
            </div>
            <Button onClick={handleCreatePersona} className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2 w-full md:w-auto">
              <Plus size={16} /> Create New Persona
            </Button>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {personas.map((persona) => (
              <Card key={persona.id} className={`glass-panel border-white/5 group hover:border-primary/50 transition-all duration-300 ${persona.active ? 'ring-1 ring-primary shadow-[0_0_20px_-5px_var(--color-primary)]' : ''}`}>
                <CardHeader className="relative pb-2">
                  <div className="flex justify-between items-start mb-2">
                    <div className={`p-3 rounded-xl ${persona.color} text-white shadow-lg`}>
                      <persona.icon size={24} />
                    </div>
                    {persona.active && <Badge variant="default" className="bg-primary text-primary-foreground">Active</Badge>}
                  </div>
                  <CardTitle className="text-xl">{persona.name}</CardTitle>
                  <CardDescription>{persona.type} Identity</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 text-sm text-muted-foreground bg-black/20 p-2 rounded border border-white/5">
                      <Mail size={14} /> {persona.email}
                    </div>
                    <div className="flex items-center gap-3 text-sm text-muted-foreground bg-black/20 p-2 rounded border border-white/5">
                      <Phone size={14} /> {persona.phone}
                    </div>
                    <div className="flex items-center gap-3 text-sm text-muted-foreground bg-black/20 p-2 rounded border border-white/5">
                      <CreditCard size={14} /> ************4291
                    </div>
                  </div>

                  <div className="pt-4 flex gap-2">
                    <Button onClick={() => handleEditPersona(persona.name)} variant="outline" size="sm" className="flex-1 border-white/10 hover:bg-white/5">
                      <Edit size={14} className="mr-2" /> Edit
                    </Button>
                    <Button onClick={() => handleDeletePersona(persona.name)} variant="destructive" size="sm" className="w-10 p-0">
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Add New Placeholder */}
            <button className="h-full min-h-[300px] border-2 border-dashed border-white/10 rounded-xl flex flex-col items-center justify-center gap-4 text-muted-foreground hover:text-primary hover:border-primary/50 hover:bg-primary/5 transition-all group">
              <div className="p-4 rounded-full bg-white/5 group-hover:bg-primary/20 transition-colors">
                <Plus size={32} />
              </div>
              <span className="font-medium">Add Another Identity</span>
            </button>
          </div>

        </div>
      </main>
    </div>
  );
}
