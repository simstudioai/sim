import { Sidebar } from "@/components/layout/Sidebar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AlertTriangle, Mic, Camera, MapPin, FolderOpen, User, Smartphone } from "lucide-react";
import texture from "@assets/generated_images/dark_hexagon_grid_background_texture.png";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";

const apps = [
  { id: 1, name: "Flashlight Pro", risk: "Critical", permissions: ["Camera", "Location", "Contacts"], icon: Smartphone },
  { id: 2, name: "Social Connect", risk: "High", permissions: ["Microphone", "Background Data", "Contacts"], icon: User },
  { id: 3, name: "Photo Editor", risk: "Medium", permissions: ["Storage", "Camera"], icon: Camera },
  { id: 4, name: "Maps Navigator", risk: "Low", permissions: ["Location"], icon: MapPin },
];

export default function Auditor() {
  const { toast } = useToast();
  const isMobile = useIsMobile();

  const handleRevoke = (appName: string) => {
    toast({
      title: "Permissions Revoked",
      description: `Successfully removed dangerous permissions from ${appName}.`,
      variant: "destructive", // Using destructive style for "action taken against threat"
      className: "bg-green-900/50 border-green-500 text-white", // Custom success style override if needed, but destructive is fine for "Revoke"
    });
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <div className="fixed inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: `url(${texture})`, backgroundSize: 'cover' }} />
      <Sidebar />
      
      <main className={`flex-1 overflow-y-auto z-10 relative p-4 md:p-8 max-w-5xl mx-auto space-y-6 md:space-y-8 ${isMobile ? 'pt-16' : ''}`}>
        <header className="flex flex-col md:flex-row justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-display font-bold text-white">Privacy Auditor</h1>
            <p className="text-sm md:text-base text-muted-foreground">Scan installed apps for dangerous permissions and trackers.</p>
          </div>
          <div className="text-left md:text-right flex items-center md:block gap-4">
            <div className="text-3xl font-bold text-destructive">2</div>
            <div className="text-xs text-muted-foreground uppercase tracking-widest">Critical Risks</div>
          </div>
        </header>

        <div className="grid gap-4">
          {apps.map((app) => (
            <Card key={app.id} className="glass-panel border-white/5 hover:border-primary/30 transition-colors">
              <CardContent className="p-4 md:p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-4 w-full md:w-auto">
                  <div className={`p-3 rounded-xl ${
                    app.risk === 'Critical' ? 'bg-destructive/20 text-destructive' :
                    app.risk === 'High' ? 'bg-orange-500/20 text-orange-500' :
                    'bg-blue-500/20 text-blue-500'
                  }`}>
                    <app.icon size={24} />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-lg">{app.name}</h3>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {app.permissions.map(p => (
                        <Badge key={p} variant="secondary" className="text-[10px] bg-white/5 text-muted-foreground border-white/10">
                          {p}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between w-full md:w-auto gap-4 mt-2 md:mt-0">
                  <div className="text-left md:text-right">
                    <div className={`font-bold ${
                      app.risk === 'Critical' ? 'text-destructive' :
                      app.risk === 'High' ? 'text-orange-500' :
                      'text-blue-500'
                    }`}>{app.risk} Risk</div>
                    <div className="text-xs text-muted-foreground">Unused for 2 weeks</div>
                  </div>
                  <Button 
                    onClick={() => handleRevoke(app.name)}
                    variant="destructive" 
                    size="sm" 
                    className="shadow-[0_0_10px_var(--color-destructive)] opacity-90 hover:opacity-100 whitespace-nowrap"
                  >
                    Revoke Access
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
}
