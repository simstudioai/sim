import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Download, Mail, HelpCircle, Shield, XCircle } from "lucide-react";

interface PurchaseInfo {
  valid: boolean;
  productName: string;
  purchasedAt: string;
  email: string;
}

export default function ThankYou() {
  const [location] = useLocation();
  const params = useParams<{ token?: string }>();
  const [purchaseInfo, setPurchaseInfo] = useState<PurchaseInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [verified, setVerified] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Get token from URL path or query parameter only
  const getToken = (): string | null => {
    // Check route params first (from /thank-you/:token or /download/:token)
    if (params.token && params.token.startsWith('priv_')) {
      return params.token;
    }
    // Check query parameter
    const urlParams = new URLSearchParams(window.location.search);
    const queryToken = urlParams.get('token');
    if (queryToken && queryToken.startsWith('priv_')) {
      return queryToken;
    }
    return null;
  };

  const token = getToken();

  useEffect(() => {
    if (token) {
      verifyPurchase(token);
    } else {
      setLoading(false);
      setError("No valid access token provided. Please use the download link from your purchase confirmation email.");
    }
  }, [token]);

  async function verifyPurchase(accessToken: string) {
    try {
      const response = await fetch(`/api/purchase/verify/${encodeURIComponent(accessToken)}`);
      if (response.ok) {
        const data = await response.json();
        if (data.valid) {
          setPurchaseInfo(data);
          setVerified(true);
        } else {
          setError("Your purchase could not be verified. Please contact support.");
        }
      } else {
        setError("Invalid or expired access token. Please check your email for the correct download link, or contact support.");
      }
    } catch (err) {
      setError("An error occurred while verifying your purchase. Please try again or contact support.");
    } finally {
      setLoading(false);
    }
  }

  const [downloadStatus, setDownloadStatus] = useState<{ success: boolean; message: string; downloading?: boolean } | null>(null);
  
  const handleDownload = async () => {
    if (!verified || !token) return;
    
    setDownloadStatus({ success: true, message: "Preparing download...", downloading: true });
    
    try {
      const response = await fetch(`/api/download/${encodeURIComponent(token)}`);
      
      // Check if we got a zip file (binary content)
      const contentType = response.headers.get('content-type');
      
      if (response.ok && contentType?.includes('application/zip')) {
        // Download the zip file
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'privately-app.zip';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        setDownloadStatus({
          success: true,
          message: "Download started! Check your downloads folder for 'privately-app.zip'.",
          downloading: false,
        });
      } else {
        // Got JSON response (error or instructions)
        const data = await response.json();
        setDownloadStatus({
          success: false,
          message: data.error || data.message || 'Download failed. Please try again or contact support.',
          downloading: false,
        });
      }
    } catch (error) {
      setDownloadStatus({
        success: false,
        message: 'Download failed. Please try again or contact support.',
        downloading: false,
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-primary">Verifying your purchase...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80 py-12 px-4">
      <div className="container mx-auto max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          {verified ? (
            <>
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-500/20 mb-6">
                <CheckCircle className="w-10 h-10 text-green-500" />
              </div>
              
              <h1 className="text-3xl font-bold mb-4 text-foreground">
                Thank You for Your Purchase!
              </h1>
              <p className="text-muted-foreground">
                Your order has been confirmed and your download is ready.
              </p>
            </>
          ) : (
            <>
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-muted/20 mb-6">
                <Shield className="w-10 h-10 text-muted-foreground" />
              </div>
              
              <h1 className="text-3xl font-bold mb-4 text-foreground">
                Verify Your Purchase
              </h1>
              <p className="text-muted-foreground">
                Please use the download link from your purchase confirmation email.
              </p>
            </>
          )}
        </motion.div>

        {purchaseInfo && (
          <Card className="mb-6 bg-card/50 border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                Order Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Product:</span>
                <span className="font-medium">{purchaseInfo.productName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Email:</span>
                <span className="font-medium">{purchaseInfo.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Date:</span>
                <span className="font-medium">
                  {new Date(purchaseInfo.purchasedAt).toLocaleDateString()}
                </span>
              </div>
            </CardContent>
          </Card>
        )}

        {error && !verified && (
          <Card className="mb-6 bg-red-500/10 border-red-500/30">
            <CardContent className="p-6 text-center">
              <XCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Access Denied</h3>
              <p className="text-muted-foreground mb-4">{error}</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button variant="outline" onClick={() => window.location.href = '/support'}>
                  Contact Support
                </Button>
                <Button variant="outline" onClick={() => window.location.href = '/buy'}>
                  Purchase Privately
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {verified && (
          <Card className="mb-6 bg-card/50 border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="w-5 h-5 text-primary" />
                Download Your Software
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {!downloadStatus ? (
                <>
                  <p className="text-muted-foreground">
                    Click the button below to access your download.
                  </p>
                  
                  <Button 
                    size="lg" 
                    onClick={handleDownload}
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold"
                    data-testid="button-download"
                  >
                    <Download className="w-5 h-5 mr-2" />
                    Access Download
                  </Button>
                  
                  <div className="text-sm text-muted-foreground">
                    <p className="mb-2">Your purchase includes:</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>Full Privately application</li>
                      <li>Setup guide and documentation</li>
                      <li>Lifetime updates</li>
                    </ul>
                  </div>
                </>
              ) : downloadStatus.downloading ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-primary">
                    <Download className="w-5 h-5 animate-pulse" />
                    <span className="font-medium">Preparing Download...</span>
                  </div>
                  <p className="text-muted-foreground">{downloadStatus.message}</p>
                </div>
              ) : downloadStatus.success ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-green-500">
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-medium">Download Complete</span>
                  </div>
                  <p className="text-muted-foreground">{downloadStatus.message}</p>
                  <Button 
                    variant="outline"
                    onClick={handleDownload}
                    className="w-full"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download Again
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-red-500">
                    <XCircle className="w-5 h-5" />
                    <span className="font-medium">Download Error</span>
                  </div>
                  <p className="text-muted-foreground">{downloadStatus.message}</p>
                  <Button 
                    variant="outline"
                    onClick={() => window.location.href = '/support'}
                  >
                    Contact Support
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        <div className="grid md:grid-cols-2 gap-4">
          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-4 flex items-start gap-3">
              <Mail className="w-5 h-5 text-primary mt-1" />
              <div>
                <h3 className="font-medium mb-1">Check Your Email</h3>
                <p className="text-sm text-muted-foreground">
                  We've sent a confirmation email with your receipt and download link.
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-4 flex items-start gap-3">
              <HelpCircle className="w-5 h-5 text-primary mt-1" />
              <div>
                <h3 className="font-medium mb-1">Need Help?</h3>
                <p className="text-sm text-muted-foreground">
                  <a href="/support" className="text-primary hover:underline">
                    Contact our support team
                  </a>
                  {" "}for assistance.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>Questions? Contact us at support@privately.app</p>
          <p className="mt-2">
            60-Day Money-Back Guarantee | Secure Payment by ClickBank
          </p>
        </div>
      </div>
    </div>
  );
}
