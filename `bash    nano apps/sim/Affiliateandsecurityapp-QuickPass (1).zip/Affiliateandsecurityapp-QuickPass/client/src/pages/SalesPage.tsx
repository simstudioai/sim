import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Zap, Bot, TrendingUp, Lock, RefreshCw, CheckCircle, Star } from "lucide-react";

export default function SalesPage() {
  const features = [
    {
      icon: Shield,
      title: "Privacy Fortress",
      description: "Military-grade encryption protects your identity across all online activities"
    },
    {
      icon: Bot,
      title: "AI-Powered Automation",
      description: "Fully automated affiliate marketing system that works 24/7 without manual intervention"
    },
    {
      icon: TrendingUp,
      title: "Real-Time Analytics",
      description: "Track earnings, clicks, and conversions across multiple affiliate networks"
    },
    {
      icon: RefreshCw,
      title: "Self-Healing Technology",
      description: "Automatic error recovery and system optimization keeps everything running smoothly"
    },
    {
      icon: Lock,
      title: "Encrypted Vault",
      description: "Secure storage for sensitive data with AES-256 encryption"
    },
    {
      icon: Zap,
      title: "Instant Setup",
      description: "Connect your accounts and start earning within minutes"
    }
  ];

  const testimonials = [
    {
      name: "Marcus T.",
      rating: 5,
      text: "This app completely changed my passive income game. The automation is incredible!"
    },
    {
      name: "Sarah K.",
      rating: 5,
      text: "Finally, an affiliate tool that actually works without constant babysitting."
    },
    {
      name: "James R.",
      rating: 5,
      text: "The self-healing feature saved me countless hours of troubleshooting."
    }
  ];

  const handleBuyNow = () => {
    window.open("https://getfixedsh.pay.clickbank.net", "_blank");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80">
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent" />
        
        <div className="container mx-auto max-w-6xl relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 mb-6">
              <Shield className="w-4 h-4 text-primary" />
              <span className="text-sm text-primary font-medium">Cyberpunk Fortress Technology</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-cyan-400 to-primary bg-clip-text text-transparent">
              Privately
            </h1>
            <h2 className="text-2xl md:text-3xl font-semibold mb-4 text-foreground">
              Android Security + AI Affiliate Marketing
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              The ultimate dual-purpose dashboard combining military-grade privacy protection with 
              fully automated affiliate marketing that runs 24/7 without any manual work.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
              <Button 
                size="lg" 
                onClick={handleBuyNow}
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-6 text-lg font-bold shadow-lg shadow-primary/25"
                data-testid="button-buy-now"
              >
                Get Instant Access Now
              </Button>
              <div className="text-sm text-muted-foreground">
                <span className="line-through">$197</span>
                <span className="text-2xl font-bold text-primary ml-2">$47</span>
                <span className="ml-2">One-Time Payment</span>
              </div>
            </div>
            
            <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <CheckCircle className="w-4 h-4 text-green-500" />
                60-Day Money Back Guarantee
              </span>
              <span className="flex items-center gap-1">
                <CheckCircle className="w-4 h-4 text-green-500" />
                Instant Download
              </span>
              <span className="flex items-center gap-1">
                <CheckCircle className="w-4 h-4 text-green-500" />
                Lifetime Updates
              </span>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="py-16 px-4 bg-card/30">
        <div className="container mx-auto max-w-6xl">
          <h3 className="text-2xl font-bold text-center mb-12 text-foreground">
            Everything You Need In One Powerful Dashboard
          </h3>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full bg-card/50 border-primary/20 hover:border-primary/40 transition-colors">
                  <CardContent className="p-6">
                    <feature.icon className="w-10 h-10 text-primary mb-4" />
                    <h4 className="text-lg font-semibold mb-2 text-foreground">{feature.title}</h4>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <h3 className="text-2xl font-bold text-center mb-12 text-foreground">
            What Our Users Are Saying
          </h3>
          
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-card/50 border-primary/20">
                <CardContent className="p-6">
                  <div className="flex mb-3">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4">"{testimonial.text}"</p>
                  <p className="font-semibold text-foreground">- {testimonial.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-primary/5">
        <div className="container mx-auto max-w-2xl text-center">
          <h3 className="text-2xl font-bold mb-6 text-foreground">
            Ready to Transform Your Online Income?
          </h3>
          <p className="text-muted-foreground mb-8">
            Join thousands of users who are already using Privately to automate their 
            affiliate marketing while protecting their digital privacy.
          </p>
          
          <Button 
            size="lg" 
            onClick={handleBuyNow}
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-12 py-6 text-xl font-bold shadow-lg shadow-primary/25"
            data-testid="button-buy-now-bottom"
          >
            Get Privately Now - Only $47
          </Button>
          
          <p className="text-sm text-muted-foreground mt-6">
            Secured by ClickBank - The Internet's Most Trusted Retailer
          </p>
        </div>
      </section>

      <footer className="py-8 px-4 border-t border-border/50">
        <div className="container mx-auto max-w-4xl text-center text-sm text-muted-foreground">
          <p className="mb-4">
            ClickBank is the retailer of products on this site. CLICKBANK is a registered trademark 
            of Click Sales Inc., a Delaware corporation located at 1444 S. Entertainment Ave., Suite 
            410 Boise, ID 83709, USA and used by permission.
          </p>
          <p>
            ClickBank's role as retailer does not constitute an endorsement, approval or review of 
            these products or any claim, statement or opinion used in promotion of these products.
          </p>
        </div>
      </footer>
    </div>
  );
}
